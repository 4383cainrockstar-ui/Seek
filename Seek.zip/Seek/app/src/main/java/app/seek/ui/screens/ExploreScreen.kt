package app.seek.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.Podcasts
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.TheaterComedy
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.seek.core.Paged
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.ui.LocalActions
import app.seek.ui.components.EndReached
import app.seek.ui.components.ErrorBox
import app.seek.ui.components.Loading
import app.seek.ui.components.PagerVm
import app.seek.ui.components.SectionHeader
import app.seek.ui.components.TopBar
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.VideoCard
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import org.schabi.newpipe.extractor.Page

class KioskVm(private val id: String) : PagerVm<VideoItem>() {
    override suspend fun first(): Paged<VideoItem> = Yt.kiosk(id)
    override suspend fun more(page: Page): Paged<VideoItem> = Yt.kioskMore(id, page)
    override fun keyOf(item: VideoItem): Any = item.url
}

private data class Category(val label: String, val icon: ImageVector, val kiosk: String? = null, val query: String? = null)

private val categories = listOf(
    Category("Music", Icons.Outlined.MusicNote, kiosk = "trending_music"),
    Category("Gaming", Icons.Outlined.SportsEsports, kiosk = "trending_gaming"),
    Category("Movies & TV", Icons.Outlined.Movie, kiosk = "trending_movies_and_shows"),
    Category("Podcasts", Icons.Outlined.Podcasts, kiosk = "trending_podcasts_episodes"),
    Category("Live", Icons.Outlined.Sensors, kiosk = "live"),
    Category("News", Icons.Outlined.Newspaper, query = "news today"),
    Category("Sports", Icons.Outlined.EmojiEvents, query = "sports highlights"),
    Category("Learning", Icons.Outlined.Lightbulb, query = "learn something new"),
    Category("Fashion & Beauty", Icons.Outlined.Checkroom, query = "fashion"),
    Category("Comedy", Icons.Outlined.TheaterComedy, query = "comedy"),
    Category("Tech", Icons.Outlined.Memory, query = "tech review"),
    Category("Cooking", Icons.Outlined.Restaurant, query = "cooking")
)

@UnstableApi
@Composable
fun ExploreScreen() {
    val actions = LocalActions.current
    var kiosk by rememberSaveable { mutableStateOf(Yt.kiosks.first().id) }
    val vm: KioskVm = viewModel(key = "kiosk-$kiosk") { KioskVm(kiosk) }
    LaunchedEffect(vm) { vm.start() }
    val listState = rememberLazyListState()
    EndReached(listState) { vm.loadMore() }
    val progress = rememberWatchProgress()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    val label = Yt.kiosks.firstOrNull { it.id == kiosk }?.label ?: ""

    Column(Modifier.fillMaxSize()) {
        TopBar("Explore", onBack = { actions.back() }) {
            IconButton(onClick = { actions.search() }) { Icon(Icons.Rounded.Search, "Search", tint = Cl.Text, modifier = Modifier.size(26.dp)) }
        }
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
            // Destination tiles, two per row
            items(categories.chunked(2)) { pair ->
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    pair.forEach { c ->
                        CategoryTile(c, selected = c.kiosk == kiosk, modifier = Modifier.weight(1f)) {
                            when {
                                c.kiosk != null -> kiosk = c.kiosk
                                c.query != null -> actions.search(c.query)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item { SectionHeader("Trending in $label") }
            when {
                vm.loading && vm.items.isEmpty() -> item { Loading() }
                vm.error != null && vm.items.isEmpty() -> item { ErrorBox(vm.error ?: "", onRetry = { vm.reload() }) }
                else -> items(vm.items, key = { it.url }) { v ->
                    VideoCard(
                        video = v,
                        progress = progress[v.url] ?: 0f,
                        onClick = { actions.video(v) },
                        onChannel = { actions.channel(v.uploaderUrl) },
                        onMore = { menuFor = v }
                    )
                }
            }
            if (vm.loadingMore) item { Loading() }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}

@Composable
private fun CategoryTile(c: Category, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .height(48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Cl.SurfaceHighest else Cl.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(c.icon, null, tint = Cl.Text, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(c.label, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}
