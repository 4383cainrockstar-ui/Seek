package app.seek.ui

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import app.seek.ui.components.pressClick
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Subscriptions
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.seek.feed.FeedRepository
import app.seek.player.PlayerController
import app.seek.ui.components.SeekLine
import app.seek.ui.screens.ChannelScreen
import app.seek.ui.screens.DownloadsScreen
import app.seek.ui.screens.ExploreScreen
import app.seek.ui.screens.HistoryScreen
import app.seek.ui.screens.HomeScreen
import app.seek.ui.screens.LibraryScreen
import app.seek.ui.screens.LocalPlaylistScreen
import app.seek.ui.screens.PlayerScreen
import app.seek.ui.screens.PlaylistScreen
import app.seek.ui.screens.PlaylistsScreen
import app.seek.ui.screens.SearchScreen
import app.seek.ui.screens.SettingsScreen
import app.seek.ui.screens.ShortsScreen
import app.seek.ui.screens.SubscriptionsManageScreen
import app.seek.ui.screens.SubscriptionsScreen
import app.seek.ui.screens.WatchLaterScreen
import app.seek.ui.theme.Cl
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun arg(raw: String?): String {
    val v = raw ?: return ""
    return if (v.startsWith("http%3A") || v.startsWith("https%3A")) Uri.decode(v) else v
}

@UnstableApi
@Composable
fun SeekRoot() {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val actions = remember(nav) {
        Actions(nav, ctx.applicationContext) { msg ->
            scope.launch {
                snack.currentSnackbarData?.dismiss()
                snack.showSnackbar(msg)
            }
        }
    }
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val inPip by UiState.inPip.collectAsState()
    val now by PlayerController.now.collectAsState()
    var showLinkDialog by remember { mutableStateOf(false) }

    LaunchedEffect(route) { UiState.onPlayerScreen.value = route == Routes.PLAYER }

    // Links / notification taps arriving from outside
    val pending by UiState.pending.collectAsState()
    LaunchedEffect(pending) {
        val p = pending ?: return@LaunchedEffect
        when (p) {
            is UiState.Pending.Link -> actions.link(p.url)
            UiState.Pending.OpenPlayer -> if (PlayerController.now.value != null) actions.openPlayer()
            UiState.Pending.OpenDownloads -> actions.open(Routes.DOWNLOADS)
        }
        UiState.pending.value = null
    }

    // Player toasts (SponsorBlock skips, sleep timer)
    LaunchedEffect(Unit) {
        PlayerController.events.collect {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar(it)
        }
    }

    // Fresh feed on launch
    LaunchedEffect(Unit) {
        if (FeedRepository.isStale()) {
            try {
                FeedRepository.refresh()
            } catch (_: Exception) {
            }
        }
    }

    CompositionLocalProvider(LocalActions provides actions) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Cl.Deep)
        ) {
            Column(Modifier.fillMaxSize()) {
                // Lists end right above the keyboard instead of under it
                Box(Modifier.weight(1f).imePadding()) {
                    NavHost(
                        navController = nav,
                        startDestination = Routes.HOME,
                        // Tabs cross-fade, the player rises from the bottom, pages slide in from the right
                        enterTransition = {
                            val to = targetState.destination.route
                            val from = initialState.destination.route
                            when {
                                to == Routes.PLAYER -> slideInVertically(tween(320, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(180))
                                to in Routes.tabs && from in Routes.tabs -> fadeIn(tween(160))
                                else -> slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 3 } + fadeIn(tween(200))
                            }
                        },
                        exitTransition = {
                            val to = targetState.destination.route
                            val from = initialState.destination.route
                            when {
                                to == Routes.PLAYER -> fadeOut(tween(260))
                                to in Routes.tabs && from in Routes.tabs -> fadeOut(tween(110))
                                else -> slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it / 10 } + fadeOut(tween(220))
                            }
                        },
                        popEnterTransition = {
                            val to = targetState.destination.route
                            val from = initialState.destination.route
                            when {
                                from == Routes.PLAYER -> fadeIn(tween(220))
                                to in Routes.tabs && from in Routes.tabs -> fadeIn(tween(160))
                                else -> slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { -it / 10 } + fadeIn(tween(180))
                            }
                        },
                        popExitTransition = {
                            val to = targetState.destination.route
                            val from = initialState.destination.route
                            when {
                                from == Routes.PLAYER -> slideOutVertically(tween(280, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(220))
                                to in Routes.tabs && from in Routes.tabs -> fadeOut(tween(110))
                                else -> slideOutHorizontally(tween(220, easing = FastOutSlowInEasing)) { it / 3 } + fadeOut(tween(170))
                            }
                        }
                    ) {
                        composable(Routes.HOME) { HomeScreen() }
                        composable(Routes.SHORTS) { ShortsScreen() }
                        composable(Routes.EXPLORE) { ExploreScreen() }
                        composable(Routes.SUBS) { SubscriptionsScreen() }
                        composable(Routes.SUBS_ALL) { SubscriptionsManageScreen() }
                        composable(Routes.LIBRARY) { LibraryScreen() }
                        composable(
                            Routes.SEARCH,
                            arguments = listOf(navArgument("q") { type = NavType.StringType; defaultValue = "" })
                        ) { e -> SearchScreen(arg(e.arguments?.getString("q"))) }
                        composable(Routes.PLAYER) { PlayerScreen() }
                        composable(
                            Routes.CHANNEL,
                            arguments = listOf(navArgument("url") { type = NavType.StringType })
                        ) { e -> ChannelScreen(arg(e.arguments?.getString("url"))) }
                        composable(
                            Routes.PLAYLIST,
                            arguments = listOf(navArgument("url") { type = NavType.StringType })
                        ) { e -> PlaylistScreen(arg(e.arguments?.getString("url"))) }
                        composable(
                            Routes.LOCAL_PLAYLIST,
                            arguments = listOf(navArgument("id") { type = NavType.StringType })
                        ) { e -> LocalPlaylistScreen(e.arguments?.getString("id") ?: "") }
                        composable(Routes.HISTORY) { HistoryScreen() }
                        composable(Routes.WATCH_LATER) { WatchLaterScreen() }
                        composable(Routes.PLAYLISTS) { PlaylistsScreen() }
                        composable(Routes.DOWNLOADS) { DownloadsScreen() }
                        composable(Routes.SETTINGS) { SettingsScreen() }
                    }
                }

                // The bottom bar and mini player step aside while you type, like on YouTube
                val typing = WindowInsets.isImeVisible
                val showChrome = route != Routes.PLAYER && !inPip && !typing
                AnimatedVisibility(
                    visible = showChrome && now != null && route != Routes.SHORTS,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut()
                ) {
                    MiniPlayer(onOpen = { actions.openPlayer() })
                }
                AnimatedVisibility(
                    visible = showChrome,
                    enter = fadeIn(tween(150)),
                    exit = fadeOut(tween(90))
                ) {
                    BottomBar(route = route, onTab = { actions.tab(it) }, onCreate = { showLinkDialog = true })
                }
            }

            SnackbarHost(
                snack,
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = if (route == Routes.PLAYER) 16.dp else if (now != null) 130.dp else 68.dp)
            ) { data ->
                // YouTube's snackbar is the light one, even in dark mode
                Snackbar(
                    snackbarData = data,
                    containerColor = Cl.Text,
                    contentColor = Color.Black,
                    actionColor = Color(0xFF065FD4),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }

        if (showLinkDialog) {
            LinkDialog(
                onDismiss = { showLinkDialog = false },
                onOpen = { url ->
                    if (actions.link(url)) showLinkDialog = false
                }
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Bottom navigation: Home · Shorts · (+) · Subscriptions · You
// ---------------------------------------------------------------------------------------------

@Composable
private fun BottomBar(route: String?, onTab: (String) -> Unit, onCreate: () -> Unit) {
    val home = route == Routes.HOME || route == Routes.EXPLORE
    val shorts = route == Routes.SHORTS
    val subs = route == Routes.SUBS || route == Routes.SUBS_ALL
    val you = route == Routes.LIBRARY || route == Routes.HISTORY || route == Routes.WATCH_LATER ||
        route == Routes.PLAYLISTS || route == Routes.DOWNLOADS
    Column(
        Modifier
            .fillMaxWidth()
            .background(Cl.Deep)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Color.White.copy(alpha = 0.08f))
        )
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem("Home", home, { onTab(Routes.HOME) }) {
                Icon(if (home) Icons.Filled.Home else Icons.Outlined.Home, null, tint = Cl.Text, modifier = Modifier.size(24.dp))
            }
            NavItem("Shorts", shorts, { onTab(Routes.SHORTS) }) { ShortsIcon(filled = shorts) }
            // YouTube's round "create" button. Here it opens any YouTube link.
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, Cl.Text.copy(alpha = 0.9f), CircleShape)
                        .clickable(onClick = onCreate),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Add, "Open a link", tint = Cl.Text, modifier = Modifier.size(26.dp))
                }
            }
            NavItem("Subscriptions", subs, { onTab(Routes.SUBS) }) {
                Icon(if (subs) Icons.Filled.Subscriptions else Icons.Outlined.Subscriptions, null, tint = Cl.Text, modifier = Modifier.size(24.dp))
            }
            NavItem("You", you, { onTab(Routes.LIBRARY) }) {
                Icon(if (you) Icons.Filled.AccountCircle else Icons.Outlined.AccountCircle, null, tint = Cl.Text, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(label: String, selected: Boolean, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        icon()
        Spacer(Modifier.height(2.dp))
        Text(
            label,
            fontSize = 10.sp,
            color = Cl.Text,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            maxLines = 1
        )
    }
}

/** A vertical video with a play mark: the Shorts tab icon. */
@Composable
fun ShortsIcon(filled: Boolean, color: Color = Cl.Text, modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val left = w * 0.26f
        val top = h * 0.12f
        val rw = w * 0.48f
        val rh = h * 0.76f
        val r = CornerRadius(w * 0.12f, w * 0.12f)
        if (filled) {
            drawRoundRect(color, Offset(left, top), Size(rw, rh), r)
        } else {
            drawRoundRect(color, Offset(left, top), Size(rw, rh), r, style = Stroke(width = w * 0.075f))
        }
        val tri = Path().apply {
            moveTo(w * 0.43f, h * 0.38f)
            lineTo(w * 0.43f, h * 0.62f)
            lineTo(w * 0.61f, h * 0.50f)
            close()
        }
        drawPath(tri, if (filled) Cl.Deep else color)
    }
}

// ---------------------------------------------------------------------------------------------
// Mini player: swipe down to close, up (or tap) to open
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
private fun MiniPlayer(onOpen: () -> Unit) {
    val now by PlayerController.now.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val n = now ?: return
    var fraction by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(n.item.url) {
        while (true) {
            val d = PlayerController.exo.duration
            fraction = if (d > 0) (PlayerController.exo.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(500)
        }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .background(Cl.Surface)
            .pressClick(scale = 0.985f, onClick = onOpen)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total > 60f) PlayerController.stop() else if (total < -40f) onOpen()
                    }
                ) { change, dy ->
                    change.consume()
                    total += dy
                }
            }
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(60.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .width(107.dp)
                    .background(Color.Black)
            ) {
                if (n.item.thumbnail.isNotBlank()) {
                    AsyncImage(n.item.thumbnail, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(n.item.title, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Text(
                    if (n.loading) "Loading…" else n.item.uploader,
                    color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = { PlayerController.togglePlay() }) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Pause" else "Play", tint = Cl.Text, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = { PlayerController.stop() }) {
                Icon(Icons.Rounded.Close, "Close", tint = Cl.Text)
            }
        }
        SeekLine(fraction)
    }
}

// ---------------------------------------------------------------------------------------------
// "+": open any YouTube link
// ---------------------------------------------------------------------------------------------

@Composable
private fun LinkDialog(onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var text by remember {
        val clip = try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
        } catch (e: Exception) {
            ""
        }
        mutableStateOf(if (clip.contains("youtu")) clip.trim() else "")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Cl.Surface,
        shape = RoundedCornerShape(12.dp),
        title = { Text("Open a YouTube link", color = Cl.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Paste a video, Short, channel or playlist link.", color = Cl.TextDim, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text("https://youtu.be/…", color = Cl.TextFaint) },
                    trailingIcon = {
                        IconButton(onClick = {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            text = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim() ?: text
                        }) { Icon(Icons.Rounded.ContentPaste, "Paste", tint = Cl.Text) }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cl.Blue,
                        unfocusedBorderColor = Cl.SurfaceHighest,
                        focusedTextColor = Cl.Text,
                        unfocusedTextColor = Cl.Text,
                        cursorColor = Cl.Blue
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onOpen(text) }, enabled = text.isNotBlank()) {
                Text("Open", color = if (text.isNotBlank()) Cl.Blue else Cl.TextFaint, fontWeight = FontWeight.Medium)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Cl.Text) }
        }
    )
}
