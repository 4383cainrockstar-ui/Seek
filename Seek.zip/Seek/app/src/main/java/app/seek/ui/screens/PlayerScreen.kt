package app.seek.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Typeface
import android.media.AudioManager
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.Headphones
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import app.seek.MainActivity
import app.seek.core.CommentItem
import app.seek.core.Fmt
import app.seek.core.Paged
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.data.Settings
import app.seek.download.Downloads
import app.seek.extras.SbSegment
import app.seek.extras.SponsorBlock
import app.seek.player.NowPlaying
import app.seek.player.PlayerController
import app.seek.ui.LocalActions
import app.seek.ui.UiState
import app.seek.ui.components.AddToPlaylistDialog
import app.seek.ui.components.Avatar
import app.seek.ui.components.ErrorBox
import app.seek.ui.components.Loading
import app.seek.ui.components.PagerVm
import app.seek.ui.components.SheetRow
import app.seek.ui.components.SubscribeButton
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.Thumb
import app.seek.ui.components.VideoCard
import app.seek.ui.components.VideoRow
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import org.schabi.newpipe.extractor.Page
import kotlin.math.roundToInt
import android.graphics.drawable.BitmapDrawable
import android.view.LayoutInflater
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.rounded.ClearAll
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import app.seek.R
import app.seek.core.CommentSort
import app.seek.player.ViewAngle
import app.seek.ui.components.Chip
import app.seek.ui.components.EchoLoader
import app.seek.ui.components.LinkedText
import app.seek.ui.components.SkeletonComments
import app.seek.ui.components.pressClick
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.stream.Frameset
import kotlin.math.abs
import kotlin.math.max

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

class CommentsVm(private val url: String) : PagerVm<CommentItem>() {
    var sort by mutableStateOf(CommentSort.TOP)
        private set

    override suspend fun first(): Paged<CommentItem> = Yt.comments(url, sort)
    override suspend fun more(page: Page): Paged<CommentItem> = Yt.commentsMore(url, page)
    override fun keyOf(item: CommentItem): Any = item.key

    fun changeSort(s: CommentSort) {
        if (s == sort) return
        sort = s
        replies.clear()
        reload()
    }

    /** The replies under one comment, loaded when you open them. */
    class Thread {
        var items by mutableStateOf<List<CommentItem>>(emptyList())
        var next by mutableStateOf<Page?>(null)
        var loading by mutableStateOf(false)
        var failed by mutableStateOf(false)
        var open by mutableStateOf(false)
    }

    val replies = mutableStateMapOf<String, Thread>()

    fun toggleReplies(c: CommentItem) {
        val t = replies.getOrPut(c.key) { Thread() }
        if (t.open) {
            t.open = false
            return
        }
        t.open = true
        if (t.items.isEmpty() && !t.loading) loadReplies(t, c.repliesPage)
    }

    fun moreReplies(c: CommentItem) {
        val t = replies[c.key] ?: return
        if (t.loading) return
        if (t.failed && t.items.isEmpty()) loadReplies(t, c.repliesPage) else t.next?.let { loadReplies(t, it) }
    }

    private fun loadReplies(t: Thread, page: Page?) {
        if (page == null) {
            t.failed = true
            return
        }
        t.loading = true
        t.failed = false
        viewModelScope.launch {
            try {
                val p = Yt.replies(url, page)
                t.items = (t.items + p.items).distinctBy { it.key }
                t.next = p.next
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                t.failed = true
            } finally {
                t.loading = false
            }
        }
    }
}

private enum class Sheet { NONE, SETTINGS, QUALITY, SPEED, CAPTIONS, SLEEP, DOWNLOAD, COMMENTS, SAVE, DESCRIPTION, QUEUE }

@UnstableApi
@Composable
fun PlayerScreen() {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val now by PlayerController.now.collectAsState()
    val inPip by UiState.inPip.collectAsState()
    val config = LocalConfiguration.current
    var forcedFullscreen by remember { mutableStateOf(false) }
    val landscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
    val fullscreen = landscape || forcedFullscreen

    // Leaving the player puts orientation back to normal
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            // The motion sensor only runs while you're watching
            ViewAngle.stopAuto()
            ViewAngle.panel = false
        }
    }

    // Immersive mode while fullscreen
    DisposableEffect(fullscreen, inPip) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        if (fullscreen || inPip) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    fun toggleFullscreen() {
        if (fullscreen) {
            forcedFullscreen = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            forcedFullscreen = true
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    BackHandler(enabled = ViewAngle.panel && !inPip) { ViewAngle.panel = false }
    BackHandler(enabled = fullscreen && !inPip && !ViewAngle.panel) { toggleFullscreen() }

    val n = now
    if (n == null) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.fillMaxWidth().padding(8.dp)) {
                IconButton(onClick = { actions.back() }) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", tint = Cl.Text) }
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nothing playing", color = Cl.TextDim)
            }
        }
        return
    }

    if (inPip) {
        Box(Modifier.fillMaxSize().background(Color.Black)) { VideoSurface(n, transform = false) }
        return
    }

    if (fullscreen) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            PlayerBox(n, fullscreen = true, onFullscreen = { toggleFullscreen() }, onMinimize = { toggleFullscreen() })
            ViewAnglePanel(fullscreen = true, modifier = Modifier.align(Alignment.BottomCenter))
        }
        return
    }

    Box(Modifier.fillMaxSize().background(Cl.Deep)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.background(Color.Black).statusBarsPadding()) {
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                    PlayerBox(n, fullscreen = false, onFullscreen = { toggleFullscreen() }, onMinimize = { actions.back() })
                }
            }
            Details(n)
        }
        // Sits over the details (not the video), so you can watch the picture straighten out
        ViewAnglePanel(fullscreen = false, modifier = Modifier.align(Alignment.BottomCenter))
    }
}

// ---------------------------------------------------------------------------------------------
// Video surface + controls
// ---------------------------------------------------------------------------------------------

/** How much to zoom so the video fills a [w] x [h] box (1 = it already does). */
@UnstableApi
internal fun fillScaleFor(w: Int, h: Int): Float {
    val v = PlayerController.exo.videoSize
    if (w <= 0 || h <= 0 || v.width <= 0 || v.height <= 0) return 1f
    val va = v.width * v.pixelWidthHeightRatio / v.height
    val ba = w.toFloat() / h
    return max(va / ba, ba / va)
}

@UnstableApi
@Composable
private fun VideoSurface(n: NowPlaying, transform: Boolean = true) {
    val playing by PlayerController.isPlaying.collectAsState()
    val settings by Settings.state.collectAsState()
    val density = LocalDensity.current.density
    // Zoom glides to where your fingers (or the snap) put it; read only while drawing
    val zoomAnim = remember { Animatable(ViewAngle.zoom) }
    LaunchedEffect(Unit) {
        snapshotFlow { ViewAngle.zoom }.collectLatest {
            zoomAnim.animateTo(it, spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow))
        }
    }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val boxNow by rememberUpdatedState(box)
    // Zoomed to fill stays filled when the next video has a different shape
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (ViewAngle.filled) ViewAngle.zoom = fillScaleFor(boxNow.width, boxNow.height)
            }
        }
        PlayerController.exo.addListener(l)
        onDispose { PlayerController.exo.removeListener(l) }
    }
    Box(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { box = it },
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { context ->
                (LayoutInflater.from(context).inflate(R.layout.player_texture, null) as PlayerView).apply {
                    layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    useController = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    setKeepContentOnPlayerReset(true)
                    player = PlayerController.exo
                }
            },
            update = { view ->
                if (view.player !== PlayerController.exo) view.player = PlayerController.exo
                view.keepScreenOn = playing
                view.subtitleView?.apply {
                    setStyle(
                        CaptionStyleCompat(
                            android.graphics.Color.WHITE,
                            if (settings.captionBackground) 0xAA000000.toInt() else android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT,
                            if (settings.captionBackground) CaptionStyleCompat.EDGE_TYPE_NONE else CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                            android.graphics.Color.BLACK,
                            Typeface.DEFAULT_BOLD
                        )
                    )
                    setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * settings.captionScale)
                }
            },
            onRelease = { view -> view.player = null },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    if (transform) {
                        val fit = ViewAngle.fitScale()
                        val z = zoomAnim.value
                        scaleX = z * fit
                        scaleY = z * fit
                        rotationX = ViewAngle.rotationX
                        rotationY = ViewAngle.rotationY
                        cameraDistance = 12f * density
                    }
                }
        )
        if (n.audioOnly) {
            Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                if (n.item.thumbnail.isNotBlank()) {
                    AsyncImage(
                        n.item.thumbnail, null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        alpha = 0.45f
                    )
                }
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Headphones, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Audio only", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@UnstableApi
@Composable
private fun PlayerBox(
    n: NowPlaying,
    fullscreen: Boolean,
    onFullscreen: () -> Unit,
    onMinimize: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val playing by PlayerController.isPlaying.collectAsState()
    val buffering by PlayerController.buffering.collectAsState()
    var controls by remember { mutableStateOf(true) }
    var poke by remember { mutableIntStateOf(0) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var seekHint by remember { mutableStateOf<String?>(null) }
    var gestureHint by remember { mutableStateOf<Pair<ImageVector, Float>?>(null) }
    var zoomHint by remember { mutableStateOf<String?>(null) }
    var sheet by remember { mutableStateOf(Sheet.NONE) }
    val boosted by PlayerController.boosted.collectAsState()
    val haptics = LocalHapticFeedback.current
    LaunchedEffect(zoomHint) {
        if (zoomHint != null) {
            delay(900)
            zoomHint = null
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            val exo = PlayerController.exo
            position = exo.currentPosition
            duration = exo.duration.coerceAtLeast(0)
            buffered = exo.bufferedPosition
            delay(200)
        }
    }
    LaunchedEffect(controls, playing, poke) {
        if (controls && playing) {
            delay(3200)
            controls = false
        }
    }
    LaunchedEffect(seekHint) {
        if (seekHint != null) {
            delay(650)
            seekHint = null
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clipToBounds()
    ) {
        VideoSurface(n)

        // Gesture layer: tap toggles controls, double tap seeks, hold = 2x, pinch = zoom to fill,
        // vertical drags = brightness / volume (fullscreen) or minimize (portrait)
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        // Hold anywhere on the video: 2x while your finger is down, like YouTube
                        onPress = {
                            tryAwaitRelease()
                            PlayerController.endBoost()
                        },
                        onLongPress = {
                            val cur = PlayerController.now.value
                            if (PlayerController.exo.isPlaying && cur != null && !cur.isLive) {
                                PlayerController.startBoost()
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                controls = false
                            }
                        },
                        onTap = {
                            controls = !controls
                            poke++
                        },
                        onDoubleTap = { off ->
                            if (off.x < size.width / 2f) {
                                PlayerController.seekBy(-10_000)
                                seekHint = "◀◀  10 seconds"
                            } else {
                                PlayerController.seekBy(10_000)
                                seekHint = "10 seconds  ▶▶"
                            }
                        }
                    )
                }
                .pointerInput(fullscreen) {
                    // Portrait: swipe down to minimize, like YouTube. Fullscreen: brightness / volume.
                    if (!fullscreen) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total > 120f) onMinimize() }
                        ) { change, dy ->
                            change.consume()
                            total += dy
                        }
                        return@pointerInput
                    }
                    var leftSide = true
                    var level = 0f
                    val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    detectVerticalDragGestures(
                        onDragStart = { off ->
                            leftSide = off.x < size.width / 2f
                            level = if (leftSide) {
                                val b = activity?.window?.attributes?.screenBrightness ?: -1f
                                if (b < 0) 0.5f else b
                            } else {
                                audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol
                            }
                        },
                        onDragEnd = { gestureHint = null },
                        onDragCancel = { gestureHint = null }
                    ) { change, dy ->
                        change.consume()
                        level = (level - dy / (size.height * 0.9f)).coerceIn(0f, 1f)
                        if (leftSide) {
                            activity?.window?.let { w ->
                                val lp = w.attributes
                                lp.screenBrightness = level.coerceAtLeast(0.01f)
                                w.attributes = lp
                            }
                            gestureHint = Icons.Rounded.BrightnessMedium to level
                        } else {
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * maxVol).roundToInt(), 0)
                            gestureHint = Icons.AutoMirrored.Rounded.VolumeUp to level
                        }
                    }
                }
                // Pinch: zoom between the whole video and filling the screen (snaps to one or the other)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        val start = ViewAngle.zoom
                        val fill = fillScaleFor(size.width, size.height)
                        var acc = 1f
                        var pinched = false
                        do {
                            val event = awaitPointerEvent()
                            if (event.changes.count { it.pressed } >= 2) {
                                val z = event.calculateZoom()
                                if (z != 1f) {
                                    pinched = true
                                    acc *= z
                                    ViewAngle.zoom = (start * acc).coerceIn(0.85f, max(fill, 1f) * 1.15f)
                                    event.changes.forEach { it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (pinched) {
                            val wantFill = fill > 1.01f && ViewAngle.zoom > 1f + (fill - 1f) * 0.35f
                            ViewAngle.filled = wantFill
                            ViewAngle.zoom = if (wantFill) fill else 1f
                            zoomHint = when {
                                fill <= 1.01f -> "Already fills the screen"
                                wantFill -> "Zoomed to fill"
                                else -> "Original"
                            }
                        }
                    }
                }
        )

        // Hold for 2x
        AnimatedVisibility(
            visible = boosted,
            enter = fadeIn() + scaleIn(initialScale = 0.85f),
            exit = fadeOut() + scaleOut(targetScale = 0.9f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .then(if (fullscreen) Modifier.statusBarsPadding() else Modifier)
                .padding(top = 14.dp)
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("2x", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Rounded.FastForward, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }

        // Zoom feedback
        zoomHint?.let {
            Text(
                it,
                color = Color.White,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            )
        }

        // Double-tap / gesture feedback
        seekHint?.let {
            Text(
                it,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            )
        }
        gestureHint?.let { (icon, value) ->
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 24.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.width(110.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.3f))) {
                    Box(Modifier.fillMaxWidth(value).height(4.dp).background(Color.White))
                }
            }
        }

        if ((buffering || n.loading) && n.error == null) {
            EchoLoader(Modifier.align(Alignment.Center), size = 52.dp)
        }

        if (n.error != null) {
            Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(n.error, color = Color.White, textAlign = TextAlign.Center, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White)
                        .clickable { PlayerController.retry() }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Replay, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Try again", color = Color.Black, fontWeight = FontWeight.Medium)
                }
            }
        }

        if (!controls && !fullscreen && n.error == null && !n.isLive) {
            IdleProgress(Modifier.align(Alignment.BottomStart))
        }

        AnimatedVisibility(
            visible = controls && n.error == null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Controls(
                n = n,
                fullscreen = fullscreen,
                playing = playing,
                position = position,
                duration = duration,
                buffered = buffered,
                onInteract = { poke++ },
                onMinimize = onMinimize,
                onFullscreen = onFullscreen,
                onSettings = { sheet = Sheet.SETTINGS },
                onCaptions = { sheet = Sheet.CAPTIONS },
                onPip = { (activity as? MainActivity)?.enterPip() }
            )
        }
    }

    PlayerSheets(n, sheet) { sheet = it }
}

@UnstableApi
@Composable
private fun Controls(
    n: NowPlaying,
    fullscreen: Boolean,
    playing: Boolean,
    position: Long,
    duration: Long,
    buffered: Long,
    onInteract: () -> Unit,
    onMinimize: () -> Unit,
    onFullscreen: () -> Unit,
    onSettings: () -> Unit,
    onCaptions: () -> Unit,
    onPip: () -> Unit
) {
    val settings by Settings.state.collectAsState()
    var scrubbing by remember { mutableStateOf<Long?>(null) }
    var width by remember { mutableIntStateOf(0) }
    val chapter = remember(n.info, position) {
        n.info?.streamSegments?.lastOrNull { it.startTimeSeconds * 1000L <= position }?.title
    }
    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { width = it.width }
            .background(Color.Black.copy(alpha = 0.45f))
    ) {
        // Top row: minimize · autoplay · captions · settings
        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .then(if (fullscreen) Modifier.statusBarsPadding() else Modifier)
                .padding(horizontal = 4.dp, vertical = if (fullscreen) 8.dp else 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMinimize) {
                Icon(Icons.Rounded.KeyboardArrowDown, "Minimize", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            if (fullscreen) {
                Text(
                    n.item.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            } else Spacer(Modifier.weight(1f))
            AutoplayToggle(settings.autoplay) {
                onInteract()
                Settings.update { it.copy(autoplay = !it.autoplay) }
            }
            if (!n.audioOnly) {
                IconButton(onClick = { onInteract(); ViewAngle.panel = !ViewAngle.panel }) {
                    Icon(
                        Icons.Rounded.ViewInAr, "View angle",
                        tint = if (ViewAngle.active) Cl.Red else Color.White
                    )
                }
            }
            if (n.subtitles.isNotEmpty()) {
                IconButton(onClick = { onInteract(); onCaptions() }) {
                    Icon(
                        if (n.subtitleId != null) Icons.Rounded.ClosedCaption else Icons.Outlined.ClosedCaption, "Captions",
                        tint = Color.White
                    )
                }
            }
            IconButton(onClick = { onInteract(); onSettings() }) {
                Icon(Icons.Outlined.Settings, "Settings", tint = Color.White)
            }
        }

        // Center: previous · play/pause · next (out of the way while you scrub)
        if (scrubbing == null) Row(
            Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(if (fullscreen) 64.dp else 40.dp)
        ) {
            RoundIcon(Icons.Rounded.SkipPrevious, 34.dp) { onInteract(); PlayerController.playPrevious() }
            Box(
                Modifier
                    .size(if (fullscreen) 68.dp else 58.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.3f))
                    .clickable { onInteract(); PlayerController.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (playing) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(if (fullscreen) 50.dp else 44.dp)
                )
            }
            Box(Modifier.alpha(if (PlayerController.hasNext()) 1f else 0.4f)) {
                RoundIcon(Icons.Rounded.SkipNext, 34.dp) { onInteract(); PlayerController.playNext() }
            }
        }

        // Scrubbing: a preview of the frame you'd land on, riding above your finger
        scrubbing?.let { t ->
            val frames = n.info?.previewFrames.orEmpty()
            val at = n.info?.streamSegments?.lastOrNull { it.startTimeSeconds * 1000L <= t }?.title
            val previewW = if (fullscreen) 200.dp else 150.dp
            val density = LocalDensity.current
            val pw = with(density) { previewW.toPx() }
            val margin = with(density) { 12.dp.toPx() }
            val frac = if (duration > 0) (t.toFloat() / duration).coerceIn(0f, 1f) else 0f
            val x = (frac * width - pw / 2f).coerceIn(margin, (width - pw - margin).coerceAtLeast(margin))
            ScrubPreview(
                frames = frames,
                timeMs = t,
                chapter = at,
                width = previewW,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = if (fullscreen) 96.dp else 50.dp)
                    .offset { IntOffset(x.roundToInt(), 0) }
            )
        }

        // Bottom: time · chapter, PiP, fullscreen, and the seek bar
        Column(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .then(if (fullscreen) Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp) else Modifier)
        ) {
            Row(
                Modifier.padding(start = if (fullscreen) 0.dp else 12.dp, end = if (fullscreen) 0.dp else 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (n.isLive) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Cl.Red))
                        Spacer(Modifier.width(6.dp))
                        Text("LIVE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                } else {
                    Text(
                        Fmt.durationMs(position),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(" / " + Fmt.durationMs(duration), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    if (!chapter.isNullOrBlank()) {
                        Text(
                            "  ·  $chapter",
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Icon(Icons.Rounded.ChevronRight, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(Modifier.weight(1f))
                if (!n.audioOnly) SmallIcon(Icons.Rounded.PictureInPictureAlt) { onPip() }
                SmallIcon(if (fullscreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen) { onFullscreen() }
            }
            SeekBar(
                position = position,
                duration = duration,
                buffered = buffered,
                segments = n.segments,
                enabled = !n.isLive,
                showThumb = true,
                onScrub = { t -> onInteract(); scrubbing = t },
                onSeek = {
                    scrubbing = null
                    PlayerController.seekTo(it)
                }
            )
        }
    }
}

/** YouTube's little autoplay switch in the player's top bar. */
@Composable
private fun AutoplayToggle(on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(horizontal = 6.dp)
            .size(width = 40.dp, height = 24.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier
                .align(Alignment.Center)
                .size(width = 36.dp, height = 14.dp)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = if (on) 0.7f else 0.3f))
        )
        Box(
            Modifier
                .align(if (on) Alignment.CenterEnd else Alignment.CenterStart)
                .size(22.dp)
                .clip(CircleShape)
                .background(if (on) Color.White else Color(0xFF717171)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (on) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                if (on) "Autoplay on" else "Autoplay off",
                tint = if (on) Color.Black else Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun RoundIcon(icon: ImageVector, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(size))
    }
}

@Composable
private fun SmallIcon(icon: ImageVector, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
    }
}

/**
 * The red seek bar, YouTube style: grey track, lighter buffered part, red played part,
 * SponsorBlock segments painted on top, and a red scrubber that grows while you drag.
 */
@Composable
private fun SeekBar(
    position: Long,
    duration: Long,
    buffered: Long,
    segments: List<SbSegment>,
    enabled: Boolean,
    showThumb: Boolean,
    onScrub: (Long) -> Unit,
    onSeek: (Long) -> Unit
) {
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    val fraction = when {
        dragging -> dragFraction
        duration > 0 -> (position.toFloat() / duration).coerceIn(0f, 1f)
        else -> 0f
    }
    val bufferedFraction = if (duration > 0) (buffered.toFloat() / duration).coerceIn(0f, 1f) else 0f

    Box(
        Modifier
            .fillMaxWidth()
            .height(24.dp)
            .pointerInput(duration, enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { off ->
                    if (duration > 0) onSeek(((off.x / size.width).coerceIn(0f, 1f) * duration).toLong())
                }
            }
            .pointerInput(duration, enabled) {
                if (!enabled) return@pointerInput
                detectHorizontalDragGestures(
                    onDragStart = { off ->
                        dragging = true
                        dragFraction = (off.x / size.width).coerceIn(0f, 1f)
                        onScrub((dragFraction * duration).toLong())
                    },
                    onDragEnd = {
                        if (duration > 0) onSeek((dragFraction * duration).toLong())
                        dragging = false
                    },
                    onDragCancel = {
                        dragging = false
                        onSeek(position)
                    }
                ) { change, _ ->
                    change.consume()
                    dragFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                    onScrub((dragFraction * duration).toLong())
                }
            },
        contentAlignment = Alignment.BottomStart
    ) {
        Canvas(Modifier.fillMaxWidth().height(24.dp)) {
            val h = if (dragging) 5.dp.toPx() else 3.dp.toPx()
            val y = size.height - 10.dp.toPx() - h / 2f
            drawRect(Color.White.copy(alpha = 0.3f), Offset(0f, y), Size(size.width, h))
            drawRect(Color.White.copy(alpha = 0.45f), Offset(0f, y), Size(size.width * bufferedFraction, h))
            drawRect(Cl.Red, Offset(0f, y), Size(size.width * fraction, h))
            if (duration > 0) {
                segments.forEach { s ->
                    val x0 = size.width * (s.startMs.toFloat() / duration).coerceIn(0f, 1f)
                    val x1 = size.width * (s.endMs.toFloat() / duration).coerceIn(0f, 1f)
                    drawRect(Color(SponsorBlock.color(s.category)), Offset(x0, y), Size((x1 - x0).coerceAtLeast(2f), h))
                }
            }
            if (showThumb) {
                val r = if (dragging) 8.dp.toPx() else 6.dp.toPx()
                drawCircle(Cl.Red, r, Offset(size.width * fraction, y + h / 2f))
            }
        }
    }
}

/** When the controls are hidden: just a thin red line along the bottom of the video. */
@UnstableApi
@Composable
private fun IdleProgress(modifier: Modifier = Modifier) {
    var fraction by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            val d = PlayerController.exo.duration
            fraction = if (d > 0) (PlayerController.exo.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(250)
        }
    }
    Canvas(modifier.fillMaxWidth().height(2.dp)) {
        drawRect(Color.White.copy(alpha = 0.25f))
        drawRect(Cl.Red, size = Size(size.width * fraction, size.height))
    }
}

// ---------------------------------------------------------------------------------------------
// Details below the player
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
private fun Details(n: NowPlaying) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val settings by Settings.state.collectAsState()
    val queueNow by PlayerController.queueFlow.collectAsState()
    val progress = rememberWatchProgress()
    var sheet by remember { mutableStateOf(Sheet.NONE) }
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    val listState = rememberLazyListState()
    LaunchedEffect(n.item.url) { listState.scrollToItem(0) }
    val subscribed = n.item.uploaderUrl.isNotBlank() && lib.subscriptions.any { Library.sameChannel(it.url, n.item.uploaderUrl) }
    val inWatchLater = lib.watchLater.any { it.url == n.item.url }
    val downloaded = lib.downloads.any { it.sourceUrl == n.item.url && it.status == app.seek.data.DownloadRecord.STATUS_DONE }

    LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
        // Title + "views · age ...more"
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { sheet = Sheet.DESCRIPTION }
                    .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 10.dp)
            ) {
                Text(
                    n.item.title,
                    color = Cl.Text,
                    fontSize = 18.sp,
                    lineHeight = 24.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val meta = Fmt.meta(n.item)
                    if (meta.isNotBlank()) Text(meta.replace(" · ", "  "), color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    Text("  ...more", color = Cl.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        // Channel row
        if (n.item.uploader.isNotBlank()) item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(enabled = n.item.uploaderUrl.isNotBlank()) { actions.channel(n.item.uploaderUrl) }
                    .padding(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(n.channelAvatar.ifBlank { n.item.uploaderAvatar }, 36.dp)
                Spacer(Modifier.width(12.dp))
                Text(n.item.uploader, color = Cl.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (n.subscriberCount > 0) {
                    Spacer(Modifier.width(8.dp))
                    Text(Fmt.count(n.subscriberCount), color = Cl.TextDim, fontSize = 12.sp, maxLines = 1)
                }
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                if (n.item.uploaderUrl.isNotBlank()) {
                    SubscribeButton(subscribed, onClick = {
                        Library.toggleSubscription(n.item.uploaderUrl, n.item.uploader, n.channelAvatar.ifBlank { n.item.uploaderAvatar })
                        actions.message(if (subscribed) "Unsubscribed" else "Subscribed to ${n.item.uploader}")
                    })
                }
            }
        }

        // Action pills: like | dislike, share, save, download, audio, loop
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { LikePill(n.likes, n.dislikes) }
                item { ActionPill(Icons.Outlined.Share, "Share") { actions.share(n.item.url, n.item.title) } }
                item {
                    ActionPill(
                        if (inWatchLater) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
                        if (inWatchLater) "Saved" else "Save"
                    ) { sheet = Sheet.SAVE }
                }
                if (!n.isLive && !n.isLocal) item {
                    ActionPill(
                        if (downloaded) Icons.Rounded.DownloadDone else Icons.Outlined.FileDownload,
                        if (downloaded) "Downloaded" else "Download"
                    ) { sheet = Sheet.DOWNLOAD }
                }
                if (!n.isLocal) item {
                    ActionPill(Icons.Outlined.Headphones, "Audio only", highlighted = n.audioOnly) {
                        PlayerController.setAudioOnly(!n.audioOnly)
                    }
                }
                item {
                    val loop by PlayerController.loop.collectAsState()
                    ActionPill(Icons.Rounded.Repeat, "Loop", highlighted = loop) { PlayerController.toggleLoop() }
                }
            }
        }

        // SponsorBlock summary
        if (n.segments.isNotEmpty() && settings.sponsorBlock) item {
            val skipping = n.segments.count { it.category in settings.sponsorCategories }
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color(SponsorBlock.color("sponsor"))))
                Spacer(Modifier.width(8.dp))
                Text(
                    "SponsorBlock: ${n.segments.size} segments, auto-skipping $skipping",
                    color = Cl.TextDim, fontSize = 12.sp
                )
            }
        }

        // Comments card with the top comment
        if (!n.isLocal && n.info != null) item { CommentsCard(n.item.url) { sheet = Sheet.COMMENTS } }

        // Playing a playlist / your queue
        if (queueNow.items.size > 1) item(key = "queue") { QueueCard(queueNow) { sheet = Sheet.QUEUE } }

        // Chapters
        val chapters = n.info?.streamSegments.orEmpty()
        if (chapters.isNotEmpty()) {
            item {
                Text("Chapters", color = Cl.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 8.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(chapters) { c ->
                        Column(
                            Modifier
                                .width(150.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { PlayerController.seekTo(c.startTimeSeconds * 1000L) }
                        ) {
                            Thumb(c.previewUrl ?: n.item.thumbnail, corner = 8.dp)
                            Spacer(Modifier.height(6.dp))
                            Text(c.title ?: "", color = Cl.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(Fmt.duration(c.startTimeSeconds.toLong()), color = Cl.Blue, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // Up next: full-width cards, like YouTube on phones
        if (n.related.isNotEmpty()) {
            item { Spacer(Modifier.height(10.dp)) }
            items(n.related, key = { "rel:" + it.url }) { v ->
                VideoCard(
                    v,
                    onClick = { actions.video(v) },
                    progress = progress[v.url] ?: 0f,
                    onChannel = { actions.channel(v.uploaderUrl) },
                    onMore = { menuFor = v }
                )
            }
        }
        if (n.loading) item { Loading() }
        item { Spacer(Modifier.navigationBarsPadding().height(24.dp)) }
    }

    PlayerSheets(n, sheet) { sheet = it }
    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}

/** The grey pill with 👍 count | 👎 inside, split by a thin line. */
@Composable
private fun LikePill(likes: Long, dislikes: Long) {
    Row(
        Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .background(Cl.SurfaceHigh),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(Modifier.padding(start = 14.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.ThumbUp, "Likes", tint = Cl.Text, modifier = Modifier.size(20.dp))
            if (likes > 0) {
                Spacer(Modifier.width(6.dp))
                Text(Fmt.count(likes), color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }
        Box(Modifier.width(1.dp).height(24.dp).background(Cl.SurfaceHighest))
        Row(Modifier.padding(start = 12.dp, end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.ThumbDown, "Dislikes", tint = Cl.Text, modifier = Modifier.size(20.dp))
            if (dislikes > 0) {
                Spacer(Modifier.width(6.dp))
                Text(Fmt.count(dislikes), color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun ActionPill(icon: ImageVector, label: String, highlighted: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .background(if (highlighted) Cl.Text else Cl.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (highlighted) Color.Black else Cl.Text, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = if (highlighted) Color.Black else Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** "Comments" card under the video, showing the top comment. */
@UnstableApi
@Composable
private fun CommentsCard(url: String, onOpen: () -> Unit) {
    val vm: CommentsVm = viewModel(key = "comments-$url") { CommentsVm(url) }
    LaunchedEffect(vm) { vm.start() }
    val top = vm.items.firstOrNull()
    Column(
        Modifier
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Cl.SurfaceHigh)
            .clickable(onClick = onOpen)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Comments", color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            if (vm.items.isNotEmpty()) {
                Spacer(Modifier.width(6.dp))
                Text(if (vm.hasMore) "${vm.items.size}+" else "${vm.items.size}", color = Cl.TextDim, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        when {
            top != null -> Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(top.avatar, 24.dp)
                Spacer(Modifier.width(10.dp))
                Text(top.text, color = Cl.Text, fontSize = 13.sp, lineHeight = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            vm.loading -> Text("Loading comments…", color = Cl.TextDim, fontSize = 13.sp)
            vm.error != null -> Text("Couldn't load comments", color = Cl.TextDim, fontSize = 13.sp)
            else -> Text("No comments (or they're turned off)", color = Cl.TextDim, fontSize = 13.sp)
        }
    }
}

/** YouTube's description panel: title, the three stat boxes, the text and the chapters. */
@UnstableApi
@Composable
private fun DescriptionSheet(n: NowPlaying, onDismiss: () -> Unit) {
    val actions = LocalActions.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Cl.Surface
    ) {
        LazyColumn(Modifier.fillMaxHeight(0.92f)) {
            item {
                Text("Description", color = Cl.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                HorizontalDivider(color = Cl.Outline, modifier = Modifier.padding(top = 8.dp))
                Text(n.item.title, color = Cl.Text, fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StatBox(if (n.likes > 0) Fmt.count(n.likes) else "–", "Likes", Modifier.weight(1f))
                    StatBox(if (n.item.views >= 0) Fmt.count(n.item.views) else "–", if (n.isLive) "Watching" else "Views", Modifier.weight(1f))
                    val ago = Fmt.ago(n.item.uploaded, n.item.uploadedText)
                    StatBox(ago.ifBlank { "–" }, "Uploaded", Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                if (n.description.isNotBlank()) {
                    LinkedText(
                        n.description,
                        color = Cl.Text,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        onTimestamp = if (n.isLive) null else ({ ms: Long ->
                            PlayerController.seekTo(ms)
                            onDismiss()
                        }),
                        onLink = { url ->
                            onDismiss()
                            actions.openLink(url)
                        },
                        onHashtag = { tag ->
                            onDismiss()
                            actions.search(tag)
                        },
                        modifier = Modifier
                            .padding(horizontal = 12.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Cl.SurfaceHigh)
                            .padding(12.dp)
                    )
                }
            }
            val chapters = n.info?.streamSegments.orEmpty()
            if (chapters.isNotEmpty()) {
                item { Text("Chapters", color = Cl.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp)) }
                items(chapters) { c ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                PlayerController.seekTo(c.startTimeSeconds * 1000L)
                                onDismiss()
                            }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(c.previewUrl ?: n.item.thumbnail, Modifier.width(110.dp), corner = 6.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(c.title ?: "", color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(Fmt.duration(c.startTimeSeconds.toLong()), color = Cl.Blue, fontSize = 12.sp)
                        }
                    }
                }
            }
            if (n.item.uploaderUrl.isNotBlank()) item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clickable {
                            onDismiss()
                            actions.channel(n.item.uploaderUrl)
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(n.channelAvatar.ifBlank { n.item.uploaderAvatar }, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(n.item.uploader, color = Cl.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        if (n.subscriberCount > 0) Text(Fmt.subs(n.subscriberCount), color = Cl.TextDim, fontSize = 12.sp)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = Cl.Text)
                }
            }
            item { Spacer(Modifier.navigationBarsPadding().height(16.dp)) }
        }
    }
}

@Composable
private fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Cl.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = Cl.TextDim, fontSize = 12.sp)
    }
}

// ---------------------------------------------------------------------------------------------
// Sheets: settings, quality, speed, captions, sleep, download, comments, save
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
private fun PlayerSheets(n: NowPlaying, sheet: Sheet, setSheet: (Sheet) -> Unit) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val speed by PlayerController.speed.collectAsState()
    val loop by PlayerController.loop.collectAsState()
    val sleepAt by PlayerController.sleepAt.collectAsState()
    val dismiss = { setSheet(Sheet.NONE) }

    when (sheet) {
        Sheet.NONE -> Unit
        Sheet.SAVE -> AddToPlaylistDialog(n.item, onDismiss = dismiss)
        Sheet.COMMENTS -> CommentsSheet(n.item.url, dismiss, creator = n.item.uploader)
        Sheet.DESCRIPTION -> DescriptionSheet(n, dismiss)
        Sheet.QUEUE -> QueueSheet(dismiss)
        else -> ModalBottomSheet(
            onDismissRequest = dismiss,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Cl.Surface
        ) {
            Column(Modifier.navigationBarsPadding().padding(bottom = 12.dp)) {
                when (sheet) {
                    Sheet.SETTINGS -> {
                        if (!n.isLocal) SettingLine(Icons.Rounded.HighQuality, "Quality", if (n.audioOnly) "Audio only" else n.quality?.label ?: "Auto") { setSheet(Sheet.QUALITY) }
                        SettingLine(Icons.Rounded.Speed, "Playback speed", if (speed == 1f) "Normal" else "${speed}x") { setSheet(Sheet.SPEED) }
                        if (n.subtitles.isNotEmpty()) {
                            SettingLine(Icons.Rounded.ClosedCaption, "Captions", n.subtitles.firstOrNull { it.id == n.subtitleId }?.label ?: "Off") { setSheet(Sheet.CAPTIONS) }
                        }
                        SettingLine(Icons.Rounded.Bedtime, "Sleep timer", sleepLabel(sleepAt)) { setSheet(Sheet.SLEEP) }
                        if (!n.audioOnly) {
                            SettingLine(Icons.Rounded.ViewInAr, "View angle", if (ViewAngle.active) "On" else "Off") {
                                ViewAngle.panel = true
                                dismiss()
                            }
                        }
                        if (!n.isLocal) ToggleLine(Icons.Rounded.Headphones, "Audio only", n.audioOnly) { PlayerController.setAudioOnly(it) }
                        ToggleLine(Icons.Rounded.Repeat, "Loop video", loop) { PlayerController.toggleLoop() }
                    }
                    Sheet.QUALITY -> {
                        SheetTitle("Quality")
                        n.qualities.forEach { q ->
                            val selected = !n.audioOnly && q.label == n.quality?.label
                            ChoiceLine(q.label + if (q.stream.fps > 30) "" else "", selected) {
                                PlayerController.setQuality(q)
                                dismiss()
                            }
                        }
                        ChoiceLine("Audio only", n.audioOnly) {
                            PlayerController.setAudioOnly(true)
                            dismiss()
                        }
                    }
                    Sheet.SPEED -> {
                        SheetTitle("Playback speed")
                        listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f).forEach { s ->
                            ChoiceLine(if (s == 1f) "Normal" else "${s}x", speed == s) {
                                PlayerController.setSpeed(s)
                                dismiss()
                            }
                        }
                    }
                    Sheet.CAPTIONS -> {
                        SheetTitle("Captions")
                        ChoiceLine("Off", n.subtitleId == null) {
                            PlayerController.setSubtitle(null)
                            dismiss()
                        }
                        n.subtitles.forEach { s ->
                            ChoiceLine(s.label, n.subtitleId == s.id) {
                                PlayerController.setSubtitle(s.id)
                                dismiss()
                            }
                        }
                    }
                    Sheet.SLEEP -> {
                        SheetTitle("Sleep timer")
                        ChoiceLine("Off", sleepAt == null) { PlayerController.setSleepTimer(null); dismiss() }
                        listOf(10, 15, 30, 45, 60, 90).forEach { m ->
                            ChoiceLine("$m minutes", false) { PlayerController.setSleepTimer(m); dismiss() }
                        }
                        ChoiceLine("End of video", sleepAt == PlayerController.SLEEP_END_OF_VIDEO) {
                            PlayerController.setSleepTimer(-1); dismiss()
                        }
                    }
                    Sheet.DOWNLOAD -> {
                        SheetTitle("Download")
                        val info = n.info
                        if (info == null) {
                            Loading()
                        } else {
                            val options = remember(info) { Downloads.options(info) }
                            if (options.isEmpty()) {
                                Text("No downloadable streams for this video.", color = Cl.TextDim, modifier = Modifier.padding(22.dp))
                            }
                            options.forEach { o ->
                                SheetRow(
                                    if (o.audioOnly) Icons.Rounded.Headphones else Icons.Rounded.Download,
                                    o.label + (if (o.approxBytes > 0) "  •  " + Fmt.bytes(o.approxBytes) else "")
                                ) {
                                    Downloads.start(ctx, info, o, n.item.thumbnail)
                                    actions.message("Downloading ${o.label}")
                                    dismiss()
                                }
                            }
                            Text(
                                "Saved to Downloads/Seek",
                                color = Cl.TextFaint, fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)
                            )
                        }
                    }
                    else -> Unit
                }
            }
        }
    }
}

private fun sleepLabel(at: Long?): String = when {
    at == null -> "Off"
    at == PlayerController.SLEEP_END_OF_VIDEO -> "End of video"
    else -> {
        val mins = ((at - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0)
        "$mins min left"
    }
}

@Composable
private fun SheetTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = Cl.Text, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
    HorizontalDivider(color = Cl.Outline)
}

@Composable
private fun SettingLine(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Cl.Text, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(title, color = Cl.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(value, color = Cl.TextDim, fontSize = 14.sp)
        Icon(Icons.Rounded.ChevronRight, null, tint = Cl.TextDim)
    }
}

@Composable
private fun ToggleLine(icon: ImageVector, title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 22.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Cl.Text, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(title, color = Cl.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Cl.Blue, checkedThumbColor = Color.Black, checkedBorderColor = Cl.Blue,
                uncheckedTrackColor = Cl.SurfaceHighest, uncheckedThumbColor = Cl.TextDim, uncheckedBorderColor = Cl.SurfaceHighest
            )
        )
    }
}

@Composable
private fun ChoiceLine(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selected) Icon(Icons.Rounded.Check, null, tint = Cl.Text) else Spacer(Modifier.width(24.dp))
        Spacer(Modifier.width(20.dp))
        Text(text, color = Cl.Text, fontSize = 15.sp, fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal, modifier = Modifier.weight(1f))
    }
}

@UnstableApi
@Composable
fun CommentsSheet(url: String, onDismiss: () -> Unit, creator: String = "") {
    val actions = LocalActions.current
    val vm: CommentsVm = viewModel(key = "comments-$url") { CommentsVm(url) }
    LaunchedEffect(vm) { vm.start() }
    val listState = rememberLazyListState()
    app.seek.ui.components.EndReached(listState) { vm.loadMore() }
    val now by PlayerController.now.collectAsState()
    // Timestamps only make sense for the video that's actually playing
    val onTimestamp: ((Long) -> Unit)? = if (now?.item?.url == url && now?.isLive != true) ({ ms: Long ->
        PlayerController.seekTo(ms)
        onDismiss()
    }) else null
    val onLink: (String) -> Unit = { u ->
        onDismiss()
        actions.openLink(u)
    }
    LaunchedEffect(vm.sort) { listState.scrollToItem(0) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Cl.Surface
    ) {
        Column(Modifier.fillMaxHeight(0.92f)) {
            Row(Modifier.padding(start = 20.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Comments", color = Cl.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (vm.items.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(if (vm.hasMore) "${vm.items.size}+" else "${vm.items.size}", color = Cl.TextDim, fontSize = 14.sp)
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close", tint = Cl.Text) }
            }
            // Sort, like YouTube's chips
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CommentSort.entries.forEach { s -> Chip(s.label, vm.sort == s, { vm.changeSort(s) }) }
            }
            HorizontalDivider(color = Cl.Outline, modifier = Modifier.padding(top = 4.dp))
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                when {
                    vm.loading && vm.items.isEmpty() -> item { SkeletonComments() }
                    vm.error != null && vm.items.isEmpty() -> item { ErrorBox(vm.error ?: "", onRetry = { vm.reload() }) }
                    vm.items.isEmpty() && vm.started && !vm.loading -> item {
                        Text("No comments (or they're turned off).", color = Cl.TextDim, modifier = Modifier.padding(22.dp))
                    }
                    else -> for (c in vm.items) {
                        item(key = "c:" + c.key) {
                            CommentRow(
                                c,
                                creator = creator,
                                onTimestamp = onTimestamp,
                                onLink = onLink,
                                repliesOpen = vm.replies[c.key]?.open == true,
                                onReplies = { vm.toggleReplies(c) },
                                modifier = Modifier.animateItem()
                            )
                        }
                        val t = vm.replies[c.key]
                        if (t != null && t.open) {
                            items(t.items, key = { r -> "r:" + c.key + ":" + r.key }) { r ->
                                CommentRow(r, creator = creator, onTimestamp = onTimestamp, onLink = onLink, reply = true, modifier = Modifier.animateItem())
                            }
                            when {
                                t.loading -> item(key = "rl:" + c.key) {
                                    Box(Modifier.fillMaxWidth().padding(start = 62.dp, top = 4.dp, bottom = 8.dp)) {
                                        EchoLoader(size = 26.dp)
                                    }
                                }
                                t.failed -> item(key = "rf:" + c.key) {
                                    RepliesLink("Couldn't load replies. Tap to try again") { vm.moreReplies(c) }
                                }
                                t.next != null -> item(key = "rm:" + c.key) {
                                    RepliesLink("Show more replies") { vm.moreReplies(c) }
                                }
                            }
                        }
                    }
                }
                if (vm.loadingMore) item { Loading() }
                item { Spacer(Modifier.navigationBarsPadding().height(16.dp)) }
            }
        }
    }
}

@Composable
private fun RepliesLink(text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .padding(start = 54.dp, bottom = 6.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = Cl.Blue, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, color = Cl.Blue, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CommentRow(
    c: CommentItem,
    creator: String = "",
    onTimestamp: ((Long) -> Unit)? = null,
    onLink: ((String) -> Unit)? = null,
    reply: Boolean = false,
    repliesOpen: Boolean = false,
    onReplies: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var expanded by remember(c.key) { mutableStateOf(false) }
    val long = c.text.length > 320 || c.text.count { it == '\n' } > 6
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = if (reply) 62.dp else 16.dp, end = 16.dp, top = if (reply) 6.dp else 12.dp, bottom = 4.dp)
    ) {
        Avatar(c.avatar, if (reply) 24.dp else 34.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            if (c.pinned) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 3.dp)) {
                    Icon(Icons.Rounded.PushPin, null, tint = Cl.TextDim, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (creator.isNotBlank()) "Pinned by $creator" else "Pinned", color = Cl.TextDim, fontSize = 11.sp)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                // The channel's own comments get YouTube's grey name pill
                Row(
                    Modifier
                        .weight(1f, fill = false)
                        .then(
                            if (c.byCreator) Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Cl.SurfaceHighest)
                                .padding(horizontal = 7.dp, vertical = 1.dp)
                            else Modifier
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        c.author,
                        color = if (c.byCreator) Cl.Text else Cl.TextDim,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (c.verified) {
                        Spacer(Modifier.width(3.dp))
                        Icon(Icons.Rounded.Verified, "Verified", tint = Cl.TextDim, modifier = Modifier.size(12.dp))
                    }
                }
                if (c.ago.isNotBlank()) Text("  •  " + c.ago, color = Cl.TextFaint, fontSize = 12.sp, maxLines = 1)
            }
            Spacer(Modifier.height(3.dp))
            LinkedText(
                c.text,
                color = Cl.Text,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                maxLines = if (long && !expanded) 5 else Int.MAX_VALUE,
                onTimestamp = onTimestamp,
                onLink = onLink
            )
            if (long) {
                Text(
                    if (expanded) "Show less" else "Read more",
                    color = Cl.TextDim,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .padding(top = 2.dp)
                        .clickable { expanded = !expanded }
                        .padding(vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.ThumbUp, null, tint = Cl.TextDim, modifier = Modifier.size(15.dp))
                if (c.likes > 0) {
                    Spacer(Modifier.width(5.dp))
                    Text(Fmt.count(c.likes.toLong()), color = Cl.TextDim, fontSize = 12.sp)
                }
                Spacer(Modifier.width(16.dp))
                Icon(Icons.Outlined.ThumbDown, null, tint = Cl.TextDim, modifier = Modifier.size(15.dp))
                if (c.hearted) {
                    Spacer(Modifier.width(16.dp))
                    Icon(Icons.Rounded.Favorite, "Hearted by the creator", tint = Cl.Red, modifier = Modifier.size(15.dp))
                }
            }
            // Replies: blue, like YouTube; opens them right here under the comment
            if (!reply && c.replies > 0 && onReplies != null) {
                Row(
                    Modifier
                        .padding(top = 4.dp)
                        .offset(x = (-10).dp)
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onReplies)
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (repliesOpen) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                        null, tint = Cl.Blue, modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        when {
                            repliesOpen -> "Hide replies"
                            c.replies == 1 -> "1 reply"
                            else -> "${Fmt.count(c.replies.toLong())} replies"
                        },
                        color = Cl.Blue, fontSize = 13.sp, fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Scrub preview: storyboard frames while dragging the seek bar
// ---------------------------------------------------------------------------------------------

/** The last few storyboard sheets, so scrubbing back and forth doesn't reload them. */
private object Storyboards {
    private val cache = object : LinkedHashMap<String, ImageBitmap>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ImageBitmap>?): Boolean = size > 8
    }

    fun get(url: String): ImageBitmap? = synchronized(cache) { cache[url] }

    suspend fun load(ctx: Context, url: String): ImageBitmap? {
        get(url)?.let { return it }
        return try {
            val req = ImageRequest.Builder(ctx).data(url).allowHardware(false).size(coil.size.Size.ORIGINAL).build()
            val bmp = ((ctx.imageLoader.execute(req) as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap ?: return null
            val img = bmp.asImageBitmap()
            synchronized(cache) { cache[url] = img }
            img
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }
}

/** YouTube's storyboard at the most useful size: the biggest one that's still small. */
private fun pickFrameset(frames: List<Frameset>): Frameset? =
    frames.filter { it.frameWidth in 1..360 && it.durationPerFrame > 0 && it.urls.isNotEmpty() }.maxByOrNull { it.frameWidth }
        ?: frames.filter { it.durationPerFrame > 0 && it.urls.isNotEmpty() }.minByOrNull { it.frameWidth }

@Composable
private fun ScrubPreview(
    frames: List<Frameset>,
    timeMs: Long,
    chapter: String?,
    width: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val set = remember(frames) { pickFrameset(frames) }
    Column(modifier.width(width), horizontalAlignment = Alignment.CenterHorizontally) {
        if (!chapter.isNullOrBlank()) {
            Text(
                chapter,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        if (set != null) {
            val fx = set.framesPerPageX.coerceAtLeast(1)
            val fy = set.framesPerPageY.coerceAtLeast(1)
            val perPage = fx * fy
            val idx = (timeMs / set.durationPerFrame).toInt().coerceIn(0, (set.totalCount - 1).coerceAtLeast(0))
            val page = (idx / perPage).coerceAtMost(set.urls.size - 1)
            val rel = idx % perPage
            val col = rel % fx
            val row = rel / fx
            val url = set.urls[page]
            // Keep showing the last sheet while the next one loads (no flashing)
            var shown by remember { mutableStateOf<Pair<String, ImageBitmap>?>(null) }
            LaunchedEffect(url) {
                val img = Storyboards.load(ctx, url)
                if (img != null) shown = url to img
            }
            val aspect = set.frameWidth.toFloat() / set.frameHeight.coerceAtLeast(1)
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspect)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
                    .border(1.5.dp, Color.White, RoundedCornerShape(8.dp))
            ) {
                val pair = shown
                if (pair != null && pair.first == url) {
                    val img = pair.second
                    Canvas(Modifier.fillMaxSize()) {
                        // Some sheets come back a little smaller than YouTube says: scale to what arrived
                        val scale = if (img.width < fx * set.frameWidth) img.width.toFloat() / (fx * set.frameWidth) else 1f
                        val fw = (set.frameWidth * scale).toInt().coerceAtLeast(1)
                        val fh = (set.frameHeight * scale).toInt().coerceAtLeast(1)
                        val left = (col * fw).coerceAtMost(img.width - 1)
                        val top = (row * fh).coerceAtMost(img.height - 1)
                        drawImage(
                            img,
                            srcOffset = IntOffset(left, top),
                            srcSize = IntSize(fw.coerceAtMost(img.width - left), fh.coerceAtMost(img.height - top)),
                            dstSize = IntSize(size.width.toInt(), size.height.toInt())
                        )
                    }
                } else if (pair != null) {
                    // Previous sheet's first frame is better than nothing; dim it while loading
                    Canvas(Modifier.fillMaxSize()) {
                        drawImage(
                            pair.second,
                            srcOffset = IntOffset.Zero,
                            srcSize = IntSize(set.frameWidth.coerceAtMost(pair.second.width), set.frameHeight.coerceAtMost(pair.second.height)),
                            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                            alpha = 0.5f
                        )
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Text(
            Fmt.durationMs(timeMs),
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

// ---------------------------------------------------------------------------------------------
// View angle: tilt / turn the picture so it looks straight from where you are
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
private fun ViewAnglePanel(fullscreen: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val audio = remember(ctx) { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember(audio) { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var brightness by remember {
        mutableFloatStateOf(activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f)
    }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var noSensor by remember { mutableStateOf(false) }

    AnimatedVisibility(
        visible = ViewAngle.panel,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
        modifier = modifier.zIndex(3f)
    ) {
        Column(
            Modifier
                .then(if (fullscreen) Modifier.width(420.dp) else Modifier.fillMaxWidth())
                .padding(horizontal = if (fullscreen) 0.dp else 8.dp)
                .padding(bottom = 8.dp)
                .navigationBarsPadding()
                .clip(RoundedCornerShape(20.dp))
                .background(Cl.Surface.copy(alpha = if (fullscreen) 0.88f else 0.97f))
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.ViewInAr, null, tint = Cl.Red, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("View angle", color = Cl.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (ViewAngle.auto) "Auto: keeping it straight as you move" else "Tilt until the picture looks straight",
                        color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { ViewAngle.reset() }) { Icon(Icons.Rounded.Restore, "Reset", tint = Cl.Text) }
                IconButton(onClick = { ViewAngle.panel = false }) { Icon(Icons.Rounded.Close, "Close", tint = Cl.Text) }
            }
            Spacer(Modifier.height(4.dp))
            AngleSlider("Tilt", "↕", ViewAngle.tilt, -ViewAngle.MAX, ViewAngle.MAX) { ViewAngle.tilt = it }
            AngleSlider("Turn", "↔", ViewAngle.turn, -ViewAngle.MAX, ViewAngle.MAX) { ViewAngle.turn = it }
            AngleSlider("Brightness", "☀", brightness, 0.01f, 1f, percent = true) { v ->
                brightness = v
                activity?.window?.let { w ->
                    val lp = w.attributes
                    lp.screenBrightness = v
                    w.attributes = lp
                }
            }
            AngleSlider("Volume", "♪", volume, 0f, 1f, percent = true) { v ->
                volume = v
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * maxVol).roundToInt(), 0)
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        if (ViewAngle.auto) ViewAngle.stopAuto() else noSensor = !ViewAngle.startAuto(ctx)
                    }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Auto", color = Cl.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(
                        if (noSensor) "This phone has no motion sensor for this" else "Uses the phone's motion sensor. Set it, then shift around",
                        color = Cl.TextDim, fontSize = 12.sp
                    )
                }
                if (ViewAngle.auto) {
                    Text(
                        "Re-center",
                        color = Cl.Blue,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { ViewAngle.recenter() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
                Switch(
                    checked = ViewAngle.auto,
                    onCheckedChange = { on -> if (on) noSensor = !ViewAngle.startAuto(ctx) else ViewAngle.stopAuto() },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Cl.Red, checkedThumbColor = Color.White, checkedBorderColor = Cl.Red,
                        uncheckedTrackColor = Cl.SurfaceHighest, uncheckedThumbColor = Cl.TextDim, uncheckedBorderColor = Cl.SurfaceHighest
                    )
                )
            }
        }
    }
}

@Composable
private fun AngleSlider(
    label: String,
    glyph: String,
    value: Float,
    min: Float,
    max: Float,
    percent: Boolean = false,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(glyph, color = Cl.TextDim, fontSize = 15.sp, modifier = Modifier.width(22.dp))
        Text(label, color = Cl.Text, fontSize = 14.sp, modifier = Modifier.width(84.dp))
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Cl.Red,
                inactiveTrackColor = Cl.SurfaceHighest,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            ),
            modifier = Modifier.weight(1f).height(36.dp)
        )
        Text(
            if (percent) "${(value * 100).roundToInt()}%" else "${value.roundToInt()}°",
            color = Cl.TextDim,
            fontSize = 12.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(42.dp)
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Queue
// ---------------------------------------------------------------------------------------------

/** "Up next in your queue" card under the actions. */
@UnstableApi
@Composable
private fun QueueCard(q: PlayerController.Queue, onOpen: () -> Unit) {
    val next = q.upNext.firstOrNull()
    Row(
        Modifier
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Cl.SurfaceHigh)
            .pressClick(scale = 0.98f, onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (next != null) {
            Thumb(next.thumbnail, Modifier.width(88.dp), corner = 6.dp)
            Spacer(Modifier.width(12.dp))
        } else {
            Icon(Icons.AutoMirrored.Rounded.PlaylistPlay, null, tint = Cl.Text)
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                q.name.ifBlank { "Your queue" } + "  ·  ${q.index + 1} / ${q.items.size}",
                color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (next != null) "Next: " + next.title else "End of the queue",
                color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
        Icon(Icons.Rounded.KeyboardArrowUp, "Open queue", tint = Cl.Text)
    }
}

@UnstableApi
@Composable
private fun QueueSheet(onDismiss: () -> Unit) {
    val q by PlayerController.queueFlow.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val state = rememberLazyListState()
    // Keys that survive reordering: the video plus which copy of it this is
    val keys = remember(q.items) {
        val seen = HashMap<String, Int>()
        q.items.map { v ->
            val k = (seen[v.url] ?: 0) + 1
            seen[v.url] = k
            v.url + "#" + k
        }
    }
    val keysNow by rememberUpdatedState(keys)
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    var rowH by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(Unit) { if (q.index > 0) state.scrollToItem(q.index) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Cl.Surface
    ) {
        Row(Modifier.padding(start = 20.dp, end = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(q.name.ifBlank { "Queue" }, color = Cl.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${q.upNext.size} up next", color = Cl.TextDim, fontSize = 13.sp)
            }
            if (q.upNext.isNotEmpty()) {
                IconButton(onClick = { PlayerController.clearUpNext() }) {
                    Icon(Icons.Rounded.ClearAll, "Clear up next", tint = Cl.Text)
                }
            }
            IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Close", tint = Cl.Text) }
        }
        HorizontalDivider(color = Cl.Outline)
        if (q.items.isEmpty()) {
            Text(
                "Nothing queued. Use Play next or Add to queue on any video's ⋮ menu.",
                color = Cl.TextDim, fontSize = 14.sp, modifier = Modifier.padding(22.dp)
            )
        }
        LazyColumn(state = state, modifier = Modifier.heightIn(max = 560.dp).navigationBarsPadding()) {
            itemsIndexed(q.items, key = { i, _ -> keys.getOrElse(i) { "q$i" } }) { i, v ->
                val key = keys.getOrElse(i) { "q$i" }
                val current = i == q.index
                val dragging = dragKey == key
                Row(
                    Modifier
                        .then(if (dragging) Modifier else Modifier.animateItem())
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                        .onSizeChanged { rowH = it.height.toFloat().coerceAtLeast(1f) }
                        .fillMaxWidth()
                        .background(
                            when {
                                dragging -> Cl.SurfaceHighest
                                current -> Color.White.copy(alpha = 0.06f)
                                else -> Cl.Surface
                            }
                        )
                        .clickable { PlayerController.playFromQueue(i) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Drag handle: hold and move up / down to reorder
                    Box(
                        Modifier
                            .size(width = 40.dp, height = 50.dp)
                            .pointerInput(key) {
                                var at = -1
                                detectVerticalDragGestures(
                                    onDragStart = {
                                        at = keysNow.indexOf(key)
                                        dragKey = key
                                        dragOffset = 0f
                                    },
                                    onDragEnd = { dragKey = null; dragOffset = 0f },
                                    onDragCancel = { dragKey = null; dragOffset = 0f }
                                ) { change, dy ->
                                    change.consume()
                                    if (at < 0) return@detectVerticalDragGestures
                                    dragOffset += dy
                                    val last = keysNow.size - 1
                                    if (dragOffset > rowH / 2 && at < last) {
                                        PlayerController.moveInQueue(at, at + 1)
                                        at++
                                        dragOffset -= rowH
                                    } else if (dragOffset < -rowH / 2 && at > 0) {
                                        PlayerController.moveInQueue(at, at - 1)
                                        at--
                                        dragOffset += rowH
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.DragHandle, "Drag to reorder", tint = if (dragging) Cl.Text else Cl.TextFaint, modifier = Modifier.size(22.dp))
                    }
                    Box(Modifier.width(112.dp)) {
                        Thumb(v.thumbnail, Modifier.fillMaxWidth(), duration = v.duration, corner = 6.dp)
                        if (current) {
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black.copy(alpha = 0.55f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(v.title, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (v.uploader.isNotBlank()) Text(v.uploader, color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (!current) {
                        IconButton(onClick = { PlayerController.removeFromQueue(i) }) {
                            Icon(Icons.Rounded.Close, "Remove from queue", tint = Cl.TextDim, modifier = Modifier.size(20.dp))
                        }
                    } else Spacer(Modifier.width(48.dp))
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}
