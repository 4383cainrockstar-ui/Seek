package app.seek.player

import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * "Keep playing during calls". Normally ExoPlayer handles audio focus and pauses for any
 * interruption, phone calls included. With this on, focus is handled here instead:
 *  - a call (phone, WhatsApp, Discord…) or any other short interruption turns the music down
 *    instead of pausing it, and it comes back up when the call ends
 *  - another music or video app taking over still pauses us, like normal
 */
class CallFocus(ctx: Context, private val player: ExoPlayer, private val attrs: AudioAttributes) {
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var enabled = false
    private var hasFocus = false
    private var ducked = false

    private val listener = AudioManager.OnAudioFocusChangeListener { change -> main.post { onChange(change) } }

    private val request: AudioFocusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(
                        if (attrs.contentType == C.AUDIO_CONTENT_TYPE_MOVIE) android.media.AudioAttributes.CONTENT_TYPE_MOVIE
                        else android.media.AudioAttributes.CONTENT_TYPE_MUSIC
                    )
                    .build()
            )
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener(listener, main)
            .build()
    }

    private val playListener = object : Player.Listener {
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (enabled && playWhenReady) grab()
        }
    }

    init {
        player.addListener(playListener)
    }

    /** Turns the call-friendly mode on or off (hands focus back to ExoPlayer when off). */
    fun setEnabled(on: Boolean) {
        if (on == enabled) return
        enabled = on
        if (on) {
            player.setAudioAttributes(attrs, false)
            if (player.playWhenReady) grab()
        } else {
            release()
            unduck()
            player.setAudioAttributes(attrs, true)
        }
    }

    private fun grab() {
        if (hasFocus) return
        val r = try {
            am?.requestAudioFocus(request) ?: AudioManager.AUDIOFOCUS_REQUEST_FAILED
        } catch (_: Exception) {
            AudioManager.AUDIOFOCUS_REQUEST_FAILED
        }
        hasFocus = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        if (hasFocus) unduck()
        // During a call the request can be refused: keep playing quietly and watch for the call to end
        else if (inCall()) {
            duck()
            watchCall()
        } else unduck()
    }

    private fun release() {
        try {
            am?.abandonAudioFocusRequest(request)
        } catch (_: Exception) {
        }
        hasFocus = false
    }

    private fun onChange(change: Int) {
        if (!enabled) return
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                hasFocus = true
                unduck()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Calls, navigation, the assistant: turn down, don't stop. Android hands focus
                // back (AUDIOFOCUS_GAIN) when they're done.
                duck()
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                hasFocus = false
                // Some calling apps take focus for good. Give the phone a moment to switch into
                // call mode, then: a call -> keep playing quietly; another media app -> pause.
                duck()
                main.postDelayed({
                    if (!enabled) return@postDelayed
                    if (inCall()) watchCall()
                    else {
                        unduck()
                        player.pause()
                    }
                }, 700)
            }
        }
    }

    private fun inCall(): Boolean = when (am?.mode) {
        AudioManager.MODE_IN_CALL, AudioManager.MODE_IN_COMMUNICATION, AudioManager.MODE_RINGTONE -> true
        else -> false
    }

    private var watching = false

    /** After a call took focus for good: checks every couple of seconds whether it's over. */
    private fun watchCall() {
        if (watching) return
        watching = true
        main.postDelayed(object : Runnable {
            override fun run() {
                if (!enabled) {
                    watching = false
                    return
                }
                if (inCall()) {
                    main.postDelayed(this, 2000)
                    return
                }
                watching = false
                if (player.playWhenReady) grab() else unduck()
            }
        }, 2000)
    }

    private fun duck() {
        ducked = true
        player.volume = DUCKED
    }

    private fun unduck() {
        ducked = false
        player.volume = 1f
    }

    companion object {
        private const val DUCKED = 0.3f
    }
}
