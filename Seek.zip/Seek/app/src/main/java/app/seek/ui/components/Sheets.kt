package app.seek.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AddToQueue
import androidx.compose.material.icons.rounded.QueuePlayNext
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.WatchLater
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.seek.core.VideoItem
import app.seek.data.Library
import app.seek.player.PlayerController
import app.seek.ui.LocalActions
import app.seek.ui.theme.Cl

@Composable
fun SheetRow(icon: ImageVector, text: String, tint: androidx.compose.ui.graphics.Color = Cl.Text, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(20.dp))
        Text(text, color = tint, fontSize = 16.sp)
    }
}

/** Long-press / ⋮ menu for any video. */
@UnstableApi
@Composable
fun VideoActionsSheet(
    video: VideoItem,
    onDismiss: () -> Unit,
    onRemove: (() -> Unit)? = null,
    removeLabel: String = "Remove"
) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var showPlaylists by remember { mutableStateOf(false) }
    val inWatchLater = lib.watchLater.any { it.url == video.url }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Cl.Surface
    ) {
        Column(Modifier.navigationBarsPadding().padding(bottom = 8.dp)) {
            Text(
                video.title,
                color = Cl.Text,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)
            )
            HorizontalDivider(color = Cl.Outline, modifier = Modifier.padding(vertical = 6.dp))
            if (!video.isShort) {
                SheetRow(Icons.Rounded.QueuePlayNext, "Play next in queue") {
                    val idle = PlayerController.now.value == null
                    PlayerController.queueNext(video)
                    actions.message(if (idle) "Playing" else "Playing next")
                    if (idle) actions.openPlayer()
                    onDismiss()
                }
                SheetRow(Icons.Rounded.AddToQueue, "Add to queue") {
                    val idle = PlayerController.now.value == null
                    PlayerController.addToQueue(video)
                    actions.message(if (idle) "Playing" else "Added to queue")
                    if (idle) actions.openPlayer()
                    onDismiss()
                }
            }
            SheetRow(Icons.Rounded.Headphones, "Play as audio") {
                PlayerController.play(video, audioOnly = true)
                actions.openPlayer()
                onDismiss()
            }
            SheetRow(
                if (inWatchLater) Icons.Rounded.Check else Icons.Rounded.WatchLater,
                if (inWatchLater) "Remove from Watch later" else "Save to Watch later"
            ) {
                Library.toggleWatchLater(video)
                actions.message(if (inWatchLater) "Removed from Watch later" else "Saved to Watch later")
                onDismiss()
            }
            SheetRow(Icons.AutoMirrored.Rounded.PlaylistAdd, "Save to playlist") { showPlaylists = true }
            if (video.uploaderUrl.isNotBlank()) {
                SheetRow(Icons.Rounded.AccountCircle, "Go to channel") {
                    onDismiss()
                    actions.channel(video.uploaderUrl)
                }
            }
            SheetRow(Icons.Rounded.Share, "Share") {
                actions.share(video.url, video.title)
                onDismiss()
            }
            if (onRemove != null) {
                SheetRow(Icons.Rounded.Delete, removeLabel) {
                    onRemove()
                    onDismiss()
                }
            }
        }
    }

    if (showPlaylists) {
        AddToPlaylistDialog(video, onDismiss = {
            showPlaylists = false
            onDismiss()
        })
    }
}

@UnstableApi
@Composable
fun AddToPlaylistDialog(video: VideoItem, onDismiss: () -> Unit) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Cl.Surface,
        title = { Text("Save to…", color = Cl.Text) },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 280.dp)) {
                    item {
                        val inWl = lib.watchLater.any { it.url == video.url }
                        SheetRow(if (inWl) Icons.Rounded.Check else Icons.Rounded.WatchLater, "Watch later", Cl.Text) {
                            if (!inWl) Library.toggleWatchLater(video)
                            actions.message("Saved to Watch later")
                            onDismiss()
                        }
                    }
                    items(lib.playlists, key = { it.id }) { p ->
                        val has = p.items.any { it.url == video.url }
                        SheetRow(
                            if (has) Icons.Rounded.Check else Icons.AutoMirrored.Rounded.PlaylistAdd,
                            p.name,
                            Cl.Text
                        ) {
                            Library.addToPlaylist(p.id, video)
                            actions.message("Added to ${p.name}")
                            onDismiss()
                        }
                    }
                }
                Spacer(Modifier.size(8.dp))
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("New playlist name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cl.Blue,
                        unfocusedBorderColor = Cl.SurfaceHighest,
                        focusedTextColor = Cl.Text,
                        unfocusedTextColor = Cl.Text,
                        cursorColor = Cl.Blue
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = newName.isNotBlank(),
                onClick = {
                    Library.createPlaylist(newName, video)
                    actions.message("Created ${newName.trim()}")
                    onDismiss()
                }
            ) {
                Icon(Icons.Rounded.Add, null, tint = Cl.Blue, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Create", color = Cl.Blue, fontWeight = FontWeight.Medium)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = Cl.TextDim) } }
    )
}
