package app.seek.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.ServiceList
import java.io.ByteArrayInputStream

@Serializable
data class SeekBackup(
    val app: String = "Seek",
    val version: Int = 1,
    val exportedAt: Long = 0,
    val settings: AppSettings = AppSettings(),
    val library: LibraryData = LibraryData()
)

/** Import/export: NewPipe subscriptions JSON, YouTube Takeout (CSV/ZIP), and full Seek backups (Clipse backups restore too). */
object ImportExport {

    /** Returns how many new subscriptions were added. Detects the format automatically. */
    suspend fun importSubscriptions(ctx: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Couldn't open that file")
        val name = (uri.lastPathSegment ?: "").lowercase()
        val head = String(bytes, 0, minOf(bytes.size, 512), Charsets.UTF_8).trimStart()

        val subs: List<Subscription> = when {
            bytes.size > 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte() ->
                fromExtractor(bytes, "zip")
            head.startsWith("{") || head.startsWith("[") -> parseJson(String(bytes, Charsets.UTF_8))
            name.endsWith(".csv") || head.contains(",") -> fromExtractor(bytes, "csv")
            else -> throw IllegalStateException("Unrecognised file. Use a NewPipe .json or a Takeout .csv/.zip")
        }
        if (subs.isEmpty()) throw IllegalStateException("No subscriptions found in that file")
        Library.addSubscriptions(subs)
    }

    private fun fromExtractor(bytes: ByteArray, type: String): List<Subscription> {
        val items = ServiceList.YouTube.subscriptionExtractor
            .fromInputStream(ByteArrayInputStream(bytes), type)
        return items.filter { it.url().isNotBlank() }.map { Subscription(url = it.url(), name = it.name() ?: "") }
    }

    private fun parseJson(text: String): List<Subscription> {
        val trimmed = text.trimStart()
        // Seek / Clipse backup dropped into the subscription importer: take its subs
        if (trimmed.startsWith("{")) {
            val obj = JSONObject(trimmed)
            if (obj.has("library")) {
                val lib = obj.getJSONObject("library")
                return arr(lib.optJSONArray("subscriptions")).map {
                    Subscription(it.optString("url"), it.optString("name"), it.optString("avatar"), it.optString("group"))
                }
            }
            // NewPipe format: {"app_version":..,"subscriptions":[{"service_id":0,"url":..,"name":..}]}
            return arr(obj.optJSONArray("subscriptions"))
                .filter { it.optInt("service_id", 0) == 0 }
                .map { Subscription(it.optString("url"), it.optString("name")) }
                .filter { it.url.isNotBlank() }
        }
        // Old Takeout JSON array -> let the extractor handle it
        return fromExtractor(text.toByteArray(), "json")
    }

    private fun arr(a: JSONArray?): List<JSONObject> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    }

    /** NewPipe-compatible export so you can move back and forth between apps. */
    suspend fun exportSubscriptions(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val list = JSONArray()
        Library.value.subscriptions.forEach {
            list.put(JSONObject().put("service_id", 0).put("url", it.url).put("name", it.name))
        }
        val root = JSONObject()
            .put("app_version", "0.27.0")
            .put("app_version_int", 1000)
            .put("subscriptions", list)
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(root.toString(2).toByteArray()) }
            ?: throw IllegalStateException("Couldn't write that file")
    }

    suspend fun exportBackup(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val backup = SeekBackup(
            exportedAt = System.currentTimeMillis(),
            settings = Settings.current,
            library = Library.value
        )
        val text = LibraryJson.json.encodeToString(SeekBackup.serializer(), backup)
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) }
            ?: throw IllegalStateException("Couldn't write that file")
    }

    suspend fun importBackup(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalStateException("Couldn't open that file")
        val backup = LibraryJson.json.decodeFromString(SeekBackup.serializer(), text)
        if (backup.app != "Seek" && backup.app != "Clipse") throw IllegalStateException("That isn't a Seek backup")
        Settings.replace(backup.settings)
        // Keep download records pointing at files on this device
        Library.replaceAll(backup.library.copy(downloads = Library.value.downloads))
    }
}
