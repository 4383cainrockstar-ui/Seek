package app.seek.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.seek.core.Fmt
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.DownloadRecord
import app.seek.data.Library
import app.seek.download.Downloads
import app.seek.player.PlayerController
import app.seek.ui.LocalActions
import app.seek.ui.components.EmptyState
import app.seek.ui.components.SheetRow
import app.seek.ui.components.Thumb
import app.seek.ui.components.TopBar
import app.seek.ui.theme.Cl
import kotlinx.coroutines.launch

@UnstableApi
@Composable
fun DownloadsScreen() {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val lib by Library.data.collectAsState()
    val scope = rememberCoroutineScope()
    var menuFor by remember { mutableStateOf<DownloadRecord?>(null) }

    fun playLocal(r: DownloadRecord) {
        val item = VideoItem(url = r.sourceUrl.ifBlank { r.fileUri }, title = r.title, thumbnail = r.thumbnail)
        PlayerController.playLocal(item, Uri.parse(r.fileUri), r.audioOnly)
        actions.openPlayer()
    }

    fun retry(r: DownloadRecord) {
        scope.launch {
            try {
                actions.message("Retrying ${r.title}")
                Downloads.retry(ctx, r)
            } catch (e: Exception) {
                actions.message(Yt.friendlyError(e))
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Downloads", onBack = { actions.back() })
        if (lib.downloads.isEmpty()) {
            EmptyState(
                Icons.Rounded.Download,
                "No downloads",
                "Hit Download under any video. Files go to Downloads/Seek and play offline right here."
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(lib.downloads, key = { it.id }) { r ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                when (r.status) {
                                    DownloadRecord.STATUS_DONE -> playLocal(r)
                                    DownloadRecord.STATUS_FAILED -> retry(r)
                                    else -> Unit
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(r.thumbnail, Modifier.width(130.dp), corner = 10.dp, badge = if (r.audioOnly) "Audio" else null)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.title, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(3.dp))
                            val status = when (r.status) {
                                DownloadRecord.STATUS_DONE -> listOf(r.quality, Fmt.bytes(r.sizeBytes)).filter { it.isNotBlank() }.joinToString(" • ")
                                DownloadRecord.STATUS_RUNNING -> "Downloading " + (r.progress * 100).toInt() + "%"
                                DownloadRecord.STATUS_QUEUED -> "Waiting…"
                                else -> r.error.ifBlank { "Failed" } + " • tap to retry"
                            }
                            Text(
                                status,
                                color = if (r.status == DownloadRecord.STATUS_FAILED) Cl.Red else Cl.TextDim,
                                fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            if (r.status == DownloadRecord.STATUS_RUNNING || r.status == DownloadRecord.STATUS_QUEUED) {
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { r.progress },
                                    color = Cl.Red,
                                    trackColor = Cl.SurfaceHigh,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(Cl.SurfaceHigh)
                                )
                            }
                        }
                        IconButton(onClick = { menuFor = r }) { Icon(Icons.Rounded.MoreVert, "More", tint = Cl.TextDim) }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    menuFor?.let { r ->
        ModalBottomSheet(
            onDismissRequest = { menuFor = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Cl.Surface
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(r.title, color = Cl.Text, fontWeight = FontWeight.SemiBold, maxLines = 2, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp))
                HorizontalDivider(color = Cl.Outline)
                if (r.status == DownloadRecord.STATUS_DONE) {
                    SheetRow(Icons.Rounded.PlayArrow, "Play in Seek") { menuFor = null; playLocal(r) }
                    SheetRow(Icons.AutoMirrored.Rounded.OpenInNew, "Open with another app") {
                        menuFor = null
                        actions.openUri(Uri.parse(r.fileUri), if (r.audioOnly) "audio/mp4" else "video/mp4")
                    }
                }
                if (r.status == DownloadRecord.STATUS_FAILED) {
                    SheetRow(Icons.Rounded.Refresh, "Retry") { menuFor = null; retry(r) }
                }
                SheetRow(Icons.Rounded.Delete, if (r.status == DownloadRecord.STATUS_DONE) "Remove from list (keeps the file)" else "Remove", tint = Cl.Red) {
                    Library.removeDownload(r.id)
                    menuFor = null
                }
            }
        }
    }
}
