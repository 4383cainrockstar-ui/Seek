package app.seek.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.seek.core.ChannelDetails
import app.seek.core.Fmt
import app.seek.core.ListEntry
import app.seek.core.Paged
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.ui.LocalActions
import app.seek.ui.components.Avatar
import app.seek.ui.components.PlaylistRow
import app.seek.ui.components.ShortTile
import app.seek.ui.components.TopBar
import app.seek.ui.components.EmptyState
import app.seek.ui.components.EndReached
import app.seek.ui.components.ErrorBox
import app.seek.ui.components.Loading
import app.seek.ui.components.PagerVm
import app.seek.ui.components.SubscribeButton
import app.seek.ui.components.Thumb
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import app.seek.core.ChannelItem
import app.seek.core.YtWeb
import app.seek.ui.components.Chip
import app.seek.ui.components.SkeletonShortsGrid
import app.seek.ui.components.SkeletonVideoCards
import app.seek.ui.components.pressClick
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler

class ChannelVm(private val url: String) : ViewModel() {
    var details by mutableStateOf<ChannelDetails?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun load() {
        if (details != null || loading) return
        loading = true
        error = null
        viewModelScope.launch {
            try {
                val d = Yt.channel(url)
                details = d
                if (Library.isSubscribed(url) || Library.isSubscribed(d.channel.url)) {
                    Library.updateSubscriptionMeta(d.channel.url, d.channel.name, d.channel.avatar)
                }
            } catch (e: Exception) {
                error = Yt.friendlyError(e)
            } finally {
                loading = false
            }
        }
    }

    fun retry() {
        details = null
        load()
    }
}

class TabVm(private val handler: ListLinkHandler) : PagerVm<ListEntry>() {
    override suspend fun first(): Paged<ListEntry> = Yt.tab(handler)
    override suspend fun more(page: Page): Paged<ListEntry> = Yt.tabMore(handler, page)
    override fun keyOf(item: ListEntry): Any = item.key
}

/** A channel's videos fetched straight from YouTube: sorted (Popular / Oldest) or a search. */
class ChannelVideosVm(
    private val channel: ChannelItem,
    private val firstPage: suspend () -> Paged<VideoItem>
) : PagerVm<ListEntry>() {
    override suspend fun first(): Paged<ListEntry> = firstPage().let { p -> Paged(p.items.map { ListEntry.Video(it) }, p.next) }
    override suspend fun more(page: Page): Paged<ListEntry> =
        YtWeb.more(page, channel).let { p -> Paged(p.items.map { ListEntry.Video(it) }, p.next) }
    override fun keyOf(item: ListEntry): Any = item.key
}

private const val ABOUT = "about"

private fun tabLabel(t: String) = when (t) {
    ChannelTabs.VIDEOS -> "Videos"
    ChannelTabs.SHORTS -> "Shorts"
    ChannelTabs.LIVESTREAMS -> "Live"
    ChannelTabs.PLAYLISTS -> "Playlists"
    ChannelTabs.PODCASTS -> "Podcasts"
    ChannelTabs.ALBUMS -> "Albums"
    ChannelTabs.CHANNELS -> "Channels"
    ABOUT -> "About"
    else -> t.replaceFirstChar { it.uppercase() }
}

@UnstableApi
@Composable
fun ChannelScreen(url: String) {
    val actions = LocalActions.current
    val vm: ChannelVm = viewModel(key = "channel-$url") { ChannelVm(url) }
    LaunchedEffect(vm) { vm.load() }
    val lib by Library.data.collectAsState()
    val d = vm.details

    Box(Modifier.fillMaxSize()) {
        when {
            d == null && vm.error != null -> Column(Modifier.statusBarsPadding()) {
                IconButton(onClick = { actions.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Cl.Text) }
                ErrorBox(vm.error ?: "", onRetry = { vm.retry() })
            }
            d == null -> Column(Modifier.statusBarsPadding()) {
                IconButton(onClick = { actions.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Cl.Text) }
                Loading()
            }
            else -> ChannelContent(d, subscribed = lib.subscriptions.any { Library.sameChannel(it.url, d.channel.url) })
        }
    }
}

@UnstableApi
@Composable
private fun ChannelContent(d: ChannelDetails, subscribed: Boolean) {
    val actions = LocalActions.current
    val tabNames = remember(d) {
        val preferred = listOf(ChannelTabs.VIDEOS, ChannelTabs.SHORTS, ChannelTabs.LIVESTREAMS, ChannelTabs.PLAYLISTS, ChannelTabs.PODCASTS)
        preferred.filter { it in d.tabs.keys } + (d.tabs.keys - preferred.toSet()).filter { it != ChannelTabs.CHANNELS } + ABOUT
    }
    var tab by rememberSaveable { mutableStateOf(tabNames.first()) }
    var sort by rememberSaveable { mutableStateOf(YtWeb.ChannelSort.LATEST) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var results by rememberSaveable { mutableStateOf("") }
    val handler = d.tabs[tab]
    val gridState = rememberLazyGridState()
    val progress = rememberWatchProgress()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    val channelId = d.info.id ?: ""
    val sortable = channelId.isNotBlank() && YtWeb.canSort(tab)

    // Which list is showing: a search inside the channel, a sorted tab, or the tab as-is
    val tabVm: PagerVm<ListEntry>? = when {
        results.isNotBlank() && channelId.isNotBlank() ->
            viewModel<ChannelVideosVm>(key = "csearch-${d.channel.url}-$results") {
                ChannelVideosVm(d.channel) { YtWeb.channelSearch(channelId, results, d.channel) }
            }
        sortable && sort != YtWeb.ChannelSort.LATEST ->
            viewModel<ChannelVideosVm>(key = "sort-${d.channel.url}-$tab-$sort") {
                ChannelVideosVm(d.channel) { YtWeb.channelTabSorted(channelId, tab, sort, d.channel) }
            }
        handler != null -> viewModel<TabVm>(key = "tab-${d.channel.url}-$tab") { TabVm(handler) }
        else -> null
    }
    // Back to the top when you switch sort / search, but not when coming back to the page
    val listKey = "$tab|$sort|$results"
    var shownKey by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(tabVm, listKey) {
        tabVm?.start()
        if (shownKey.isNotEmpty() && shownKey != listKey) gridState.scrollToItem(0)
        shownKey = listKey
    }
    EndReached(gridState) { tabVm?.loadMore() }
    BackHandler(enabled = searching) {
        searching = false
        results = ""
        query = ""
    }

    Column(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = searching,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "channel-top"
        ) { s ->
            if (s) {
                ChannelSearchBar(
                    channel = d.channel.name,
                    query = query,
                    onQuery = { query = it },
                    onSearch = { if (query.isNotBlank()) results = query.trim() },
                    onClose = {
                        searching = false
                        results = ""
                        query = ""
                    }
                )
            } else {
                TopBar(d.channel.name, onBack = { actions.back() }) {
                    IconButton(onClick = { searching = true }) { Icon(Icons.Rounded.Search, "Search this channel", tint = Cl.Text) }
                    IconButton(onClick = { actions.share(d.channel.url, d.channel.name) }) { Icon(Icons.Rounded.Share, "Share", tint = Cl.Text) }
                }
            }
        }

        // 6 columns: videos span all 6, Shorts span 2 (three across), like YouTube
        LazyVerticalGrid(
            columns = GridCells.Fixed(6),
            state = gridState,
            contentPadding = PaddingValues(bottom = 32.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (results.isNotBlank()) item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Results for “$results”",
                    color = Cl.TextDim,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            } else item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    if (d.banner.isNotBlank()) {
                        AsyncImage(
                            d.banner, null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                .fillMaxWidth()
                                .aspectRatio(6.2f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Cl.SurfaceHigh)
                        )
                    }
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(d.channel.avatar, 72.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.channel.name, color = Cl.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 28.sp)
                            if (d.channel.subscribers > 0) {
                                Spacer(Modifier.height(4.dp))
                                Text(Fmt.subs(d.channel.subscribers), color = Cl.TextDim, fontSize = 12.sp)
                            }
                        }
                    }
                    if (d.channel.description.isNotBlank()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { tab = ABOUT }
                                .padding(horizontal = 12.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                d.channel.description.lineSequence().firstOrNull { it.isNotBlank() } ?: "",
                                color = Cl.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Icon(Icons.Rounded.ChevronRight, null, tint = Cl.Text, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    SubscribeButton(
                        subscribed,
                        onClick = {
                            Library.toggleSubscription(d.channel.url, d.channel.name, d.channel.avatar)
                            actions.message(if (subscribed) "Unsubscribed" else "Subscribed to ${d.channel.name}")
                        },
                        modifier = Modifier
                            .padding(horizontal = 12.dp)
                            .fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    TabStrip(tabNames.map { tabLabel(it) }, tabNames.indexOf(tab)) {
                        tab = tabNames[it]
                        sort = YtWeb.ChannelSort.LATEST
                    }
                    // Latest / Popular / Oldest, like on YouTube
                    if (sortable && tab != ABOUT) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(YtWeb.ChannelSort.entries.toList()) { o -> Chip(o.label, sort == o, { sort = o }) }
                        }
                    } else Spacer(Modifier.height(10.dp))
                }
            }

            if (tab == ABOUT && results.isBlank()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Text("Description", color = Cl.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            d.channel.description.ifBlank { "No description." },
                            color = Cl.Text, fontSize = 14.sp, lineHeight = 21.sp
                        )
                        val tags = d.info.tags
                        if (tags.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            Text(tags.joinToString("  ") { "#$it" }, color = Cl.Blue, fontSize = 13.sp)
                        }
                        if (d.channel.subscribers > 0) {
                            Spacer(Modifier.height(16.dp))
                            Text(Fmt.subs(d.channel.subscribers), color = Cl.TextDim, fontSize = 14.sp)
                        }
                    }
                }
            } else if (tabVm != null) {
                when {
                    tabVm.loading && tabVm.items.isEmpty() -> item(span = { GridItemSpan(maxLineSpan) }) {
                        if (tab == ChannelTabs.SHORTS && results.isBlank()) SkeletonShortsGrid() else SkeletonVideoCards(2)
                    }
                    tabVm.error != null && tabVm.items.isEmpty() -> item(span = { GridItemSpan(maxLineSpan) }) {
                        ErrorBox(tabVm.error ?: "", onRetry = { tabVm.reload() })
                    }
                    tabVm.items.isEmpty() && tabVm.started -> item(span = { GridItemSpan(maxLineSpan) }) {
                        if (results.isNotBlank()) EmptyState(Icons.Rounded.Search, "No results", "Nothing on ${d.channel.name} matches “$results”.")
                        else EmptyState(Icons.Rounded.VideoLibrary, "Nothing here yet", "This channel hasn't posted anything in this tab.")
                    }
                    else -> {
                        val shortsTab = tab == ChannelTabs.SHORTS && results.isBlank()
                        val shortList = if (shortsTab) tabVm.items.filterIsInstance<ListEntry.Video>().map { it.item } else emptyList()
                        items(
                            tabVm.items,
                            key = { it.key },
                            span = { e -> GridItemSpan(if (shortsTab && e is ListEntry.Video) 2 else maxLineSpan) }
                        ) { e ->
                            when (e) {
                                is ListEntry.Video -> if (shortsTab) {
                                    ShortTile(
                                        e.item,
                                        onClick = { actions.shorts(shortList, shortList.indexOfFirst { it.url == e.item.url }) },
                                        modifier = Modifier.padding(1.dp),
                                        onMore = { menuFor = e.item }
                                    )
                                } else {
                                    ChannelVideo(
                                        e.item,
                                        progress[e.item.url] ?: 0f,
                                        onClick = { actions.video(e.item) },
                                        onMore = { menuFor = e.item }
                                    )
                                }
                                is ListEntry.Playlist -> PlaylistRow(e.item, onClick = { actions.playlist(e.item.url) })
                                is ListEntry.Channel -> Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable { actions.channel(e.item.url) }
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Avatar(e.item.avatar, 40.dp)
                                    Spacer(Modifier.width(14.dp))
                                    Column {
                                        Text(e.item.name, color = Cl.Text, fontSize = 15.sp)
                                        if (e.item.subscribers > 0) Text(Fmt.subs(e.item.subscribers), color = Cl.TextDim, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                if (tabVm.loadingMore) item(span = { GridItemSpan(maxLineSpan) }) { Loading() }
            }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}

/** YouTube's text tabs with the white underline. */
@Composable
private fun TabStrip(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column {
        LazyRow(contentPadding = PaddingValues(horizontal = 4.dp)) {
            items(labels.size) { i ->
                val on = i == selected
                Column(
                    Modifier
                        .clickable { onSelect(i) }
                        .padding(horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        labels[i],
                        color = if (on) Cl.Text else Cl.TextDim,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier
                            .width(if (on) 36.dp else 0.dp)
                            .height(2.dp)
                            .background(Cl.Text)
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Cl.Outline))
    }
}

/** A channel's video: full-width thumbnail, title and "views · age", no avatar. */
@Composable
private fun ChannelVideo(v: VideoItem, progress: Float, onClick: () -> Unit, onMore: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .pressClick(scale = 0.985f, onLongClick = onMore, onClick = onClick)
            .padding(bottom = 16.dp)
    ) {
        Thumb(v.thumbnail, Modifier.fillMaxWidth(), duration = v.duration, isLive = v.isLive, progress = progress, corner = 0.dp)
        Row(Modifier.padding(start = 12.dp, top = 10.dp)) {
            Column(Modifier.weight(1f)) {
                Text(v.title, color = Cl.Text, fontSize = 16.sp, lineHeight = 21.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val meta = Fmt.meta(v)
                if (meta.isNotBlank()) {
                    Spacer(Modifier.height(3.dp))
                    Text(meta, color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            IconButton(onClick = onMore, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Rounded.MoreVert, "More", tint = Cl.Text, modifier = Modifier.size(20.dp))
            }
        }
    }
}

/** The channel's top bar while searching inside it. */
@Composable
private fun ChannelSearchBar(
    channel: String,
    query: String,
    onQuery: (String) -> Unit,
    onSearch: () -> Unit,
    onClose: () -> Unit
) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    LaunchedEffect(Unit) { focus.requestFocus() }
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Close search", tint = Cl.Text) }
        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Search $channel", color = Cl.TextDim, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp),
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { onQuery(""); focus.requestFocus() }) {
                    Icon(Icons.Rounded.Close, "Clear", tint = Cl.Text)
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                onSearch()
            }),
            shape = RoundedCornerShape(50),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Cl.SurfaceHigh,
                unfocusedContainerColor = Cl.SurfaceHigh,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Cl.Text,
                unfocusedTextColor = Cl.Text,
                cursorColor = Cl.Blue
            ),
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .focusRequester(focus)
        )
    }
}
