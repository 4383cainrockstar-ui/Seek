package app.seek.player

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sin

/**
 * How the video sits on screen: zoom (pinch to fill) and the view angle (tilt / turn) that
 * pre-skews the picture so it looks straight when you're looking at the phone from an angle,
 * like lying down.
 *
 * Everything here is Compose state that's read only inside the video's graphics layer, so
 * moving a slider or the gyro updating 60 times a second redraws just the video, nothing else.
 */
object ViewAngle {
    const val MAX = 40f

    /** Your manual angles, in degrees. Tilt = top/bottom, turn = left/right. */
    var tilt by mutableFloatStateOf(0f)
    var turn by mutableFloatStateOf(0f)

    /** Extra angle from the motion sensor while Auto is on. */
    var autoTilt by mutableFloatStateOf(0f)
        private set
    var autoTurn by mutableFloatStateOf(0f)
        private set

    var auto by mutableStateOf(false)
        private set

    /** Whether the View angle panel is open on the player. */
    var panel by mutableStateOf(false)

    /** Pinch zoom: 1 = whole video, [fillScale] = zoomed to fill the screen. */
    var zoom by mutableFloatStateOf(1f)
    var filled by mutableStateOf(false)

    val rotationX: Float get() = (tilt + autoTilt).coerceIn(-MAX, MAX)
    val rotationY: Float get() = (turn + autoTurn).coerceIn(-MAX, MAX)
    val active: Boolean get() = abs(tilt) > 0.5f || abs(turn) > 0.5f || auto

    /** Shrinks the picture a little as it tilts, so the near edge doesn't get cut off. */
    fun fitScale(): Float {
        val sx = abs(sin(Math.toRadians(rotationX.toDouble()))).toFloat()
        val sy = abs(sin(Math.toRadians(rotationY.toDouble()))).toFloat()
        return 1f / (1f + 0.42f * (sx + sy))
    }

    fun reset() {
        tilt = 0f
        turn = 0f
        stopAuto()
    }

    // ---------------------------------------------------------------------------------------------
    // Auto: keeps the picture facing you as the phone moves
    // ---------------------------------------------------------------------------------------------

    private var sensors: SensorManager? = null
    private var windows: WindowManager? = null
    private var baseAlpha = Float.NaN
    private var baseBeta = Float.NaN
    private var smoothTilt = 0f
    private var smoothTurn = 0f

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            // "Up" in the phone's frame, turned into the screen's frame (landscape swaps axes)
            var x = e.values[0]
            var y = e.values[1]
            val z = e.values[2]
            @Suppress("DEPRECATION")
            when (windows?.defaultDisplay?.rotation ?: Surface.ROTATION_0) {
                Surface.ROTATION_90 -> { val t = x; x = -y; y = t }
                Surface.ROTATION_180 -> { x = -x; y = -y }
                Surface.ROTATION_270 -> { val t = x; x = y; y = -t }
            }
            // Where your eyes are relative to the screen, assuming they stay put while the phone
            // moves: alpha = toward the top edge, beta = toward the right edge
            val alpha = Math.toDegrees(atan2(-y.toDouble(), -z.toDouble())).toFloat()
            val beta = Math.toDegrees(atan2(-x.toDouble(), -z.toDouble())).toFloat()
            if (baseAlpha.isNaN()) {
                baseAlpha = alpha
                baseBeta = beta
            }
            // Eyes moving toward the top: the top looks bigger, so push it back (+rotationX).
            // Eyes moving toward the right: the right looks bigger, so push it back (-rotationY).
            val targetTilt = wrap(alpha - baseAlpha).coerceIn(-MAX, MAX)
            val targetTurn = (-wrap(beta - baseBeta)).coerceIn(-MAX, MAX)
            smoothTilt += (targetTilt - smoothTilt) * 0.18f
            smoothTurn += (targetTurn - smoothTurn) * 0.18f
            autoTilt = smoothTilt
            autoTurn = smoothTurn
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }

    private fun wrap(d: Float): Float {
        var v = d
        while (v > 180f) v -= 360f
        while (v < -180f) v += 360f
        return v
    }

    /** Turns Auto on: from now on, moving the phone adjusts the angle to keep the picture straight. */
    fun startAuto(ctx: Context): Boolean {
        val sm = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return false
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return false
        stopAuto()
        sensors = sm
        windows = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        baseAlpha = Float.NaN
        baseBeta = Float.NaN
        smoothTilt = 0f
        smoothTurn = 0f
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        auto = true
        return true
    }

    /** Turns Auto off and folds whatever it had added into the manual angles (no jump). */
    fun stopAuto() {
        sensors?.unregisterListener(listener)
        sensors = null
        if (auto) {
            tilt = (tilt + autoTilt).coerceIn(-MAX, MAX)
            turn = (turn + autoTurn).coerceIn(-MAX, MAX)
        }
        autoTilt = 0f
        autoTurn = 0f
        auto = false
    }

    /** Re-centres Auto on where the phone is right now. */
    fun recenter() {
        if (!auto) return
        tilt = (tilt + autoTilt).coerceIn(-MAX, MAX)
        turn = (turn + autoTurn).coerceIn(-MAX, MAX)
        baseAlpha = Float.NaN
        baseBeta = Float.NaN
        smoothTilt = 0f
        smoothTurn = 0f
        autoTilt = 0f
        autoTurn = 0f
    }
}
