package app.seek.data

import android.content.Context
import app.seek.core.VideoItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

object LibraryJson {
    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        encodeDefaults = true
        isLenient = true
    }
}

@Serializable
data class Subscription(
    val url: String,
    val name: String,
    val avatar: String = "",
    val group: String = "",
    val addedAt: Long = 0
)

@Serializable
data class HistoryEntry(
    val video: VideoItem,
    val watchedAt: Long,
    val positionMs: Long = 0,
    val durationMs: Long = 0
)

@Serializable
data class LocalPlaylist(
    val id: String,
    val name: String,
    val items: List<VideoItem> = emptyList(),
    val createdAt: Long = 0
)

@Serializable
data class DownloadRecord(
    val id: String,
    val title: String,
    val thumbnail: String = "",
    val sourceUrl: String = "",
    val audioOnly: Boolean = false,
    val quality: String = "",
    val status: String = STATUS_QUEUED,
    val progress: Float = 0f,
    val fileUri: String = "",
    val fileName: String = "",
    val sizeBytes: Long = 0,
    val error: String = "",
    val createdAt: Long = 0
) {
    companion object {
        const val STATUS_QUEUED = "queued"
        const val STATUS_RUNNING = "running"
        const val STATUS_DONE = "done"
        const val STATUS_FAILED = "failed"
    }
}

@Serializable
data class LibraryData(
    val subscriptions: List<Subscription> = emptyList(),
    val history: List<HistoryEntry> = emptyList(),
    val playlists: List<LocalPlaylist> = emptyList(),
    val watchLater: List<VideoItem> = emptyList(),
    val searchHistory: List<String> = emptyList(),
    val feed: List<VideoItem> = emptyList(),
    val feedUpdatedAt: Long = 0,
    val downloads: List<DownloadRecord> = emptyList(),
    val version: Int = 1
)

/**
 * Everything Seek remembers lives in one JSON file. Small, fast, trivially backed up.
 * State is a StateFlow so the UI recomposes on change; writes are debounced to disk.
 */
@OptIn(FlowPreview::class)
object Library {
    private const val MAX_HISTORY = 3000
    private const val MAX_FEED = 1500
    private const val MAX_SEARCH = 50

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var file: File
    private val _data = MutableStateFlow(LibraryData())
    val data: StateFlow<LibraryData> = _data.asStateFlow()
    val value: LibraryData get() = _data.value

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "library.json")
        val tmp = File(ctx.filesDir, "library.json.tmp")
        val source = when {
            file.exists() -> file
            tmp.exists() -> tmp
            else -> null
        }
        if (source != null) {
            _data.value = try {
                LibraryJson.json.decodeFromString(LibraryData.serializer(), source.readText())
            } catch (e: Exception) {
                LibraryData()
            }
        }
        _data.drop(1).debounce(400).onEach { save(it) }.launchIn(scope)
    }

    @Synchronized
    private fun save(d: LibraryData) {
        try {
            val tmp = File(file.parentFile, "library.json.tmp")
            tmp.writeText(LibraryJson.json.encodeToString(LibraryData.serializer(), d))
            if (!tmp.renameTo(file)) {
                file.writeText(tmp.readText())
                tmp.delete()
            }
        } catch (_: Exception) {
        }
    }

    fun flushNow() = save(_data.value)

    fun replaceAll(d: LibraryData) = _data.update { d }

    // ---------------- Subscriptions ----------------

    fun isSubscribed(url: String): Boolean = value.subscriptions.any { sameChannel(it.url, url) }

    fun sameChannel(a: String, b: String): Boolean =
        a.trimEnd('/').substringAfterLast('/') == b.trimEnd('/').substringAfterLast('/') || a == b

    fun subscribe(url: String, name: String, avatar: String) = _data.update { d ->
        if (d.subscriptions.any { sameChannel(it.url, url) }) d
        else d.copy(subscriptions = d.subscriptions + Subscription(url, name, avatar, "", System.currentTimeMillis()))
    }

    fun unsubscribe(url: String) = _data.update { d ->
        d.copy(
            subscriptions = d.subscriptions.filterNot { sameChannel(it.url, url) },
            feed = d.feed.filterNot { sameChannel(it.uploaderUrl, url) }
        )
    }

    fun toggleSubscription(url: String, name: String, avatar: String) {
        if (isSubscribed(url)) unsubscribe(url) else subscribe(url, name, avatar)
    }

    fun setGroup(url: String, group: String) = _data.update { d ->
        d.copy(subscriptions = d.subscriptions.map { if (it.url == url) it.copy(group = group.trim()) else it })
    }

    fun updateSubscriptionMeta(url: String, name: String, avatar: String) = _data.update { d ->
        d.copy(subscriptions = d.subscriptions.map {
            if (sameChannel(it.url, url)) it.copy(
                name = name.ifBlank { it.name },
                avatar = avatar.ifBlank { it.avatar }
            ) else it
        })
    }

    fun addSubscriptions(items: List<Subscription>): Int {
        var added = 0
        _data.update { d ->
            val existing = d.subscriptions.toMutableList()
            for (s in items) {
                if (existing.none { sameChannel(it.url, s.url) }) {
                    existing += s.copy(addedAt = if (s.addedAt == 0L) System.currentTimeMillis() else s.addedAt)
                    added++
                }
            }
            d.copy(subscriptions = existing)
        }
        return added
    }

    fun groups(): List<String> =
        value.subscriptions.map { it.group }.filter { it.isNotBlank() }.distinct().sorted()

    // ---------------- Feed ----------------

    fun setFeed(items: List<VideoItem>) = _data.update { d ->
        d.copy(
            feed = items.distinctBy { it.url }.sortedByDescending { it.uploaded }.take(MAX_FEED),
            feedUpdatedAt = System.currentTimeMillis()
        )
    }

    // ---------------- History ----------------

    fun addHistory(v: VideoItem) {
        if (Settings.current.pauseHistory) return
        _data.update { d ->
            val old = d.history.firstOrNull { it.video.url == v.url }
            val entry = HistoryEntry(
                video = v,
                watchedAt = System.currentTimeMillis(),
                positionMs = old?.positionMs ?: 0,
                durationMs = old?.durationMs ?: 0
            )
            d.copy(history = (listOf(entry) + d.history.filterNot { it.video.url == v.url }).take(MAX_HISTORY))
        }
    }

    fun saveProgress(url: String, positionMs: Long, durationMs: Long) {
        if (Settings.current.pauseHistory) return
        _data.update { d ->
            d.copy(history = d.history.map {
                if (it.video.url == url) it.copy(positionMs = positionMs, durationMs = durationMs) else it
            })
        }
    }

    fun progressFor(url: String): HistoryEntry? = value.history.firstOrNull { it.video.url == url }

    fun watchedUrls(): Set<String> = value.history
        .filter { it.durationMs > 0 && it.positionMs > it.durationMs * 0.9 }
        .map { it.video.url }.toSet()

    fun removeHistory(url: String) = _data.update { d ->
        d.copy(history = d.history.filterNot { it.video.url == url })
    }

    fun clearHistory() = _data.update { it.copy(history = emptyList()) }

    // ---------------- Search history ----------------

    fun addSearch(q: String) {
        if (!Settings.current.saveSearchHistory || q.isBlank()) return
        _data.update { d ->
            d.copy(searchHistory = (listOf(q.trim()) + d.searchHistory.filterNot { it.equals(q.trim(), true) }).take(MAX_SEARCH))
        }
    }

    fun removeSearch(q: String) = _data.update { d -> d.copy(searchHistory = d.searchHistory - q) }

    fun clearSearches() = _data.update { it.copy(searchHistory = emptyList()) }

    // ---------------- Watch later ----------------

    fun inWatchLater(url: String) = value.watchLater.any { it.url == url }

    fun toggleWatchLater(v: VideoItem) = _data.update { d ->
        if (d.watchLater.any { it.url == v.url }) d.copy(watchLater = d.watchLater.filterNot { it.url == v.url })
        else d.copy(watchLater = listOf(v) + d.watchLater)
    }

    fun removeWatchLater(url: String) = _data.update { d -> d.copy(watchLater = d.watchLater.filterNot { it.url == url }) }

    // ---------------- Playlists ----------------

    fun createPlaylist(name: String, first: VideoItem? = null): String {
        val id = UUID.randomUUID().toString()
        _data.update { d ->
            d.copy(playlists = d.playlists + LocalPlaylist(id, name.trim().ifBlank { "My playlist" }, listOfNotNull(first), System.currentTimeMillis()))
        }
        return id
    }

    fun renamePlaylist(id: String, name: String) = _data.update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(name = name) else it })
    }

    fun deletePlaylist(id: String) = _data.update { d -> d.copy(playlists = d.playlists.filterNot { it.id == id }) }

    fun addToPlaylist(id: String, v: VideoItem) = _data.update { d ->
        d.copy(playlists = d.playlists.map {
            if (it.id == id && it.items.none { x -> x.url == v.url }) it.copy(items = it.items + v) else it
        })
    }

    fun removeFromPlaylist(id: String, url: String) = _data.update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(items = it.items.filterNot { x -> x.url == url }) else it })
    }

    fun moveInPlaylist(id: String, from: Int, to: Int) = _data.update { d ->
        d.copy(playlists = d.playlists.map {
            if (it.id != id || from !in it.items.indices || to !in it.items.indices) it
            else {
                val list = it.items.toMutableList()
                val x = list.removeAt(from)
                list.add(to, x)
                it.copy(items = list)
            }
        })
    }

    // ---------------- Downloads ----------------

    fun upsertDownload(r: DownloadRecord) = _data.update { d ->
        if (d.downloads.any { it.id == r.id }) d.copy(downloads = d.downloads.map { if (it.id == r.id) r else it })
        else d.copy(downloads = listOf(r) + d.downloads)
    }

    fun updateDownload(id: String, block: (DownloadRecord) -> DownloadRecord) = _data.update { d ->
        d.copy(downloads = d.downloads.map { if (it.id == id) block(it) else it })
    }

    fun removeDownload(id: String) = _data.update { d -> d.copy(downloads = d.downloads.filterNot { it.id == id }) }
}
