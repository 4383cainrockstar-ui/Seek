package app.seek.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.seek.BuildConfig
import app.seek.core.Yt
import app.seek.data.AppSettings
import app.seek.data.ImportExport
import app.seek.data.Library
import app.seek.data.Settings
import app.seek.extras.SponsorBlock
import app.seek.feed.FeedRepository
import app.seek.feed.FeedWorker
import app.seek.ui.LocalActions
import app.seek.ui.components.Logo
import app.seek.ui.components.TopBar
import app.seek.ui.theme.Cl
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@UnstableApi
@Composable
fun SettingsScreen() {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val s by Settings.state.collectAsState()
    val lib by Library.data.collectAsState()
    val scope = rememberCoroutineScope()
    var picker by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }

    fun upd(block: (AppSettings) -> AppSettings) = Settings.update(block)

    val importSubs = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val added = ImportExport.importSubscriptions(ctx, uri)
                actions.message("Imported $added new subscriptions. Refreshing feed…")
                FeedRepository.refresh()
            } catch (e: Exception) {
                actions.message(e.message ?: Yt.friendlyError(e))
            }
        }
    }
    val exportSubs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                ImportExport.exportSubscriptions(ctx, uri)
                actions.message("Exported ${Library.value.subscriptions.size} subscriptions")
            } catch (e: Exception) {
                actions.message(e.message ?: Yt.friendlyError(e))
            }
        }
    }
    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                ImportExport.exportBackup(ctx, uri)
                actions.message("Backup saved")
            } catch (e: Exception) {
                actions.message(e.message ?: Yt.friendlyError(e))
            }
        }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                ImportExport.importBackup(ctx, uri)
                FeedWorker.schedule(ctx)
                actions.message("Backup restored")
            } catch (e: Exception) {
                actions.message(e.message ?: Yt.friendlyError(e))
            }
        }
    }
    val stamp = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", onBack = { actions.back() })
        LazyColumn(Modifier.fillMaxSize()) {
            item { Section("Player") }
            item { Choice("Default quality", qualityLabel(s.defaultQuality)) { picker = "quality" } }
            item { Choice("Default speed", if (s.defaultSpeed == 1f) "Normal" else "${s.defaultSpeed}x") { picker = "speed" } }
            item { Toggle("Autoplay next video", "Plays something related when a video ends", s.autoplay) { v -> upd { it.copy(autoplay = v) } } }
            item { Toggle("Start in audio-only mode", "Saves data; great for music and podcasts", s.audioOnlyDefault) { v -> upd { it.copy(audioOnlyDefault = v) } } }
            item { Toggle("Resume where you left off", null, s.resumePlayback) { v -> upd { it.copy(resumePlayback = v) } } }
            item { Toggle("Keep playing during calls", "Video keeps going, turned down, while you're on a call", s.keepDuringCalls) { v -> upd { it.copy(keepDuringCalls = v) } } }

            item { Section("Captions") }
            item { Toggle("Turn captions on automatically", "Uses your phone's language when available", s.captionsByDefault) { v -> upd { it.copy(captionsByDefault = v) } } }
            item { Toggle("Caption background", "Off = outlined text", s.captionBackground) { v -> upd { it.copy(captionBackground = v) } } }
            item {
                SliderLine("Caption size", "${(s.captionScale * 100).toInt()}%", s.captionScale, 0.6f..2f) { v ->
                    upd { it.copy(captionScale = (v * 10).toInt() / 10f) }
                }
            }

            item { Section("Feed") }
            item { Toggle("Hide Shorts", null, s.hideShorts) { v -> upd { it.copy(hideShorts = v) } } }
            item { Toggle("Hide watched videos", null, s.hideWatched) { v -> upd { it.copy(hideWatched = v) } } }
            item {
                Choice(
                    "Hide videos shorter than",
                    if (s.minDurationMinutes == 0) "Off" else "${s.minDurationMinutes} min"
                ) { picker = "duration" }
            }
            item {
                Toggle(
                    "Detailed feed",
                    "Slower refresh, but includes durations and live info (needed for the length filter)",
                    s.detailedFeed
                ) { v -> upd { it.copy(detailedFeed = v) } }
            }
            item {
                Toggle("Refresh in the background", "Checks for new uploads every few hours", s.backgroundRefresh) { v ->
                    upd { it.copy(backgroundRefresh = v) }
                    FeedWorker.schedule(ctx)
                }
            }
            item { Toggle("Notify me about new videos", null, s.newVideoNotifications) { v -> upd { it.copy(newVideoNotifications = v) } } }

            item { Section("SponsorBlock") }
            item { Toggle("Skip sponsored segments", "Community-submitted segments from sponsor.ajay.app", s.sponsorBlock) { v -> upd { it.copy(sponsorBlock = v) } } }
            SponsorBlock.categories.forEach { c ->
                item(key = "sb-" + c.key) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = s.sponsorBlock) {
                                val on = c.key in s.sponsorCategories
                                upd { it.copy(sponsorCategories = if (on) it.sponsorCategories - c.key else it.sponsorCategories + c.key) }
                            }
                            .padding(start = 36.dp, end = 16.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(Color(c.color)))
                        Spacer(Modifier.width(14.dp))
                        Text(c.label, color = if (s.sponsorBlock) Cl.Text else Cl.TextFaint, modifier = Modifier.weight(1f))
                        Switch(
                            checked = c.key in s.sponsorCategories,
                            enabled = s.sponsorBlock,
                            onCheckedChange = { on ->
                                upd { it.copy(sponsorCategories = if (on) it.sponsorCategories + c.key else it.sponsorCategories - c.key) }
                            },
                            colors = switchColors()
                        )
                    }
                }
            }
            item { Toggle("Show dislike counts", "From Return YouTube Dislike", s.returnDislikes) { v -> upd { it.copy(returnDislikes = v) } } }

            item { Section("Your data") }
            item { Action("Import subscriptions", "NewPipe .json or YouTube Takeout .csv / .zip") { importSubs.launch(arrayOf("*/*")) } }
            item { Action("Export subscriptions", "NewPipe-compatible .json") { exportSubs.launch("seek-subscriptions-$stamp.json") } }
            item { Action("Back up everything", "Subscriptions, history, playlists, watch later, settings") { exportBackup.launch("seek-backup-$stamp.json") } }
            item { Action("Restore a backup", "Replaces what's on this phone") { confirm = "restore" } }

            item { Section("Privacy") }
            item { Toggle("Pause watch history", null, s.pauseHistory) { v -> upd { it.copy(pauseHistory = v) } } }
            item { Toggle("Save search history", null, s.saveSearchHistory) { v -> upd { it.copy(saveSearchHistory = v) } } }
            item { Action("Clear search history", "${lib.searchHistory.size} searches") { Library.clearSearches(); actions.message("Search history cleared") } }
            item { Action("Clear watch history", "${lib.history.size} videos") { confirm = "history" } }

            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Logo(size = 24)
                    Spacer(Modifier.height(6.dp))
                    Text("Version ${BuildConfig.VERSION_NAME}", color = Cl.TextDim, fontSize = 13.sp)
                    Text("Powered by NewPipe Extractor, SponsorBlock & Return YouTube Dislike", color = Cl.TextFaint, fontSize = 12.sp)
                    Text("Zero ads. Zero accounts. Everything stays on your phone.", color = Cl.TextFaint, fontSize = 12.sp)
                }
            }
        }
    }

    when (picker) {
        "quality" -> PickerDialog("Default quality", Settings.qualityOptions.map { qualityLabel(it) }, qualityLabel(s.defaultQuality), { picker = null }) { label ->
            val q = Settings.qualityOptions.firstOrNull { qualityLabel(it) == label } ?: 720
            upd { it.copy(defaultQuality = q) }
            picker = null
        }
        "speed" -> {
            val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
            PickerDialog("Default speed", speeds.map { if (it == 1f) "Normal" else "${it}x" }, if (s.defaultSpeed == 1f) "Normal" else "${s.defaultSpeed}x", { picker = null }) { label ->
                val v = speeds.firstOrNull { (if (it == 1f) "Normal" else "${it}x") == label } ?: 1f
                upd { it.copy(defaultSpeed = v) }
                app.seek.player.PlayerController.setSpeed(v)
                picker = null
            }
        }
        "duration" -> {
            val opts = listOf(0, 1, 2, 3, 5, 10, 20)
            PickerDialog("Hide videos shorter than", opts.map { if (it == 0) "Off" else "$it min" }, if (s.minDurationMinutes == 0) "Off" else "${s.minDurationMinutes} min", { picker = null }) { label ->
                val v = opts.firstOrNull { (if (it == 0) "Off" else "$it min") == label } ?: 0
                upd { it.copy(minDurationMinutes = v) }
                picker = null
            }
        }
        else -> Unit
    }

    when (confirm) {
        "history" -> ConfirmDialog("Clear watch history?", "This also forgets where you left off in every video.", "Clear", { confirm = null }) {
            Library.clearHistory()
            confirm = null
        }
        "restore" -> ConfirmDialog("Restore a backup?", "Your current subscriptions, history and playlists will be replaced by the backup.", "Choose file", { confirm = null }) {
            confirm = null
            importBackup.launch(arrayOf("application/json", "*/*"))
        }
        else -> Unit
    }
}

private fun qualityLabel(q: Int) = when (q) {
    2160 -> "2160p (4K)"
    1440 -> "1440p"
    else -> "${q}p"
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedTrackColor = Cl.Blue, checkedThumbColor = Color.Black, checkedBorderColor = Cl.Blue,
    uncheckedTrackColor = Cl.SurfaceHighest, uncheckedThumbColor = Cl.TextDim, uncheckedBorderColor = Cl.SurfaceHighest
)

@Composable
private fun Section(title: String) {
    Text(
        title,
        color = Cl.TextDim,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 6.dp)
    )
}

@Composable
private fun Toggle(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Cl.Text, fontSize = 15.sp)
            if (sub != null) Text(sub, color = Cl.TextDim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, colors = switchColors())
    }
}

@Composable
private fun Choice(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Cl.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(value, color = Cl.TextDim, fontSize = 14.sp)
    }
}

@Composable
private fun Action(title: String, sub: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(title, color = Cl.Text, fontSize = 15.sp)
        Text(sub, color = Cl.TextDim, fontSize = 12.sp)
    }
}

@Composable
private fun SliderLine(title: String, value: String, current: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Cl.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(value, color = Cl.TextDim, fontSize = 14.sp)
        }
        Slider(
            value = current,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Cl.Red, activeTrackColor = Cl.Red, inactiveTrackColor = Cl.SurfaceHighest)
        )
    }
}

@Composable
private fun PickerDialog(title: String, options: List<String>, selected: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Cl.Surface,
        title = { Text(title, color = Cl.Text) },
        text = {
            Column {
                options.forEach { o ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onPick(o) }
                            .padding(vertical = 12.dp, horizontal = 8.dp)
                    ) {
                        Text(o, color = if (o == selected) Cl.Blue else Cl.Text, fontWeight = if (o == selected) FontWeight.Medium else FontWeight.Normal)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Cl.TextDim) } }
    )
}

@Composable
private fun ConfirmDialog(title: String, body: String, confirmText: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Cl.Surface,
        title = { Text(title, color = Cl.Text) },
        text = { Text(body, color = Cl.TextDim) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmText, color = Cl.Blue, fontWeight = FontWeight.Medium) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Cl.TextDim) } }
    )
}
