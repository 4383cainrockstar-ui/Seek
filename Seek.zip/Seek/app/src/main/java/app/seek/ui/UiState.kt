package app.seek.ui

import app.seek.core.VideoItem
import kotlinx.coroutines.flow.MutableStateFlow

/** Small bits of app-wide UI state shared between the Activity and Compose. */
object UiState {
    val inPip = MutableStateFlow(false)
    val onPlayerScreen = MutableStateFlow(false)

    /** Shorts to open the Shorts tab with (tapped on a Shorts shelf), starting at [index]. */
    val shortsStart = MutableStateFlow<ShortsStart?>(null)

    data class ShortsStart(val items: List<VideoItem>, val index: Int)

    /** A navigation request coming from outside Compose (links, notifications). */
    val pending = MutableStateFlow<Pending?>(null)

    sealed interface Pending {
        data class Link(val url: String) : Pending
        data object OpenPlayer : Pending
        data object OpenDownloads : Pending
    }
}
