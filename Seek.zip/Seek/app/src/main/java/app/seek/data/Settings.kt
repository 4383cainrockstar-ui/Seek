package app.seek.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable

@Serializable
data class AppSettings(
    // Player
    val defaultQuality: Int = 720,
    val autoplay: Boolean = true,
    val audioOnlyDefault: Boolean = false,
    val resumePlayback: Boolean = true,
    val defaultSpeed: Float = 1f,
    /** Keep playing (turned down) during phone and app calls instead of pausing. */
    val keepDuringCalls: Boolean = false,
    // Captions
    val captionsByDefault: Boolean = false,
    val captionScale: Float = 1f,
    val captionBackground: Boolean = true,
    // Feed
    val hideShorts: Boolean = false,
    val hideWatched: Boolean = false,
    val minDurationMinutes: Int = 0,
    val detailedFeed: Boolean = false,
    val backgroundRefresh: Boolean = true,
    val newVideoNotifications: Boolean = true,
    // Extras
    val sponsorBlock: Boolean = true,
    val sponsorCategories: Set<String> = setOf("sponsor", "selfpromo", "interaction"),
    val returnDislikes: Boolean = true,
    // Privacy
    val pauseHistory: Boolean = false,
    val saveSearchHistory: Boolean = true,
    // Downloads
    val downloadQuality: Int = 720
)

object Settings {
    private const val KEY = "settings_json"
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state.asStateFlow()
    val current: AppSettings get() = _state.value

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("clipse", Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, null)
        if (raw != null) {
            _state.value = try {
                LibraryJson.json.decodeFromString(AppSettings.serializer(), raw)
            } catch (e: Exception) {
                AppSettings()
            }
        }
    }

    fun update(block: (AppSettings) -> AppSettings) {
        val next = block(_state.value)
        _state.value = next
        prefs.edit().putString(KEY, LibraryJson.json.encodeToString(AppSettings.serializer(), next)).apply()
    }

    fun replace(s: AppSettings) = update { s }

    val qualityOptions = listOf(144, 240, 360, 480, 720, 1080, 1440, 2160)
}
