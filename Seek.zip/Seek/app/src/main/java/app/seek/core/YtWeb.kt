package app.seek.core

import com.grack.nanojson.JsonObject
import com.grack.nanojson.JsonWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeReelInfoItemExtractor
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamInfoItemExtractor
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamInfoItemLockupExtractor
import org.schabi.newpipe.extractor.stream.StreamInfoItemsCollector
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

/**
 * The few things the extractor doesn't do, asked of YouTube directly (same web API and client
 * version the extractor itself uses):
 *  - comments sorted "Newest first"
 *  - a channel's videos sorted Latest / Popular / Oldest
 *  - searching inside one channel
 */
object YtWeb {

    /** One of a channel tab's sort chips. */
    data class SortChip(val label: String, val token: String)

    /** The order a channel tab can be sorted in. Index matches YouTube's chip order. */
    enum class ChannelSort(val label: String) { LATEST("Latest"), POPULAR("Popular"), OLDEST("Oldest") }

    private val yt get() = ServiceList.YouTube
    private val newestTokens = ConcurrentHashMap<String, String>()
    private val sortChips = ConcurrentHashMap<String, List<SortChip>>()

    // ---------------------------------------------------------------------------------------------
    // Plumbing
    // ---------------------------------------------------------------------------------------------

    private fun post(endpoint: String, build: (com.grack.nanojson.JsonBuilder<JsonObject>) -> Unit): JsonObject {
        val loc = NewPipe.getPreferredLocalization()
        val builder = YoutubeParsingHelper.prepareDesktopJsonBuilder(loc, NewPipe.getPreferredContentCountry())
        build(builder)
        val body = JsonWriter.string(builder.done()).toByteArray(StandardCharsets.UTF_8)
        return YoutubeParsingHelper.getJsonPostResponse(endpoint, body, loc)
    }

    /** First value under [key] anywhere inside [node] (depth first). */
    private fun find(node: Any?, key: String): Any? {
        when (node) {
            is Map<*, *> -> {
                node[key]?.let { return it }
                for (v in node.values) find(v, key)?.let { return it }
            }
            is List<*> -> for (v in node) find(v, key)?.let { return it }
        }
        return null
    }

    /** The continuation token inside [node], if any. */
    private fun tokenIn(node: Any?): String? = find(find(node, "continuationCommand"), "token") as? String

    /** Readable text of a YouTube text object: simpleText, runs, or a plain "content" string. */
    private fun textOf(node: Any?): String? {
        when (node) {
            is String -> return node
            is Map<*, *> -> {
                (node["simpleText"] as? String)?.let { return it }
                (node["content"] as? String)?.let { return it }
                (node["runs"] as? List<*>)?.let { runs ->
                    return runs.joinToString("") { (it as? Map<*, *>)?.get("text") as? String ?: "" }
                }
                (node["text"])?.let { return textOf(it) }
            }
        }
        return null
    }

    // ---------------------------------------------------------------------------------------------
    // Comments: Newest first
    // ---------------------------------------------------------------------------------------------

    /** Token for the "Newest first" comments list of a video. Null if YouTube didn't offer one. */
    fun newestCommentsToken(videoUrl: String): String? {
        val id = videoIdFromUrl(videoUrl) ?: return null
        newestTokens[id]?.let { return it }
        val next = post("next") { it.value("videoId", id) }
        // The comments section's first continuation
        var sectionToken: String? = null
        fun walk(n: Any?) {
            if (sectionToken != null) return
            when (n) {
                is Map<*, *> -> {
                    val isr = n["itemSectionRenderer"] as? Map<*, *>
                    if (isr != null && isr["targetId"] == "comments-section") {
                        sectionToken = tokenIn(isr)
                        return
                    }
                    n.values.forEach { walk(it) }
                }
                is List<*> -> n.forEach { walk(it) }
            }
        }
        walk(next)
        val first = sectionToken ?: return null
        val page = post("next") { it.value("continuation", first) }
        // Header's sort menu: [Top comments, Newest first]
        val menu = find(page, "sortFilterSubMenuRenderer") as? Map<*, *> ?: return null
        val items = menu["subMenuItems"] as? List<*> ?: return null
        val token = tokenIn(items.getOrNull(1)) ?: return null
        newestTokens[id] = token
        return token
    }

    // ---------------------------------------------------------------------------------------------
    // Channel tabs: Latest / Popular / Oldest
    // ---------------------------------------------------------------------------------------------

    private fun tabParams(tab: String): String? = when (tab) {
        ChannelTabs.VIDEOS -> "EgZ2aWRlb3PyBgQKAjoA"
        ChannelTabs.SHORTS -> "EgZzaG9ydHPyBgUKA5oBAA%3D%3D"
        ChannelTabs.LIVESTREAMS -> "EgdzdHJlYW1z8gYECgJ6AA%3D%3D"
        else -> null
    }

    fun canSort(tab: String): Boolean = tabParams(tab) != null

    /** The sort chips YouTube shows on a channel tab, in its order (Latest, Popular, Oldest). */
    private fun chips(channelId: String, tab: String): List<SortChip> {
        val cacheKey = "$channelId|$tab"
        sortChips[cacheKey]?.let { return it }
        val params = tabParams(tab) ?: return emptyList()
        val res = post("browse") { it.value("browseId", channelId).value("params", params) }
        val out = ArrayList<SortChip>()
        fun walk(n: Any?) {
            when (n) {
                is Map<*, *> -> {
                    val chip = (n["chipCloudChipRenderer"] ?: n["chipViewModel"]) as? Map<*, *>
                    if (chip != null) {
                        // Keep chips without a token too, so positions still line up with Latest/Popular/Oldest
                        out += SortChip(textOf(chip["text"]) ?: "", tokenIn(chip) ?: "")
                        return
                    }
                    n.values.forEach { walk(it) }
                }
                is List<*> -> n.forEach { walk(it) }
            }
        }
        walk(res)
        if (out.any { it.token.isNotBlank() }) sortChips[cacheKey] = out
        return out
    }

    /** First page of a channel tab in the given order. */
    suspend fun channelTabSorted(channelId: String, tab: String, sort: ChannelSort, channel: ChannelItem): Paged<VideoItem> =
        withContext(Dispatchers.IO) {
            val list = chips(channelId, tab)
            if (list.isEmpty()) throw IllegalStateException("This channel can't be sorted right now")
            val wanted = (list.firstOrNull { it.label.equals(sort.label, ignoreCase = true) } ?: list.getOrNull(sort.ordinal))
                ?.takeIf { it.token.isNotBlank() }
                ?: throw IllegalStateException("YouTube doesn't offer \"${sort.label}\" here")
            videosFrom(post("browse") { it.value("continuation", wanted.token) }, channel)
        }

    // ---------------------------------------------------------------------------------------------
    // Search inside a channel
    // ---------------------------------------------------------------------------------------------

    suspend fun channelSearch(channelId: String, query: String, channel: ChannelItem): Paged<VideoItem> =
        withContext(Dispatchers.IO) {
            videosFrom(
                post("browse") {
                    it.value("browseId", channelId).value("params", "EgZzZWFyY2jyBgQKAloA").value("query", query)
                },
                channel
            )
        }

    /** Next page for anything above ([Page.getId] is the continuation token). */
    suspend fun more(page: Page, channel: ChannelItem): Paged<VideoItem> = withContext(Dispatchers.IO) {
        videosFrom(post("browse") { it.value("continuation", page.id) }, channel)
    }

    // ---------------------------------------------------------------------------------------------
    // Parsing videos out of any browse response
    // ---------------------------------------------------------------------------------------------

    private fun videosFrom(res: JsonObject, channel: ChannelItem): Paged<VideoItem> {
        val collector = StreamInfoItemsCollector(yt.serviceId)
        val parser = yt.getTimeAgoParser(NewPipe.getPreferredLocalization())
        val shorts = ArrayList<VideoItem>()
        var nextToken: String? = null
        fun walk(n: Any?) {
            when (n) {
                is JsonObject -> {
                    when {
                        n.has("videoRenderer") -> collector.commit(YoutubeStreamInfoItemExtractor(n.getObject("videoRenderer"), parser))
                        n.has("gridVideoRenderer") -> collector.commit(YoutubeStreamInfoItemExtractor(n.getObject("gridVideoRenderer"), parser))
                        n.has("reelItemRenderer") -> collector.commit(YoutubeReelInfoItemExtractor(n.getObject("reelItemRenderer")))
                        n.has("shortsLockupViewModel") -> shortFrom(n.getObject("shortsLockupViewModel"))?.let { shorts += it }
                        n.has("lockupViewModel") -> {
                            val l = n.getObject("lockupViewModel")
                            if (l.getString("contentType", "") == "LOCKUP_CONTENT_TYPE_VIDEO") {
                                collector.commit(YoutubeStreamInfoItemLockupExtractor(l, parser))
                            }
                        }
                        n.has("continuationItemRenderer") -> tokenIn(n.getObject("continuationItemRenderer"))?.let { nextToken = it }
                        else -> n.values.forEach { walk(it) }
                    }
                }
                is List<*> -> n.forEach { walk(it) }
            }
        }
        walk(res)
        val videos = collector.items.map { it.toVideo() } + shorts
        val filled = videos.map { v ->
            v.copy(
                uploader = v.uploader.ifBlank { channel.name },
                uploaderUrl = v.uploaderUrl.ifBlank { channel.url },
                uploaderAvatar = v.uploaderAvatar.ifBlank { channel.avatar }
            )
        }.distinctBy { it.url }
        return Paged(filled, nextToken?.let { Page("", it) })
    }

    /** YouTube's newer Shorts tiles (the extractor's own parser for these isn't public). */
    private fun shortFrom(o: JsonObject): VideoItem? {
        val id = (find(o, "reelWatchEndpoint") as? Map<*, *>)?.get("videoId") as? String
            ?: (o.getString("entityId", "").substringAfterLast('-').takeIf { it.length == 11 })
            ?: return null
        val meta = o.getObject("overlayMetadata")
        val title = textOf(meta["primaryText"]) ?: textOf(o["accessibilityText"]) ?: ""
        val viewsText = textOf(meta["secondaryText"]) ?: ""
        val thumb = ((find(o, "sources") as? List<*>)?.firstOrNull() as? Map<*, *>)?.get("url") as? String
        return VideoItem(
            url = "https://www.youtube.com/shorts/$id",
            title = title,
            thumbnail = thumb ?: "https://i.ytimg.com/vi/$id/hq2.jpg",
            views = parseCount(viewsText),
            isShort = true
        )
    }

    /** "1.2M views" -> 1200000. -1 if it can't be read. */
    private fun parseCount(text: String): Long {
        val m = Regex("([\\d.,]+)\\s*([KMB])?", RegexOption.IGNORE_CASE).find(text) ?: return -1
        val num = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return -1
        val mult = when (m.groupValues[2].uppercase()) {
            "K" -> 1_000.0
            "M" -> 1_000_000.0
            "B" -> 1_000_000_000.0
            else -> 1.0
        }
        return (num * mult).toLong()
    }
}
