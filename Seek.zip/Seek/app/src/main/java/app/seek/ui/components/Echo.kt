package app.seek.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.pulltorefresh.PullToRefreshState
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.seek.ui.theme.Cl
import kotlin.math.PI
import kotlin.math.sin

/*
 * Seek's logo, "Echo": a play button speeding past two fading copies of itself.
 *
 * Geometry lives in a 100-unit box (the same numbers as the launcher icon):
 * each play triangle has its tip at (cx + 0.62s, 50) and its back edge at cx - 0.42s,
 * with s = 26 and the three centres at 35, 47 and 59.
 */

private const val S = 26f
private val CENTRES = floatArrayOf(35f, 47f, 59f)
val EchoTop = Color(0xFFFF5A6E)
val EchoBottom = Color(0xFFE4002B)

private fun DrawScope.triangle(cx: Float, unit: Float, dx: Float = 0f): Path {
    val c = (cx + dx) * unit
    val cy = 50f * unit
    val s = S * unit
    return Path().apply {
        moveTo(c - 0.42f * s, cy - 0.55f * s)
        lineTo(c - 0.42f * s, cy + 0.55f * s)
        lineTo(c + 0.62f * s, cy)
        close()
    }
}

/**
 * Draws the mark into the current canvas.
 * [lit] is how "on" each of the three triangles is (0 = ghost outline, 1 = solid);
 * [slide] nudges them sideways (in 100-unit space) for the loader.
 */
fun DrawScope.drawEcho(
    color: Color = Cl.Red,
    lit: FloatArray = floatArrayOf(0f, 0f, 1f),
    slide: FloatArray = floatArrayOf(0f, 0f, 0f),
    gradient: Boolean = true,
    ghostAlpha: FloatArray = floatArrayOf(0.3f, 0.55f, 1f)
) {
    val unit = size.minDimension / 100f
    val brush = if (gradient && color == Cl.Red) {
        Brush.linearGradient(listOf(EchoTop, EchoBottom), Offset(20f * unit, 25f * unit), Offset(80f * unit, 75f * unit))
    } else null
    for (i in 0..2) {
        val p = triangle(CENTRES[i], unit, slide[i])
        val l = lit[i].coerceIn(0f, 1f)
        // Outline (the "ghost"), always there underneath
        val outlineAlpha = ghostAlpha[i] * (1f - l) + l
        val sw = (4.2f + 0.4f * i) * unit
        if (brush != null) drawPath(p, brush, alpha = outlineAlpha, style = Stroke(width = sw, join = StrokeJoin.Round))
        else drawPath(p, color, alpha = outlineAlpha, style = Stroke(width = sw, join = StrokeJoin.Round))
        // Fill as it lights up (stroked too, which rounds the corners)
        if (l > 0.01f) {
            if (brush != null) {
                drawPath(p, brush, alpha = l, style = Fill)
                drawPath(p, brush, alpha = l, style = Stroke(width = 6f * unit, join = StrokeJoin.Round))
            } else {
                drawPath(p, color, alpha = l, style = Fill)
                drawPath(p, color, alpha = l, style = Stroke(width = 6f * unit, join = StrokeJoin.Round))
            }
        }
    }
}

/** The logo mark, still. */
@Composable
fun EchoMark(size: Dp, modifier: Modifier = Modifier, color: Color = Cl.Red) {
    Canvas(modifier.size(size)) { drawEcho(color) }
}

/**
 * The loader: the three plays light up one after another, left to right, then let go and go
 * again. One transition drives it and it's read only while drawing, so it never recomposes.
 */
@Composable
fun EchoLoader(modifier: Modifier = Modifier, size: Dp = 40.dp, color: Color = Cl.Red) {
    val t = rememberInfiniteTransition(label = "echo")
    val phase = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "echo-phase"
    )
    Canvas(modifier.size(size)) {
        val p = phase.value
        val lit = FloatArray(3) { i -> pulse(p - i * 0.16f) }
        val slide = FloatArray(3) { i -> -3f * (1f - lit[i]) }
        drawEcho(color, lit = lit, slide = slide, ghostAlpha = floatArrayOf(0.22f, 0.22f, 0.22f))
    }
}

/** 0 → 1 → 0 bump over the first ~60% of the loop. */
private fun pulse(x: Float): Float {
    val v = ((x % 1f) + 1f) % 1f
    return if (v > 0.6f) 0f else sin(v / 0.6f * PI).toFloat().coerceAtLeast(0f)
}

/**
 * Pull-to-refresh: the plays fill in one by one as you pull ([pull] 0..1), then the loader runs
 * while it refreshes.
 */
@Composable
fun EchoRefreshIndicator(pull: Float, refreshing: Boolean, modifier: Modifier = Modifier, size: Dp = 30.dp, color: Color = Cl.Red) {
    if (refreshing) {
        EchoLoader(modifier, size, color)
        return
    }
    val f = pull.coerceIn(0f, 1f)
    Canvas(modifier.size(size)) {
        val lit = FloatArray(3) { i -> ((f - 0.2f - i * 0.22f) / 0.22f).coerceIn(0f, 1f) }
        val slide = FloatArray(3) { i -> -6f * (1f - lit[i]) }
        drawEcho(color, lit = lit, slide = slide, ghostAlpha = floatArrayOf(0.25f * f, 0.25f * f, 0.25f * f))
    }
}

/** Pull-to-refresh indicator: a round chip that follows your pull with the Echo filling in. */
@Composable
fun EchoPullIndicator(state: PullToRefreshState, refreshing: Boolean, modifier: Modifier = Modifier) {
    val f = if (refreshing) 1f else state.distanceFraction
    if (!refreshing && f <= 0.01f) return
    Box(
        modifier
            .padding(top = 8.dp)
            .graphicsLayer {
                val d = if (refreshing) 1f else state.distanceFraction.coerceIn(0f, 1.3f)
                translationY = d * 60.dp.toPx() - 44.dp.toPx()
                alpha = if (refreshing) 1f else (state.distanceFraction * 2f).coerceIn(0f, 1f)
            }
            .size(44.dp)
            .clip(CircleShape)
            .background(Cl.SurfaceHigh),
        contentAlignment = Alignment.Center
    ) {
        EchoRefreshIndicator(f, refreshing, size = 30.dp)
    }
}
