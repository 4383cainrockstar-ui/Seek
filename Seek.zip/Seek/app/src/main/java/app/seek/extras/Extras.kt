package app.seek.extras

import app.seek.core.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest

data class SbSegment(val category: String, val startMs: Long, val endMs: Long, val uuid: String)

data class SbCategory(val key: String, val label: String, val color: Long)

/** SponsorBlock: crowd-sourced skip segments (https://sponsor.ajay.app). */
object SponsorBlock {
    val categories = listOf(
        SbCategory("sponsor", "Sponsor", 0xFF00D400),
        SbCategory("selfpromo", "Self promotion", 0xFFFFFF00),
        SbCategory("interaction", "Interaction reminder", 0xFFCC00FF),
        SbCategory("intro", "Intro / intermission", 0xFF00FFFF),
        SbCategory("outro", "Outro / endcards", 0xFF0202ED),
        SbCategory("preview", "Preview / recap", 0xFF008FD6),
        SbCategory("music_offtopic", "Non-music section", 0xFFFF9900),
        SbCategory("filler", "Filler tangent", 0xFF7300FF)
    )

    fun color(category: String): Long = categories.firstOrNull { it.key == category }?.color ?: 0xFF00D400

    fun label(category: String): String = categories.firstOrNull { it.key == category }?.label ?: category

    private fun sha256(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    /** Uses the privacy-preserving hash-prefix endpoint, so the exact video id never leaves the phone. */
    suspend fun segments(videoId: String): List<SbSegment> = withContext(Dispatchers.IO) {
        try {
            val prefix = sha256(videoId).take(4)
            val cats = JSONArray(categories.map { it.key }).toString()
            val url = "https://sponsor.ajay.app/api/skipSegments/$prefix?categories=" +
                URLEncoder.encode(cats, "UTF-8")
            val body = Net.getText(url) ?: return@withContext emptyList()
            val arr = JSONArray(body)
            val out = mutableListOf<SbSegment>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                if (obj.optString("videoID") != videoId) continue
                val segs = obj.optJSONArray("segments") ?: continue
                for (j in 0 until segs.length()) {
                    val s = segs.getJSONObject(j)
                    if (s.optString("actionType", "skip") != "skip") continue
                    val pair = s.optJSONArray("segment") ?: continue
                    val start = (pair.optDouble(0, 0.0) * 1000).toLong()
                    val end = (pair.optDouble(1, 0.0) * 1000).toLong()
                    if (end > start) out += SbSegment(s.optString("category"), start, end, s.optString("UUID"))
                }
            }
            out.sortedBy { it.startMs }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

data class Votes(val likes: Long, val dislikes: Long)

/** Return YouTube Dislike (https://returnyoutubedislike.com). */
object Dislikes {
    suspend fun votes(videoId: String): Votes? = withContext(Dispatchers.IO) {
        try {
            val body = Net.getText("https://returnyoutubedislikeapi.com/votes?videoId=$videoId")
                ?: return@withContext null
            val o = JSONObject(body)
            Votes(o.optLong("likes", -1), o.optLong("dislikes", -1))
        } catch (e: Exception) {
            null
        }
    }
}
