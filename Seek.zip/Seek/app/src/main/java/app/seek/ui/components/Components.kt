package app.seek.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.seek.core.ChannelItem
import app.seek.core.Fmt
import app.seek.core.PlaylistItem
import app.seek.core.VideoItem
import app.seek.ui.theme.Cl
import coil.compose.AsyncImage

// =============================================================================================
// Brand
// =============================================================================================

/** The logo mark ("Echo": a play speeding past two fading copies of itself), crisp at any size. */
@Composable
fun SeekMark(width: Dp, modifier: Modifier = Modifier) {
    EchoMark(width, modifier)
}

/** "▶▶ Seek": the mark and the wordmark, the way YouTube's sits in the top bar. */
@Composable
fun Logo(modifier: Modifier = Modifier, size: Int = 21) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        // The mark's box has breathing room around the triangles, so it's drawn a bit larger and
        // nudged so the triangles sit flush left and tight against the word
        EchoMark((size * 1.75f).dp, Modifier.offset(x = (-size * 0.36f).dp))
        Text(
            "Seek",
            color = Cl.Text,
            fontSize = size.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-1).sp,
            modifier = Modifier.offset(x = (-size * 0.62f).dp)
        )
    }
}

// =============================================================================================
// Thumbnails / avatars
// =============================================================================================

@Composable
fun Thumb(
    url: String,
    modifier: Modifier = Modifier,
    duration: Long = -1,
    isLive: Boolean = false,
    progress: Float = 0f,
    corner: Dp = 8.dp,
    badge: String? = null
) {
    Box(
        modifier
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(corner))
            .background(Cl.SurfaceHigh)
    ) {
        if (url.isNotBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        if (badge != null) {
            Text(
                badge,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
        when {
            isLive -> LiveBadge(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
            )
            duration > 0 -> Text(
                Fmt.duration(duration),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
        if (progress > 0.02f) WatchedBar(progress, Modifier.align(Alignment.BottomStart))
    }
}

/** The red "you watched this far" line along the bottom of a thumbnail. */
@Composable
fun WatchedBar(progress: Float, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(3.dp)
            .background(Color.White.copy(alpha = 0.35f))
    ) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(3.dp)
                .background(Cl.Red)
        )
    }
}

@Composable
fun LiveBadge(modifier: Modifier = Modifier) {
    Row(
        modifier
            .background(Cl.LiveRed, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Sensors, null, tint = Color.White, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(3.dp))
        Text("LIVE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Avatar(url: String, size: Dp, modifier: Modifier = Modifier, ring: Boolean = false) {
    val base = modifier
        .size(size)
        .clip(CircleShape)
    val ringed = if (ring) base.border(2.dp, Cl.Red, CircleShape).padding(3.dp).clip(CircleShape) else base
    Box(ringed.background(Cl.SurfaceHighest), contentAlignment = Alignment.Center) {
        if (url.isNotBlank()) {
            AsyncImage(url, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Rounded.Person, null, tint = Cl.TextDim, modifier = Modifier.size(size * 0.55f))
        }
    }
}

// =============================================================================================
// Video cards
// =============================================================================================

@Composable
private fun Kebab(onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Cl.Text) {
    IconButton(onClick = onClick, modifier = modifier.size(36.dp)) {
        Icon(Icons.Rounded.MoreVert, "More", tint = tint, modifier = Modifier.size(20.dp))
    }
}

/**
 * The YouTube feed card: edge-to-edge thumbnail, then avatar, two-line title,
 * "Channel · views · age", and the ⋮ menu.
 */
@Composable
fun VideoCard(
    video: VideoItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    avatar: String = video.uploaderAvatar,
    progress: Float = 0f,
    onChannel: (() -> Unit)? = null,
    onMore: (() -> Unit)? = null
) {
    Column(
        modifier
            .fillMaxWidth()
            .pressClick(scale = 0.985f, onLongClick = onMore, onClick = onClick)
            .padding(bottom = 18.dp)
    ) {
        Thumb(video.thumbnail, Modifier.fillMaxWidth(), duration = video.duration, isLive = video.isLive, progress = progress, corner = 0.dp)
        Row(Modifier.padding(start = 12.dp, top = 12.dp), verticalAlignment = Alignment.Top) {
            Avatar(
                avatar, 36.dp,
                Modifier.then(if (onChannel != null) Modifier.clickable(onClick = onChannel) else Modifier)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    video.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Cl.Text,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val line = Fmt.line(video)
                if (line.isNotBlank()) {
                    Spacer(Modifier.height(3.dp))
                    Text(line, color = Cl.TextDim, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            if (onMore != null) Kebab(onMore) else Spacer(Modifier.width(12.dp))
        }
    }
}

/** Compact row: thumbnail on the left (search on tablets, history, playlists, up next). */
@Composable
fun VideoRow(
    video: VideoItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    progress: Float = 0f,
    subtitle: String? = null,
    onMore: (() -> Unit)? = null,
    trailing: (@Composable RowScope.() -> Unit)? = null
) {
    Row(
        modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onMore)
            .padding(start = 12.dp, end = 0.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Thumb(
            video.thumbnail,
            Modifier.width(160.dp),
            duration = video.duration,
            isLive = video.isLive,
            progress = progress,
            corner = 8.dp
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).padding(top = 2.dp)) {
            Text(video.title, color = Cl.Text, fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            if (video.uploader.isNotBlank()) {
                Text(video.uploader, color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val meta = subtitle ?: Fmt.meta(video)
            if (meta.isNotBlank()) Text(meta, color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) trailing()
        else if (onMore != null) Kebab(onMore)
        else Spacer(Modifier.width(12.dp))
    }
}

/** Small card for horizontal shelves ("History" on the You tab, etc). */
@Composable
fun ShelfVideoCard(
    video: VideoItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 160.dp,
    progress: Float = 0f,
    onMore: (() -> Unit)? = null
) {
    Column(
        modifier
            .width(width)
            .pressClick(onLongClick = onMore, onClick = onClick)
    ) {
        Thumb(video.thumbnail, duration = video.duration, isLive = video.isLive, progress = progress, corner = 8.dp)
        Row(Modifier.padding(top = 8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(video.title, color = Cl.Text, fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (video.uploader.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(video.uploader, color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (onMore != null) {
                IconButton(onClick = onMore, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Rounded.MoreVert, "More", tint = Cl.Text, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

/** Tall 9:16 Shorts tile with the title over the picture. */
@Composable
fun ShortTile(
    video: VideoItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onMore: (() -> Unit)? = null
) {
    Box(
        modifier
            .aspectRatio(9f / 16f)
            .pressClick(onLongClick = onMore, onClick = onClick)
            .clip(RoundedCornerShape(8.dp))
            .background(Cl.SurfaceHigh)
    ) {
        if (video.thumbnail.isNotBlank()) {
            AsyncImage(video.thumbnail, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.75f)))
        )
        if (onMore != null) {
            IconButton(onClick = onMore, modifier = Modifier.align(Alignment.TopEnd).size(36.dp)) {
                Icon(Icons.Rounded.MoreVert, "More", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
        ) {
            Text(video.title, color = Color.White, fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (video.views > 0) {
                Spacer(Modifier.height(2.dp))
                Text(Fmt.views(video.views), color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
    }
}

// =============================================================================================
// Channels / playlists
// =============================================================================================

@Composable
fun ChannelRow(
    channel: ChannelItem,
    subscribed: Boolean,
    onClick: () -> Unit,
    onSubscribe: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(112.dp), contentAlignment = Alignment.Center) {
            Avatar(channel.avatar, 80.dp)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(channel.name, color = Cl.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val meta = listOfNotNull(
                Fmt.subs(channel.subscribers).takeIf { it.isNotBlank() },
                if (channel.videos > 0) Fmt.count(channel.videos) + " videos" else null
            ).joinToString(" · ")
            if (meta.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(meta, color = Cl.TextDim, fontSize = 12.sp, maxLines = 2)
            }
            Spacer(Modifier.height(10.dp))
            SubscribeButton(subscribed, onSubscribe)
        }
    }
}

/** White "Subscribe" pill, or the grey "🔔 Subscribed ⌄" one. */
@Composable
fun SubscribeButton(subscribed: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .background(if (subscribed) Cl.SurfaceHigh else Cl.Text)
            .clickable(onClick = onClick)
            .padding(horizontal = if (subscribed) 12.dp else 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (subscribed) {
            Icon(Icons.Outlined.NotificationsNone, null, tint = Cl.Text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(
            if (subscribed) "Subscribed" else "Subscribe",
            color = if (subscribed) Cl.Text else Color.Black,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
        if (subscribed) {
            Spacer(Modifier.width(2.dp))
            Icon(Icons.Rounded.KeyboardArrowDown, null, tint = Cl.Text, modifier = Modifier.size(20.dp))
        }
    }
}

/** Playlist thumbnail with the stacked-cards look and the "▶≡ 24 videos" badge. */
@Composable
fun PlaylistThumb(url: String, count: Long, modifier: Modifier = Modifier, label: String? = null) {
    Column(modifier) {
        Box(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                .background(Cl.SurfaceHighest.copy(alpha = 0.6f))
        )
        Box(
            Modifier
                .padding(horizontal = 8.dp)
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                .background(Cl.SurfaceHighest)
        )
        Spacer(Modifier.height(1.dp))
        Box {
            Thumb(url, corner = 8.dp)
            val text = label ?: if (count >= 0) "$count videos" else null
            if (text != null) {
                Row(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.AutoMirrored.Rounded.PlaylistPlay, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(3.dp))
                    Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun PlaylistRow(p: PlaylistItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        PlaylistThumb(p.thumbnail, p.count, Modifier.width(160.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).padding(top = 8.dp)) {
            Text(p.name, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(
                listOf(p.uploader, "Playlist").filter { it.isNotBlank() }.joinToString(" · "),
                color = Cl.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// =============================================================================================
// Chips, buttons, bars
// =============================================================================================

/** YouTube's rounded-rectangle filter chip: grey, or white when selected. */
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    // Selection fades between grey and white instead of snapping
    val bg by androidx.compose.animation.animateColorAsState(if (selected) Cl.Text else Cl.SurfaceHigh, label = "chip-bg")
    val fg by androidx.compose.animation.animateColorAsState(if (selected) Color.Black else Cl.Text, label = "chip-fg")
    Box(
        modifier
            .height(32.dp)
            .pressClick(scale = 0.94f, onClick = onClick)
            .clip(RoundedCornerShape(8.dp))
            .drawBehind { drawRect(bg) }
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = fg,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

/** Icon-only chip, like YouTube's compass "Explore" chip at the start of the row. */
@Composable
fun IconChip(icon: ImageVector, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Cl.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, label, tint = Cl.Text, modifier = Modifier.size(20.dp))
    }
}

/** White pill with black text: the main action on a screen. */
@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .background(Cl.Text)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.Black, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** Grey pill with white text: secondary actions ("Shuffle", "Share", …). */
@Composable
fun TonalButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, highlighted: Boolean = false) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(50))
            .background(if (highlighted) Cl.SurfaceHighest else Cl.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Cl.Text, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Outlined "View all" pill next to a section title. */
@Composable
fun ViewAllButton(onClick: () -> Unit, text: String = "View all") {
    Box(
        Modifier
            .height(32.dp)
            .clip(RoundedCornerShape(50))
            .border(1.dp, Cl.SurfaceHighest, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun TopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(52.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Cl.Text)
            }
            Spacer(Modifier.width(4.dp))
        } else Spacer(Modifier.width(12.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = Cl.Text,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 12.dp, top = 20.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = MaterialTheme.typography.titleLarge, color = Cl.Text, modifier = Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
fun Loading(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
        EchoLoader(size = 40.dp)
    }
}

@Composable
fun ErrorBox(message: String, onRetry: (() -> Unit)?, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.ErrorOutline, null, tint = Cl.TextDim, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(message, color = Cl.TextDim, textAlign = TextAlign.Center, fontSize = 14.sp)
        if (onRetry != null) {
            Spacer(Modifier.height(16.dp))
            TonalButton("Retry", onRetry, icon = Icons.Rounded.Refresh)
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Cl.TextDim, modifier = Modifier.size(72.dp))
        Spacer(Modifier.height(18.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cl.Text, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, color = Cl.TextDim, textAlign = TextAlign.Center, fontSize = 14.sp, lineHeight = 20.sp)
        if (action != null) {
            Spacer(Modifier.height(20.dp))
            action()
        }
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, padding: PaddingValues = PaddingValues(12.dp), content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Cl.SurfaceHigh)
            .padding(padding),
        content = content
    )
}

/** A thin red seek line, the app's signature (mini player, Shorts). */
@Composable
fun SeekLine(fraction: Float, modifier: Modifier = Modifier, height: Dp = 2.dp, track: Color = Color.White.copy(alpha = 0.2f)) {
    Canvas(modifier.fillMaxWidth().height(height)) {
        drawRect(track)
        drawRect(Cl.Red, size = Size(size.width * fraction.coerceIn(0f, 1f), size.height), topLeft = Offset.Zero)
    }
}
