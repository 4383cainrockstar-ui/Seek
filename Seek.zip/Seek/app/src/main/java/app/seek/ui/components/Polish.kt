package app.seek.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import app.seek.ui.theme.Cl

// =============================================================================================
// Press: things shrink a touch under your finger
// =============================================================================================

/**
 * Click (and long-press) that scales down slightly while pressed, with a soft spring back.
 * The scale is applied on the graphics layer, so nothing re-lays out.
 */
fun Modifier.pressClick(
    scale: Float = 0.97f,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) scale else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, enabled = enabled, onLongClick = onLongClick, onClick = onClick)
}

// =============================================================================================
// Skeletons: grey shapes in the layout of what's loading, with a slow shimmer
// =============================================================================================

private val LocalShimmer = compositionLocalOf<State<Float>?> { null }

/** One shimmer clock shared by every bone inside it. */
@Composable
fun Shimmer(content: @Composable () -> Unit) {
    val t = rememberInfiniteTransition(label = "shimmer")
    val a = t.animateFloat(0.45f, 0.9f, infiniteRepeatable(tween(850, easing = LinearEasing), RepeatMode.Reverse), label = "shimmer-a")
    CompositionLocalProvider(LocalShimmer provides a, content = content)
}

/** A grey placeholder block. The alpha is read while drawing, so the shimmer never recomposes. */
@Composable
fun Bone(modifier: Modifier, shape: Shape = RoundedCornerShape(6.dp)) {
    val a = LocalShimmer.current
    Box(
        modifier
            .clip(shape)
            .drawBehind { drawRect(Cl.SurfaceHigh, alpha = a?.value ?: 0.7f) }
    )
}

/** Feed cards: big thumbnail, avatar, two lines. */
@Composable
fun SkeletonVideoCards(count: Int = 3) = Shimmer {
    Column {
        repeat(count) {
            Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
                Bone(Modifier.fillMaxWidth().aspectRatio(16f / 9f), RoundedCornerShape(0.dp))
                Row(Modifier.padding(start = 12.dp, top = 12.dp, end = 12.dp)) {
                    Bone(Modifier.size(36.dp), CircleShape)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Bone(Modifier.fillMaxWidth(0.92f).height(15.dp))
                        Spacer(Modifier.height(7.dp))
                        Bone(Modifier.fillMaxWidth(0.55f).height(12.dp))
                    }
                }
            }
        }
    }
}

/** Compact rows: small thumbnail on the left. */
@Composable
fun SkeletonVideoRows(count: Int = 6) = Shimmer {
    Column {
        repeat(count) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Bone(Modifier.width(160.dp).aspectRatio(16f / 9f), RoundedCornerShape(8.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.padding(top = 4.dp)) {
                    Bone(Modifier.fillMaxWidth(0.9f).height(13.dp))
                    Spacer(Modifier.height(6.dp))
                    Bone(Modifier.fillMaxWidth(0.6f).height(13.dp))
                    Spacer(Modifier.height(8.dp))
                    Bone(Modifier.fillMaxWidth(0.4f).height(11.dp))
                }
            }
        }
    }
}

/** Comments: avatar and a few lines of text. */
@Composable
fun SkeletonComments(count: Int = 6) = Shimmer {
    Column {
        repeat(count) { i ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Bone(Modifier.size(34.dp), CircleShape)
                Spacer(Modifier.width(12.dp))
                Column {
                    Bone(Modifier.width(110.dp).height(11.dp))
                    Spacer(Modifier.height(8.dp))
                    Bone(Modifier.fillMaxWidth(if (i % 2 == 0) 0.95f else 0.8f).height(13.dp))
                    Spacer(Modifier.height(5.dp))
                    Bone(Modifier.fillMaxWidth(if (i % 3 == 0) 0.5f else 0.7f).height(13.dp))
                }
            }
        }
    }
}

/** Channel page: three-wide grid of tall tiles (Shorts tab). */
@Composable
fun SkeletonShortsGrid(rows: Int = 2) = Shimmer {
    Column {
        repeat(rows) {
            Row(Modifier.fillMaxWidth()) {
                repeat(3) {
                    Box(Modifier.weight(1f).padding(1.dp)) {
                        Bone(Modifier.fillMaxWidth().aspectRatio(9f / 16f), RoundedCornerShape(8.dp))
                    }
                }
            }
        }
    }
}
