package app.seek

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.media3.common.util.UnstableApi
import app.seek.core.Net
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.data.Settings
import app.seek.download.Downloads
import app.seek.feed.FeedWorker
import app.seek.player.PlayerController
import coil.ImageLoader
import coil.ImageLoaderFactory

@UnstableApi
class SeekApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        Settings.init(this)
        Library.init(this)
        Yt.init()
        createChannels()
        PlayerController.init(this)
        Downloads.markInterrupted()
        try {
            FeedWorker.schedule(this)
        } catch (_: Exception) {
        }
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .okHttpClient(Net.client)
            .crossfade(true)
            .build()

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_DOWNLOADS, "Downloads", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_FEED, "New videos", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "downloads"
        const val CHANNEL_FEED = "feed"
    }
}
