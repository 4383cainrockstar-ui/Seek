package app.seek.core

import android.text.format.DateUtils
import java.util.Locale

object Fmt {
    fun count(n: Long): String {
        if (n < 0) return ""
        return when {
            n >= 1_000_000_000 -> trim(n / 1_000_000_000.0) + "B"
            n >= 1_000_000 -> trim(n / 1_000_000.0) + "M"
            n >= 1_000 -> trim(n / 1_000.0) + "K"
            else -> n.toString()
        }
    }

    private fun trim(v: Double): String {
        val s = if (v >= 100) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
        return s.removeSuffix(".0")
    }

    fun views(n: Long): String = if (n < 0) "" else count(n) + if (n == 1L) " view" else " views"

    fun subs(n: Long): String = if (n < 0) "" else count(n) + " subscribers"

    fun duration(seconds: Long): String {
        if (seconds < 0) return ""
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun durationMs(ms: Long): String = duration((ms / 1000).coerceAtLeast(0))

    fun ago(epochMs: Long, fallback: String = ""): String {
        if (epochMs <= 0) return fallback
        return DateUtils.getRelativeTimeSpanString(
            epochMs, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
        ).toString()
    }

    /** "1.2M views · 3 days ago" (or "1.2K watching" for live). */
    fun meta(video: VideoItem): String {
        val parts = mutableListOf<String>()
        if (video.isLive) {
            if (video.views > 0) parts += count(video.views) + " watching"
        } else {
            val v = views(video.views)
            if (v.isNotEmpty()) parts += v
            val a = ago(video.uploaded, video.uploadedText)
            if (a.isNotEmpty()) parts += a
        }
        return parts.joinToString(" · ")
    }

    /** YouTube's line under a title: "Channel · 1.2M views · 3 days ago". */
    fun line(video: VideoItem): String =
        listOf(video.uploader, meta(video)).filter { it.isNotBlank() }.joinToString(" · ")

    fun bytes(b: Long): String {
        if (b <= 0) return ""
        val kb = b / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
            else -> String.format(Locale.US, "%.0f KB", kb)
        }
    }
}
