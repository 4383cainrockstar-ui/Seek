package app.seek.download

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat as AndroidMediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import app.seek.SeekApp
import app.seek.MainActivity
import app.seek.R
import app.seek.core.Net
import app.seek.core.Yt
import app.seek.data.DownloadRecord
import app.seek.data.Library
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.File
import java.io.FileDescriptor
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

data class DownloadOption(
    val label: String,
    val audioOnly: Boolean,
    val video: VideoStream?,
    val audio: AudioStream?,
    val approxBytes: Long
)

data class DownloadJob(
    val id: String,
    val title: String,
    val pageUrl: String,
    val videoUrl: String?,
    val videoBytes: Long,
    val audioUrl: String?,
    val audioBytes: Long,
    val audioOnly: Boolean,
    val muxedVideo: Boolean
)

object Downloads {
    private val queue = ConcurrentLinkedQueue<DownloadJob>()

    private fun progressiveOk(s: org.schabi.newpipe.extractor.stream.Stream) =
        s.isUrl && s.content.isNotBlank() && s.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP

    private fun size(s: org.schabi.newpipe.extractor.stream.Stream?): Long =
        try {
            s?.itagItem?.contentLength ?: -1L
        } catch (e: Exception) {
            -1L
        }

    /** Download choices: MP4/AVC video (merged with AAC audio) up to 1080p+, or M4A audio. */
    fun options(info: StreamInfo): List<DownloadOption> {
        val audio = info.audioStreams
            .filter { progressiveOk(it) && it.format == MediaFormat.M4A }
            .filter { it.audioTrackType == null || it.audioTrackType == org.schabi.newpipe.extractor.stream.AudioTrackType.ORIGINAL }
            .ifEmpty { info.audioStreams.filter { progressiveOk(it) && it.format == MediaFormat.M4A } }
            .maxByOrNull { it.averageBitrate }

        val out = mutableListOf<DownloadOption>()
        if (audio != null) {
            val adaptive = info.videoOnlyStreams
                .filter { progressiveOk(it) && it.format == MediaFormat.MPEG_4 && (it.codec ?: "avc").startsWith("avc") }
                .groupBy { it.getResolution() }
                .mapNotNull { (_, list) -> list.maxByOrNull { it.fps } }
            adaptive.forEach { v ->
                val vs = size(v)
                val a = size(audio)
                out += DownloadOption(
                    label = v.getResolution(),
                    audioOnly = false,
                    video = v,
                    audio = audio,
                    approxBytes = if (vs > 0 && a > 0) vs + a else -1
                )
            }
        }
        // Classic muxed streams (usually 360p) as a fallback
        info.videoStreams
            .filter { progressiveOk(it) && !it.isVideoOnly() && it.format == MediaFormat.MPEG_4 }
            .filter { m -> out.none { it.label == m.getResolution() } }
            .forEach { m ->
                out += DownloadOption(m.getResolution(), false, m, null, size(m))
            }
        out.sortByDescending { o -> Regex("(\\d+)p").find(o.label)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
        if (audio != null) {
            out += DownloadOption("Audio (M4A ${audio.averageBitrate.coerceAtLeast(0)} kbps)", true, null, audio, size(audio))
        }
        return out
    }

    fun start(ctx: Context, info: StreamInfo, option: DownloadOption, thumbnail: String) {
        val id = UUID.randomUUID().toString()
        val title = info.name ?: "video"
        val job = DownloadJob(
            id = id,
            title = title,
            pageUrl = info.url ?: "",
            videoUrl = if (option.audioOnly) null else option.video?.content,
            videoBytes = size(option.video),
            audioUrl = option.audio?.content,
            audioBytes = size(option.audio),
            audioOnly = option.audioOnly,
            muxedVideo = option.video != null && !option.video.isVideoOnly()
        )
        Library.upsertDownload(
            DownloadRecord(
                id = id,
                title = title,
                thumbnail = thumbnail,
                sourceUrl = info.url ?: "",
                audioOnly = option.audioOnly,
                quality = option.label,
                status = DownloadRecord.STATUS_QUEUED,
                createdAt = System.currentTimeMillis()
            )
        )
        queue.add(job)
        ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
    }

    /** Re-fetches fresh stream URLs and queues the same quality again. */
    suspend fun retry(ctx: Context, record: DownloadRecord) {
        val info = Yt.stream(record.sourceUrl)
        val opts = options(info)
        val opt = opts.firstOrNull { it.label == record.quality }
            ?: opts.firstOrNull { it.audioOnly == record.audioOnly }
            ?: throw IllegalStateException("That quality isn't available anymore")
        Library.removeDownload(record.id)
        start(ctx, info, opt, record.thumbnail)
    }

    internal fun next(): DownloadJob? = queue.poll()

    /** Called at startup: anything that was mid-flight when the app died is marked as interrupted. */
    fun markInterrupted() {
        Library.value.downloads
            .filter { it.status == DownloadRecord.STATUS_RUNNING || it.status == DownloadRecord.STATUS_QUEUED }
            .forEach { r ->
                if (queue.none { it.id == r.id }) {
                    Library.updateDownload(r.id) { it.copy(status = DownloadRecord.STATUS_FAILED, error = "Interrupted. Tap retry.") }
                }
            }
    }
}

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var worker: Job? = null
    private val nm by lazy { NotificationManagerCompat.from(this) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = progressNotification("Starting download…", 0, true)
        ServiceCompat.startForeground(
            this, NOTIF_ID, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        if (worker?.isActive != true) {
            worker = scope.launch { drain() }
        }
        return START_NOT_STICKY
    }

    private suspend fun drain() {
        while (true) {
            val job = Downloads.next() ?: break
            runJob(job)
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun runJob(job: DownloadJob) {
        Library.updateDownload(job.id) { it.copy(status = DownloadRecord.STATUS_RUNNING, progress = 0f) }
        val tmpDir = File(cacheDir, "dl").apply { mkdirs() }
        val videoTmp = File(tmpDir, job.id + ".video")
        val audioTmp = File(tmpDir, job.id + ".audio")
        try {
            val total = (if (job.videoUrl != null) job.videoBytes.coerceAtLeast(0) else 0) +
                (if (job.audioUrl != null && !job.muxedVideo) job.audioBytes.coerceAtLeast(0) else 0)
            var doneBefore = 0L
            var lastUpdate = 0L
            val report: (Long) -> Unit = { bytesSoFar ->
                val now = System.currentTimeMillis()
                if (now - lastUpdate > 500) {
                    lastUpdate = now
                    val all = doneBefore + bytesSoFar
                    val p = if (total > 0) (all.toFloat() / total).coerceIn(0f, 1f) else 0f
                    Library.updateDownload(job.id) { it.copy(progress = p, sizeBytes = all) }
                    nm.notifySafe(NOTIF_ID, progressNotification(job.title, (p * 100).toInt(), total <= 0))
                }
            }

            if (job.videoUrl != null) {
                fetch(job.videoUrl, videoTmp, job.videoBytes, report)
                doneBefore += videoTmp.length()
            }
            if (job.audioUrl != null && !job.muxedVideo) {
                fetch(job.audioUrl, audioTmp, job.audioBytes, report)
            }

            val ext = if (job.audioOnly) "m4a" else "mp4"
            val mime = if (job.audioOnly) "audio/mp4" else "video/mp4"
            val name = safeName(job.title) + "." + ext

            val inputs = mutableListOf<File>()
            if (job.videoUrl != null) inputs += videoTmp
            if (job.audioUrl != null && !job.muxedVideo) inputs += audioTmp

            val uri = writeOutput(name, mime) { fd, path ->
                try {
                    mux(inputs, fd, path)
                } catch (e: Exception) {
                    // Remux failed; a single file can still be saved as-is
                    if (inputs.size == 1) copyRaw(inputs[0], fd, path) else throw e
                }
            }
            val finalSize = inputs.sumOf { it.length() }
            Library.updateDownload(job.id) {
                it.copy(status = DownloadRecord.STATUS_DONE, progress = 1f, fileUri = uri.toString(), fileName = name, sizeBytes = finalSize)
            }
            nm.notifySafe(job.id.hashCode(), doneNotification(job.title, true))
        } catch (e: Exception) {
            Library.updateDownload(job.id) {
                it.copy(status = DownloadRecord.STATUS_FAILED, error = Yt.friendlyError(e))
            }
            nm.notifySafe(job.id.hashCode(), doneNotification(job.title, false))
        } finally {
            videoTmp.delete()
            audioTmp.delete()
        }
    }

    /** googlevideo throttles big single requests; pull 8 MB ranges like the official clients do. */
    private fun fetch(url: String, out: File, expected: Long, onProgress: (Long) -> Unit) {
        val isPlayback = Uri.parse(url).path?.startsWith("/videoplayback") == true
        var pos = 0L
        FileOutputStream(out).use { fos ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val end = pos + CHUNK - 1
                val builder = Request.Builder().header("User-Agent", Net.USER_AGENT).header("Accept-Encoding", "identity")
                if (isPlayback) {
                    builder.url("$url&range=$pos-$end").post(byteArrayOf(0x78, 0).toRequestBody())
                } else {
                    builder.url(url).get()
                }
                Net.client.newCall(builder.build()).execute().use { resp ->
                    if (resp.code == 416) return
                    if (!resp.isSuccessful) throw IOException("Server answered HTTP ${resp.code}")
                    val body = resp.body ?: throw IOException("Empty response")
                    var got = 0L
                    body.byteStream().use { input ->
                        while (true) {
                            val n = input.read(buf)
                            if (n == -1) break
                            fos.write(buf, 0, n)
                            got += n
                            onProgress(pos + got)
                        }
                    }
                    pos += got
                    if (!isPlayback || got < CHUNK || got == 0L) return
                    if (expected > 0 && pos >= expected) return
                }
            }
        }
    }

    private fun writeOutput(name: String, mime: String, write: (FileDescriptor?, String?) -> Unit): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Seek")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Couldn't create the file in Downloads")
            try {
                resolver.openFileDescriptor(uri, "rw")?.use { pfd -> write(pfd.fileDescriptor, null) }
                    ?: throw IOException("Couldn't open the output file")
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } else {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Seek").apply { mkdirs() }
            var file = File(dir, name)
            var i = 1
            while (file.exists()) {
                file = File(dir, name.substringBeforeLast('.') + " ($i)." + name.substringAfterLast('.'))
                i++
            }
            write(null, file.absolutePath)
            return Uri.fromFile(file)
        }
    }

    @SuppressLint("WrongConstant")
    private fun mux(inputs: List<File>, fd: FileDescriptor?, path: String?) {
        val muxer = if (fd != null) MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        else MediaMuxer(path!!, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val extractors = mutableListOf<Pair<MediaExtractor, Int>>()
        try {
            var maxInput = 1024 * 1024
            for (f in inputs) {
                val ex = MediaExtractor()
                ex.setDataSource(f.absolutePath)
                var picked = -1
                for (t in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(t).getString(AndroidMediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        picked = t
                        break
                    }
                }
                if (picked < 0) throw IOException("No media track in downloaded file")
                ex.selectTrack(picked)
                val format = ex.getTrackFormat(picked)
                if (format.containsKey(AndroidMediaFormat.KEY_MAX_INPUT_SIZE)) {
                    maxInput = maxOf(maxInput, format.getInteger(AndroidMediaFormat.KEY_MAX_INPUT_SIZE))
                }
                extractors += ex to muxer.addTrack(format)
            }
            muxer.start()
            val buffer = ByteBuffer.allocate(maxOf(maxInput, 4 * 1024 * 1024))
            val info = MediaCodec.BufferInfo()
            for ((ex, track) in extractors) {
                while (true) {
                    buffer.clear()
                    val size = ex.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = ex.sampleTime
                    info.flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(track, buffer, info)
                    ex.advance()
                }
            }
            muxer.stop()
        } finally {
            extractors.forEach { it.first.release() }
            try {
                muxer.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun copyRaw(src: File, fd: FileDescriptor?, path: String?) {
        val out = if (fd != null) FileOutputStream(fd) else FileOutputStream(path!!)
        out.use { o -> src.inputStream().use { it.copyTo(o) } }
    }

    private fun safeName(title: String): String =
        title.replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), " ").replace(Regex("\\s+"), " ").trim().take(120).ifBlank { "Seek video" }

    private fun openDownloadsIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_OPEN_DOWNLOADS)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 3, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun progressNotification(title: String, percent: Int, indeterminate: Boolean): Notification =
        NotificationCompat.Builder(this, SeekApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(if (indeterminate) "Downloading…" else "$percent%")
            .setProgress(100, percent, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openDownloadsIntent())
            .build()

    private fun doneNotification(title: String, ok: Boolean): Notification =
        NotificationCompat.Builder(this, SeekApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(if (ok) "Downloaded" else "Download failed")
            .setContentText(title)
            .setAutoCancel(true)
            .setContentIntent(openDownloadsIntent())
            .build()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 5150
        private const val CHUNK = 8L * 1024 * 1024
    }
}

@SuppressLint("MissingPermission")
private fun NotificationManagerCompat.notifySafe(id: Int, n: Notification) {
    try {
        if (areNotificationsEnabled()) notify(id, n)
    } catch (_: SecurityException) {
    }
}
