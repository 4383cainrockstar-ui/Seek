package app.seek.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** YouTube's dark theme, as close as it gets. */
object Cl {
    /** App background (YouTube's #0F0F0F). */
    val Deep = Color(0xFF0F0F0F)
    /** Sheets, menus, dialogs. */
    val Surface = Color(0xFF212121)
    /** Chips, pills, search box, cards. */
    val SurfaceHigh = Color(0xFF272727)
    /** Pressed / raised pills, placeholders. */
    val SurfaceHighest = Color(0xFF3F3F3F)
    val Outline = Color(0xFF303030)

    val Text = Color(0xFFF1F1F1)
    val TextDim = Color(0xFFAAAAAA)
    val TextFaint = Color(0xFF717171)

    /** The red: seek bar, live badges, logo. */
    val Red = Color(0xFFFF0033)
    /** Links, "more", switches. */
    val Blue = Color(0xFF3EA6FF)
    val Green = Color(0xFF2BA640)
    /** Live badge background. */
    val LiveRed = Color(0xFFCC0000)
}

private val scheme = darkColorScheme(
    primary = Cl.Text,
    onPrimary = Color.Black,
    primaryContainer = Cl.SurfaceHigh,
    onPrimaryContainer = Cl.Text,
    secondary = Cl.Blue,
    onSecondary = Color.Black,
    secondaryContainer = Cl.SurfaceHigh,
    onSecondaryContainer = Cl.Text,
    tertiary = Cl.Red,
    background = Cl.Deep,
    onBackground = Cl.Text,
    surface = Cl.Deep,
    onSurface = Cl.Text,
    surfaceVariant = Cl.SurfaceHigh,
    onSurfaceVariant = Cl.TextDim,
    surfaceContainer = Cl.Surface,
    surfaceContainerHigh = Cl.Surface,
    surfaceContainerHighest = Cl.SurfaceHigh,
    surfaceContainerLow = Cl.Surface,
    surfaceContainerLowest = Cl.Deep,
    outline = Cl.Outline,
    outlineVariant = Cl.Outline,
    error = Cl.Red
)

// Roboto (the system font) with YouTube's weights: titles are Medium, not Bold
private val base = Typography()
private val typography = Typography(
    headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = base.titleMedium.copy(fontSize = 16.sp, fontWeight = FontWeight.Medium, lineHeight = 21.sp),
    titleSmall = base.titleSmall.copy(fontWeight = FontWeight.Medium),
    bodyLarge = base.bodyLarge,
    bodyMedium = base.bodyMedium,
    bodySmall = base.bodySmall,
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Medium),
    labelMedium = base.labelMedium,
    labelSmall = base.labelSmall
)

@Composable
fun SeekTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
