package app.seek.feed

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.seek.SeekApp
import app.seek.MainActivity
import app.seek.R
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.data.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

data class FeedProgress(val running: Boolean = false, val done: Int = 0, val total: Int = 0, val failed: Int = 0)

object FeedRepository {
    private val lock = Mutex()
    private val _progress = MutableStateFlow(FeedProgress())
    val progress: StateFlow<FeedProgress> = _progress.asStateFlow()

    /** Refreshes every subscription. Returns the number of brand new videos. */
    suspend fun refresh(): Int = lock.withLock {
        withContext(Dispatchers.IO) {
            val subs = Library.value.subscriptions
            if (subs.isEmpty()) {
                Library.setFeed(emptyList())
                return@withContext 0
            }
            val before = Library.value.feed.map { it.url }.toSet()
            val detailed = Settings.current.detailedFeed
            val done = AtomicInteger(0)
            val failed = AtomicInteger(0)
            _progress.value = FeedProgress(true, 0, subs.size, 0)
            val gate = Semaphore(if (detailed) 4 else 8)

            val results: List<List<VideoItem>> = coroutineScope {
                subs.map { sub ->
                    async {
                        gate.withPermit {
                            val items = try {
                                Yt.latestUploads(sub.url, detailed).map { v ->
                                    v.copy(
                                        uploader = v.uploader.ifBlank { sub.name },
                                        uploaderUrl = v.uploaderUrl.ifBlank { sub.url },
                                        uploaderAvatar = v.uploaderAvatar.ifBlank { sub.avatar }
                                    )
                                }
                            } catch (e: Exception) {
                                failed.incrementAndGet()
                                // keep what we already had for this channel
                                Library.value.feed.filter { Library.sameChannel(it.uploaderUrl, sub.url) }
                            }
                            if (sub.avatar.isBlank()) {
                                items.firstOrNull { it.uploaderAvatar.isNotBlank() }?.let {
                                    Library.updateSubscriptionMeta(sub.url, "", it.uploaderAvatar)
                                }
                            }
                            _progress.value = FeedProgress(true, done.incrementAndGet(), subs.size, failed.get())
                            items
                        }
                    }
                }.awaitAll()
            }

            val merged = results.flatten()
            Library.setFeed(merged)
            _progress.value = FeedProgress(false, subs.size, subs.size, failed.get())

            // RSS has no avatars: fill in missing channel art/names a few at a time
            val missing = Library.value.subscriptions.filter { it.avatar.isBlank() }.take(40)
            if (missing.isNotEmpty()) {
                val gate2 = Semaphore(4)
                coroutineScope {
                    missing.map { s ->
                        async {
                            gate2.withPermit {
                                try {
                                    val d = Yt.channel(s.url)
                                    Library.updateSubscriptionMeta(s.url, d.channel.name, d.channel.avatar)
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }.awaitAll()
                }
            }
            if (before.isEmpty()) 0 else merged.count { it.url !in before }
        }
    }

    fun isStale(): Boolean =
        System.currentTimeMillis() - Library.value.feedUpdatedAt > TimeUnit.MINUTES.toMillis(30)
}

class FeedWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            val fresh = FeedRepository.refresh()
            if (fresh > 0 && Settings.current.newVideoNotifications) notifyNew(fresh)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    @SuppressLint("MissingPermission")
    private fun notifyNew(count: Int) {
        val ctx = applicationContext
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val intent = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(ctx, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, SeekApp.CHANNEL_FEED)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(if (count == 1) "1 new video" else "$count new videos")
            .setContentText("Fresh uploads from your subscriptions")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        NotificationManagerCompat.from(ctx).notify(4242, n)
    }

    companion object {
        private const val NAME = "clipse-feed-refresh"

        fun schedule(ctx: Context) {
            val wm = WorkManager.getInstance(ctx)
            if (!Settings.current.backgroundRefresh) {
                wm.cancelUniqueWork(NAME)
                return
            }
            val req = PeriodicWorkRequestBuilder<FeedWorker>(3, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
