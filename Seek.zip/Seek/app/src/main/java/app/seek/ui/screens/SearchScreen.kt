package app.seek.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.NorthWest
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.seek.core.ListEntry
import app.seek.core.Paged
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.ui.LocalActions
import app.seek.ui.components.ChannelRow
import app.seek.ui.components.Chip
import app.seek.ui.components.EmptyState
import app.seek.ui.components.EndReached
import app.seek.ui.components.ErrorBox
import app.seek.ui.components.Loading
import app.seek.ui.components.SkeletonVideoCards
import app.seek.ui.components.PagerVm
import app.seek.ui.components.PlaylistRow
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.VideoCard
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

class SearchVm : PagerVm<ListEntry>() {
    var query by mutableStateOf("")
        private set
    var filter by mutableStateOf(Yt.FILTER_ALL)
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    private var suggestJob: Job? = null

    override suspend fun first(): Paged<ListEntry> = Yt.search(query, filter)
    override suspend fun more(page: Page): Paged<ListEntry> = Yt.searchMore(query, filter, page)
    override fun keyOf(item: ListEntry): Any = item.key

    fun submit(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        query = t
        suggestions = emptyList()
        Library.addSearch(t)
        reload()
    }

    fun changeFilter(f: String) {
        if (f == filter) return
        filter = f
        if (query.isNotBlank()) reload()
    }

    fun suggest(text: String) {
        suggestJob?.cancel()
        if (text.isBlank()) {
            suggestions = emptyList()
            return
        }
        suggestJob = viewModelScope.launch {
            delay(220)
            suggestions = Yt.suggestions(text).take(8)
        }
    }
}

@UnstableApi
@Composable
fun SearchScreen(initial: String) {
    val actions = LocalActions.current
    val vm: SearchVm = viewModel()
    val lib by Library.data.collectAsState()
    var text by rememberSaveable { mutableStateOf(initial) }
    var editing by rememberSaveable { mutableStateOf(initial.isBlank()) }
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val listState = rememberLazyListState()
    val progress = rememberWatchProgress()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    EndReached(listState) { vm.loadMore() }

    LaunchedEffect(Unit) {
        if (initial.isNotBlank() && vm.query != initial) vm.submit(initial)
        if (editing) focus.requestFocus()
    }

    fun go(q: String) {
        val clean = q.trim()
        if (clean.isEmpty()) return
        val url = Yt.extractUrl(clean)
        if (url != null && Yt.linkKind(url) != Yt.LinkKind.NONE) {
            actions.link(url)
            return
        }
        text = clean
        editing = false
        focusManager.clearFocus()
        vm.submit(clean)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { actions.back() }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Cl.Text)
            }
            TextField(
                value = text,
                onValueChange = {
                    text = it
                    editing = true
                    vm.suggest(it)
                },
                placeholder = { Text("Search YouTube", color = Cl.TextDim, fontSize = 16.sp) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp),
                trailingIcon = {
                    if (text.isNotEmpty()) IconButton(onClick = {
                        text = ""
                        editing = true
                        vm.suggest("")
                        focus.requestFocus()
                    }) { Icon(Icons.Rounded.Close, "Clear", tint = Cl.Text) }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { go(text) }),
                shape = RoundedCornerShape(50),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Cl.SurfaceHigh,
                    unfocusedContainerColor = Cl.SurfaceHigh,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedTextColor = Cl.Text,
                    unfocusedTextColor = Cl.Text,
                    cursorColor = Cl.Blue
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .focusRequester(focus)
            )
        }

        if (editing) {
            // Suggestions + history
            LazyColumn(Modifier.fillMaxSize()) {
                val history = if (text.isBlank()) lib.searchHistory
                else lib.searchHistory.filter { it.contains(text.trim(), ignoreCase = true) }.take(4)
                items(history, key = { "h:$it" }) { h ->
                    SuggestionRow(h, history = true, onClick = { go(h) }, onFill = { text = h; vm.suggest(h) }, onRemove = { Library.removeSearch(h) })
                }
                items(vm.suggestions.filter { s -> history.none { it.equals(s, true) } }, key = { "s:$it" }) { s ->
                    SuggestionRow(s, history = false, onClick = { go(s) }, onFill = { text = s; vm.suggest(s) }, onRemove = null)
                }
                if (text.isBlank() && lib.searchHistory.isEmpty()) item {
                    EmptyState(Icons.Rounded.Search, "Search YouTube", "Videos, Shorts, channels and playlists. You can paste a YouTube link here too.")
                }
            }
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf(Yt.FILTER_ALL to "All", Yt.FILTER_VIDEOS to "Videos", Yt.FILTER_CHANNELS to "Channels", Yt.FILTER_PLAYLISTS to "Playlists")
                items(filters) { (key, label) -> Chip(label, vm.filter == key, { vm.changeFilter(key) }) }
            }
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                when {
                    vm.loading && vm.items.isEmpty() -> item { SkeletonVideoCards(3) }
                    vm.error != null && vm.items.isEmpty() -> item { ErrorBox(vm.error ?: "", onRetry = { vm.reload() }) }
                    vm.items.isEmpty() && vm.started -> item {
                        EmptyState(Icons.Rounded.Search, "No results", "Try different words.")
                    }
                    else -> items(vm.items, key = { it.key }) { e ->
                        when (e) {
                            is ListEntry.Video -> VideoCard(
                                modifier = Modifier.animateItem(fadeInSpec = null, fadeOutSpec = null),
                                video = e.item,
                                progress = progress[e.item.url] ?: 0f,
                                onClick = { actions.video(e.item) },
                                onChannel = { actions.channel(e.item.uploaderUrl) },
                                onMore = { menuFor = e.item }
                            )
                            is ListEntry.Channel -> ChannelRow(
                                channel = e.item,
                                subscribed = lib.subscriptions.any { Library.sameChannel(it.url, e.item.url) },
                                onClick = { actions.channel(e.item.url) },
                                onSubscribe = { Library.toggleSubscription(e.item.url, e.item.name, e.item.avatar) }
                            )
                            is ListEntry.Playlist -> PlaylistRow(e.item, onClick = { actions.playlist(e.item.url) })
                        }
                    }
                }
                if (vm.loadingMore) item { Loading() }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}

@Composable
private fun SuggestionRow(
    text: String,
    history: Boolean,
    onClick: () -> Unit,
    onFill: () -> Unit,
    onRemove: (() -> Unit)?
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (history) Icons.Rounded.History else Icons.Rounded.Search, null, tint = Cl.Text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Text(text, color = Cl.Text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (onRemove != null) {
            IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, "Remove", tint = Cl.TextDim, modifier = Modifier.size(20.dp)) }
        }
        IconButton(onClick = onFill) { Icon(Icons.Rounded.NorthWest, "Fill", tint = Cl.Text, modifier = Modifier.size(22.dp)) }
    }
}
