package app.seek.core

import kotlinx.serialization.Serializable
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType

@Serializable
data class VideoItem(
    val url: String,
    val title: String,
    val uploader: String = "",
    val uploaderUrl: String = "",
    val thumbnail: String = "",
    val duration: Long = -1,
    val views: Long = -1,
    val uploaded: Long = 0,
    val uploadedText: String = "",
    val isShort: Boolean = false,
    val isLive: Boolean = false,
    val uploaderAvatar: String = ""
)

@Serializable
data class ChannelItem(
    val url: String,
    val name: String,
    val avatar: String = "",
    val subscribers: Long = -1,
    val videos: Long = -1,
    val description: String = ""
)

@Serializable
data class PlaylistItem(
    val url: String,
    val name: String,
    val thumbnail: String = "",
    val uploader: String = "",
    val count: Long = -1
)

/** One row in a mixed result list (search, channel tabs). */
sealed interface ListEntry {
    val key: String

    data class Video(val item: VideoItem) : ListEntry {
        override val key get() = "v:" + item.url
    }

    data class Channel(val item: ChannelItem) : ListEntry {
        override val key get() = "c:" + item.url
    }

    data class Playlist(val item: PlaylistItem) : ListEntry {
        override val key get() = "p:" + item.url
    }
}

// ---------------------------------------------------------------------------------------------
// Mapping helpers from NewPipe Extractor types
// ---------------------------------------------------------------------------------------------

fun List<Image>?.bestUrl(maxHeight: Int = 720): String {
    if (this.isNullOrEmpty()) return ""
    val usable = this.filter { !it.url.isNullOrBlank() }
    if (usable.isEmpty()) return ""
    val known = usable.filter { it.height > 0 }
    if (known.isEmpty()) {
        // Unknown sizes: the extractor lists them roughly small -> large
        return if (maxHeight >= 480) usable.last().url else usable.first().url
    }
    val fitting = known.filter { it.height <= maxHeight }.maxByOrNull { it.height }
    return (fitting ?: known.minByOrNull { it.height }!!).url
}

fun videoIdFromUrl(url: String): String? {
    val patterns = listOf(
        Regex("[?&]v=([A-Za-z0-9_-]{11})"),
        Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
        Regex("/shorts/([A-Za-z0-9_-]{11})"),
        Regex("/live/([A-Za-z0-9_-]{11})"),
        Regex("/embed/([A-Za-z0-9_-]{11})")
    )
    for (p in patterns) {
        val m = p.find(url)
        if (m != null) return m.groupValues[1]
    }
    return null
}

fun fallbackThumb(url: String): String =
    videoIdFromUrl(url)?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" } ?: ""

private fun safeEpoch(block: () -> Long?): Long = try {
    block() ?: 0L
} catch (e: Exception) {
    0L
}

fun StreamInfoItem.toVideo(): VideoItem {
    val u = url ?: ""
    val thumb = thumbnails.bestUrl().ifBlank { fallbackThumb(u) }
    val type = streamType
    return VideoItem(
        url = u,
        title = name ?: "",
        uploader = uploaderName ?: "",
        uploaderUrl = uploaderUrl ?: "",
        thumbnail = thumb,
        duration = duration,
        views = viewCount,
        uploaded = safeEpoch { uploadDate?.offsetDateTime()?.toInstant()?.toEpochMilli() },
        uploadedText = textualUploadDate ?: "",
        isShort = isShortFormContent || u.contains("/shorts/"),
        isLive = type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM,
        uploaderAvatar = uploaderAvatars.bestUrl(176)
    )
}

fun StreamInfo.toVideo(): VideoItem {
    val u = url ?: ""
    val type = streamType
    return VideoItem(
        url = u,
        title = name ?: "",
        uploader = uploaderName ?: "",
        uploaderUrl = uploaderUrl ?: "",
        thumbnail = thumbnails.bestUrl().ifBlank { fallbackThumb(u) },
        duration = duration,
        views = viewCount,
        uploaded = safeEpoch { uploadDate?.offsetDateTime()?.toInstant()?.toEpochMilli() },
        uploadedText = textualUploadDate ?: "",
        isShort = isShortFormContent,
        isLive = type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM,
        uploaderAvatar = uploaderAvatars.bestUrl(176)
    )
}

fun ChannelInfoItem.toChannel() = ChannelItem(
    url = url ?: "",
    name = name ?: "",
    avatar = thumbnails.bestUrl(176),
    subscribers = subscriberCount,
    videos = streamCount,
    description = description ?: ""
)

fun PlaylistInfoItem.toPlaylist() = PlaylistItem(
    url = url ?: "",
    name = name ?: "",
    thumbnail = thumbnails.bestUrl(),
    uploader = uploaderName ?: "",
    count = streamCount
)

fun InfoItem.toEntry(): ListEntry? = when (this) {
    is StreamInfoItem -> ListEntry.Video(toVideo())
    is ChannelInfoItem -> ListEntry.Channel(toChannel())
    is PlaylistInfoItem -> ListEntry.Playlist(toPlaylist())
    else -> null
}
