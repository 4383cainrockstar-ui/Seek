package app.seek.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import app.seek.ui.components.EchoPullIndicator
import app.seek.ui.components.SkeletonVideoCards
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.data.Settings
import app.seek.feed.FeedRepository
import app.seek.ui.LocalActions
import app.seek.ui.Routes
import app.seek.ui.ShortsIcon
import app.seek.ui.components.Card
import app.seek.ui.components.Chip
import app.seek.ui.components.EmptyState
import app.seek.ui.components.IconChip
import app.seek.ui.components.Loading
import app.seek.ui.components.Logo
import app.seek.ui.components.PrimaryButton
import app.seek.ui.components.ShortTile
import app.seek.ui.components.TonalButton
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.VideoCard
import app.seek.ui.components.channelKey
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/**
 * "Recommended", with no account and no tracking: videos related to what you watched
 * last (straight from each video's own "up next"), mixed with new uploads from your
 * subscriptions. Nothing watched yet? Trending fills in.
 */
class HomeVm : ViewModel() {
    var recs by mutableStateOf<List<VideoItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    private var loadedFor: String? = null

    fun load(force: Boolean = false) {
        val seeds = Library.value.history.take(5).map { it.video }
        val sig = seeds.joinToString("|") { it.url }
        if (loading || (!force && sig == loadedFor && recs.isNotEmpty())) return
        loading = true
        viewModelScope.launch {
            try {
                val lists: List<List<VideoItem>> = coroutineScope {
                    seeds.map { s ->
                        async {
                            try {
                                Yt.related(Yt.stream(s.url))
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                emptyList()
                            }
                        }
                    }.awaitAll()
                }
                // Take turns between seeds so one video doesn't own the whole feed
                val merged = LinkedHashMap<String, VideoItem>()
                var i = 0
                while (lists.any { i < it.size }) {
                    lists.forEach { l -> l.getOrNull(i)?.let { merged.putIfAbsent(it.url, it) } }
                    i++
                }
                var out = merged.values.toList()
                if (out.size < 15) {
                    val trending = Yt.kiosks.take(2).map { k ->
                        try {
                            Yt.kiosk(k.id).items
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            emptyList()
                        }
                    }
                    out = out + trending.flatten()
                }
                recs = out.distinctBy { it.url }
                loadedFor = sig
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            } finally {
                loading = false
            }
        }
    }
}

private enum class HomeChip(val label: String) {
    ALL("All"), SUBS("Subscriptions"), NEW_TO_YOU("New to you"), RECENT("Recently uploaded"), LIVE("Live"), CONTINUE("Continue watching")
}

@UnstableApi
@Composable
fun HomeScreen() {
    val actions = LocalActions.current
    val vm: HomeVm = viewModel()
    val lib by Library.data.collectAsState()
    val settings by Settings.state.collectAsState()
    val feedProgress by FeedRepository.progress.collectAsState()
    val scope = rememberCoroutineScope()
    var chip by rememberSaveable { mutableStateOf(HomeChip.ALL) }
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    val progress = rememberWatchProgress()
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) { vm.load() }

    val subsByKey = remember(lib.subscriptions) { lib.subscriptions.associateBy { channelKey(it.url) } }
    val watched = remember(lib.history) {
        lib.history.filter { it.durationMs > 0 && it.positionMs > it.durationMs * 0.9 }.map { it.video.url }.toSet()
    }
    fun keep(v: VideoItem) = !(settings.hideWatched && v.url in watched) &&
        !(settings.minDurationMinutes > 0 && v.duration in 1 until settings.minDurationMinutes * 60L)

    val feedVideos = remember(lib.feed, watched, settings) { lib.feed.filter { !it.isShort && keep(it) } }
    val recVideos = remember(vm.recs, watched, settings) { vm.recs.filter { !it.isShort && it.url !in watched && keep(it) } }
    val shorts = remember(lib.feed, vm.recs, watched, settings.hideShorts) {
        if (settings.hideShorts) emptyList()
        else (lib.feed.filter { it.isShort && it.url !in watched } + vm.recs.filter { it.isShort }).distinctBy { it.url }.take(12)
    }

    val visible: List<VideoItem> = remember(chip, feedVideos, recVideos, lib.history) {
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        when (chip) {
            HomeChip.ALL -> {
                // One new upload from your subscriptions, then two recommendations, and so on
                val fresh = feedVideos.filter { it.uploaded <= 0 || it.uploaded >= weekAgo }.filter { it.url !in watched }
                val out = ArrayList<VideoItem>()
                val a = fresh.iterator()
                val b = recVideos.iterator()
                while (a.hasNext() || b.hasNext()) {
                    if (a.hasNext()) out += a.next()
                    repeat(2) { if (b.hasNext()) out += b.next() }
                }
                (out + feedVideos).distinctBy { it.url }
            }
            HomeChip.SUBS -> feedVideos
            HomeChip.NEW_TO_YOU -> recVideos.filter { subsByKey[channelKey(it.uploaderUrl)] == null }
            HomeChip.RECENT -> {
                val threeDays = System.currentTimeMillis() - 3L * 24 * 3600 * 1000
                (feedVideos + recVideos).filter { it.uploaded >= threeDays }.distinctBy { it.url }.sortedByDescending { it.uploaded }
            }
            HomeChip.LIVE -> (feedVideos + recVideos).filter { it.isLive }.distinctBy { it.url }
            HomeChip.CONTINUE -> lib.history.filter { it.durationMs > 0 && it.positionMs > 5_000 && it.positionMs < it.durationMs * 0.9 }.map { it.video }
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Top bar: logo, search
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(52.dp)
                .padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Logo()
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { actions.search() }) { Icon(Icons.Rounded.Search, "Search", tint = Cl.Text, modifier = Modifier.size(26.dp)) }
        }

        // Chips, starting with the compass that opens Explore
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { IconChip(Icons.Outlined.Explore, "Explore", { actions.open(Routes.EXPLORE) }) }
            items(HomeChip.entries.toList()) { c -> Chip(c.label, chip == c, { chip = c }) }
        }

        if (feedProgress.running && feedProgress.total > 0) {
            LinearProgressIndicator(
                progress = { feedProgress.done.toFloat() / feedProgress.total },
                color = Cl.Red,
                trackColor = Cl.SurfaceHigh,
                modifier = Modifier.fillMaxWidth().height(2.dp)
            )
        } else Spacer(Modifier.height(2.dp))

        val pullState = rememberPullToRefreshState()
        PullToRefreshBox(
            isRefreshing = feedProgress.running,
            onRefresh = {
                vm.load(force = true)
                scope.launch { FeedRepository.refresh() }
            },
            state = pullState,
            modifier = Modifier.fillMaxSize(),
            indicator = { EchoPullIndicator(pullState, feedProgress.running, Modifier.align(Alignment.TopCenter)) }
        ) {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                if (lib.subscriptions.isEmpty() && chip == HomeChip.ALL) item { StarterCard() }

                if (visible.isEmpty()) {
                    item {
                        when {
                            vm.loading || feedProgress.running -> SkeletonVideoCards(3)
                            chip == HomeChip.SUBS && lib.subscriptions.isEmpty() -> EmptyState(
                                Icons.Rounded.Subscriptions, "No subscriptions yet",
                                "Subscribe to channels and their new videos show up here.",
                                action = { PrimaryButton("Find channels", { actions.search() }, icon = Icons.Rounded.Search) }
                            )
                            else -> EmptyState(
                                Icons.Rounded.Subscriptions,
                                "Nothing here right now",
                                if (lib.feed.isEmpty() && lib.subscriptions.isNotEmpty()) "Pull down to load the latest from ${lib.subscriptions.size} channels."
                                else "Try another chip, or loosen the feed filters in Settings."
                            )
                        }
                    }
                } else {
                    visible.forEachIndexed { i, v ->
                        item(key = "v:" + v.url) {
                            val sub = subsByKey[channelKey(v.uploaderUrl)]
                            VideoCard(
                                modifier = Modifier.animateItem(fadeInSpec = null, fadeOutSpec = null),
                                video = v,
                                avatar = sub?.avatar?.ifBlank { null } ?: v.uploaderAvatar,
                                progress = progress[v.url] ?: 0f,
                                onClick = { actions.video(v) },
                                onChannel = { actions.channel(v.uploaderUrl) },
                                onMore = { menuFor = v }
                            )
                        }
                        if (i == 1 && chip == HomeChip.ALL && shorts.isNotEmpty()) item(key = "shorts-shelf") {
                            ShortsShelf(shorts, onOpen = { idx -> actions.shorts(shorts, idx) }, onMore = { menuFor = it })
                        }
                    }
                    if (vm.loading) item { Loading() }
                }
                item { Spacer(Modifier.height(16.dp)) }
                if (feedProgress.failed > 0 && !feedProgress.running) item {
                    Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("${feedProgress.failed} channels couldn't be refreshed", color = Cl.TextFaint, fontSize = 12.sp)
                    }
                }
            }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}

/** The Shorts shelf between feed cards: logo row, then tall tiles. */
@Composable
fun ShortsShelf(shorts: List<VideoItem>, onOpen: (Int) -> Unit, onMore: (VideoItem) -> Unit) {
    Column(Modifier.padding(bottom = 22.dp)) {
        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            ShortsIcon(filled = true, color = Cl.Red)
            Spacer(Modifier.width(8.dp))
            Text("Shorts", color = Cl.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(shorts.size) { i ->
                val s = shorts[i]
                ShortTile(s, onClick = { onOpen(i) }, modifier = Modifier.width(168.dp), onMore = { onMore(s) })
            }
        }
    }
}

/** Shown on Home until you've subscribed to something. */
@UnstableApi
@Composable
private fun StarterCard() {
    val actions = LocalActions.current
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).padding(bottom = 12.dp)) {
        Column {
            Text("Make Seek yours", color = Cl.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Subscribe to channels or bring your subscriptions over from YouTube or NewPipe. No account, and nothing leaves your phone.",
                color = Cl.TextDim, fontSize = 13.sp, lineHeight = 18.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("Import", { actions.open(Routes.SETTINGS) })
                TonalButton("Find channels", { actions.search() })
            }
        }
    }
}
