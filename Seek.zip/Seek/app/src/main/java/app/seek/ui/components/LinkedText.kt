package app.seek.ui.components

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.TextUnit
import app.seek.ui.theme.Cl

private val TIME = Regex("(?<![\\d:])(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})(?![\\d:])")
private val URL = Regex("https?://[^\\s<>\"]+")
private val TAG = Regex("(?<![\\w&])#([\\p{L}\\p{N}_]{2,})")

/** "1:02:03" -> 3723000 ms. Null if it isn't a real time. */
fun parseTimestamp(text: String): Long? {
    val m = TIME.matchEntire(text.trim()) ?: return null
    val h = m.groupValues[1].toLongOrNull() ?: 0L
    val min = m.groupValues[2].toLongOrNull() ?: return null
    val sec = m.groupValues[3].toLongOrNull() ?: return null
    if (sec >= 60 || (h > 0 && min >= 60)) return null
    return ((h * 60 + min) * 60 + sec) * 1000L
}

private class Span(val start: Int, val end: Int, val kind: Int, val value: String)

/**
 * Text with the useful bits tappable, like on YouTube:
 *  - timestamps ("4:20") jump the video there,
 *  - links open (YouTube links stay inside Seek),
 *  - #hashtags search.
 * Anything not handed a callback stays plain text.
 */
@Composable
fun LinkedText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Cl.Text,
    fontSize: TextUnit = TextUnit.Unspecified,
    lineHeight: TextUnit = TextUnit.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
    onTimestamp: ((Long) -> Unit)? = null,
    onLink: ((String) -> Unit)? = null,
    onHashtag: ((String) -> Unit)? = null
) {
    // Latest callbacks, without rebuilding the text every time a lambda is recreated
    val ts by rememberUpdatedState(onTimestamp)
    val ln by rememberUpdatedState(onLink)
    val ht by rememberUpdatedState(onHashtag)
    val annotated = remember(text, onTimestamp != null, onLink != null, onHashtag != null) {
        build(
            text,
            if (onTimestamp != null) ({ ms: Long -> ts?.invoke(ms) }) else null,
            if (onLink != null) ({ u: String -> ln?.invoke(u) }) else null,
            if (onHashtag != null) ({ h: String -> ht?.invoke(h) }) else null
        )
    }
    Text(
        annotated,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        lineHeight = lineHeight,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

private fun build(
    text: String,
    onTimestamp: ((Long) -> Unit)?,
    onLink: ((String) -> Unit)?,
    onHashtag: ((String) -> Unit)?
): AnnotatedString {
    val spans = ArrayList<Span>()
    if (onLink != null) URL.findAll(text).forEach { m ->
        val url = m.value.trimEnd('.', ',', ')', ']', '!', '?', ';', ':', '\'')
        spans += Span(m.range.first, m.range.first + url.length, 0, url)
    }
    if (onTimestamp != null) TIME.findAll(text).forEach { m ->
        if (parseTimestamp(m.value) != null) spans += Span(m.range.first, m.range.last + 1, 1, m.value)
    }
    if (onHashtag != null) TAG.findAll(text).forEach { m ->
        spans += Span(m.range.first, m.range.last + 1, 2, m.value)
    }
    if (spans.isEmpty()) return AnnotatedString(text)
    // Links win over anything found inside them
    spans.sortWith(compareBy<Span> { it.start }.thenBy { it.kind })
    val style = TextLinkStyles(SpanStyle(color = Cl.Blue, fontWeight = FontWeight.Medium))
    return buildAnnotatedString {
        var at = 0
        for (sp in spans) {
            if (sp.start < at) continue
            append(text.substring(at, sp.start))
            val link = LinkAnnotation.Clickable("k${sp.kind}", style) {
                when (sp.kind) {
                    0 -> onLink?.invoke(sp.value)
                    1 -> parseTimestamp(sp.value)?.let { ms -> onTimestamp?.invoke(ms) }
                    else -> onHashtag?.invoke(sp.value)
                }
            }
            withLink(link) { append(text.substring(sp.start, sp.end)) }
            at = sp.end
        }
        if (at < text.length) append(text.substring(at))
    }
}
