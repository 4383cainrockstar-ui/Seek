package app.seek.player

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.dash.DefaultDashChunkSource
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.SingleSampleMediaSource
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.services.youtube.dashmanifestcreators.YoutubeOtfDashManifestCreator
import org.schabi.newpipe.extractor.services.youtube.dashmanifestcreators.YoutubePostLiveStreamDvrDashManifestCreator
import org.schabi.newpipe.extractor.services.youtube.dashmanifestcreators.YoutubeProgressiveDashManifestCreator
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.Stream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.ByteArrayInputStream

data class QualityOption(val label: String, val height: Int, val stream: VideoStream)

data class SubtitleOption(val id: String, val label: String, val language: String, val url: String, val auto: Boolean)

/** Turns a StreamInfo into something ExoPlayer can play, the same way NewPipe does. */
@UnstableApi
object Sources {

    private val dashDs by lazy { YtDataSource.Factory(rangeParameter = true, rnParameter = true) }
    private val progressiveDs by lazy { YtDataSource.Factory(rangeParameter = false, rnParameter = true) }
    private val plainDs by lazy { YtDataSource.Factory(rangeParameter = false, rnParameter = false) }

    private val dashFactory by lazy { DashMediaSource.Factory(DefaultDashChunkSource.Factory(dashDs), dashDs) }
    private val progressiveFactory by lazy { ProgressiveMediaSource.Factory(progressiveDs) }
    private val hlsFactory by lazy { HlsMediaSource.Factory(plainDs).setAllowChunklessPreparation(true) }
    private val liveDashFactory by lazy { DashMediaSource.Factory(DefaultDashChunkSource.Factory(plainDs), plainDs) }

    // ---------------------------------------------------------------------------------------
    // Choosing streams
    // ---------------------------------------------------------------------------------------

    private fun heightOf(v: VideoStream): Int {
        if (v.height > 0) return v.height
        return Regex("(\\d+)p").find(v.getResolution())?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    private fun playable(s: Stream): Boolean =
        s.isUrl && s.content.isNotBlank() &&
            (s.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP || s.deliveryMethod == DeliveryMethod.DASH ||
                s.deliveryMethod == DeliveryMethod.HLS)

    /** Every distinct resolution, best stream per resolution (prefer MP4/AVC, then WebM). */
    fun qualities(info: StreamInfo): List<QualityOption> {
        val candidates = (info.videoOnlyStreams + info.videoStreams).filter { playable(it) }
        return candidates
            .groupBy { it.getResolution().ifBlank { heightOf(it).toString() + "p" } }
            .mapNotNull { (label, list) ->
                val best = list.sortedWith(
                    compareByDescending<VideoStream> { it.isVideoOnly() } // adaptive streams first
                        .thenByDescending { it.format == MediaFormat.MPEG_4 }
                        .thenByDescending { (it.codec ?: "").startsWith("avc") }
                        .thenByDescending { it.fps }
                ).firstOrNull() ?: return@mapNotNull null
                QualityOption(label, heightOf(best), best)
            }
            .sortedWith(compareByDescending<QualityOption> { it.height }.thenByDescending { it.stream.fps })
    }

    fun pickQuality(options: List<QualityOption>, preferred: Int): QualityOption? {
        if (options.isEmpty()) return null
        return options.filter { it.height in 1..preferred }.maxByOrNull { it.height }
            ?: options.minByOrNull { if (it.height <= 0) Int.MAX_VALUE else it.height }
    }

    fun bestAudio(info: StreamInfo): AudioStream? {
        val list = info.audioStreams.filter { playable(it) }
        if (list.isEmpty()) return null
        val original = list.filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
        val pool = original.ifEmpty { list }
        return pool.sortedWith(
            compareByDescending<AudioStream> { it.format == MediaFormat.M4A }
                .thenByDescending { it.averageBitrate }
        ).firstOrNull()
    }

    fun subtitles(info: StreamInfo): List<SubtitleOption> =
        info.subtitles
            .filter { it.format == MediaFormat.VTT && it.content.isNotBlank() }
            .distinctBy { it.languageTag + it.isAutoGenerated }
            .map { s ->
                val name = try {
                    s.displayLanguageName
                } catch (e: Exception) {
                    s.languageTag
                }
                SubtitleOption(
                    id = "sub-" + s.languageTag + if (s.isAutoGenerated) "-auto" else "",
                    label = name + if (s.isAutoGenerated) " (auto)" else "",
                    language = s.languageTag,
                    url = s.content,
                    auto = s.isAutoGenerated
                )
            }
            .sortedWith(compareBy<SubtitleOption> { it.auto }.thenBy { it.label })

    fun isLive(info: StreamInfo) =
        info.streamType == StreamType.LIVE_STREAM || info.streamType == StreamType.AUDIO_LIVE_STREAM

    // ---------------------------------------------------------------------------------------
    // Building media sources
    // ---------------------------------------------------------------------------------------

    fun build(
        info: StreamInfo,
        quality: QualityOption?,
        audioOnly: Boolean,
        subs: List<SubtitleOption>,
        metadata: MediaMetadata
    ): MediaSource {
        val mediaId = info.url ?: ""

        if (isLive(info)) {
            val item = MediaItem.Builder()
                .setMediaId(mediaId)
                .setMediaMetadata(metadata)
                .setLiveConfiguration(MediaItem.LiveConfiguration.Builder().setTargetOffsetMs(10_000).build())
            return when {
                !info.hlsUrl.isNullOrBlank() -> hlsFactory.createMediaSource(item.setUri(info.hlsUrl).build())
                !info.dashMpdUrl.isNullOrBlank() -> liveDashFactory.createMediaSource(item.setUri(info.dashMpdUrl).build())
                else -> throw IllegalStateException("This livestream has no playable source")
            }
        }

        val audio = bestAudio(info)
        val sources = mutableListOf<MediaSource>()

        if (audioOnly && audio != null) {
            sources += streamSource(info, audio, metadata, mediaId)
        } else {
            val video = quality?.stream ?: qualities(info).firstOrNull()?.stream
            when {
                video == null && audio != null -> sources += streamSource(info, audio, metadata, mediaId)
                video == null -> {
                    if (!info.hlsUrl.isNullOrBlank()) {
                        return hlsFactory.createMediaSource(
                            MediaItem.Builder().setUri(info.hlsUrl).setMediaId(mediaId).setMediaMetadata(metadata).build()
                        )
                    }
                    throw IllegalStateException("No playable streams found for this video")
                }
                video.isVideoOnly() -> {
                    sources += streamSource(info, video, metadata, mediaId)
                    if (audio != null) sources += streamSource(info, audio, MediaMetadata.EMPTY, mediaId + "#audio")
                }
                else -> sources += streamSource(info, video, metadata, mediaId)
            }
            subs.forEach { sources += subtitleSource(it) }
        }

        return if (sources.size == 1) sources[0] else MergingMediaSource(true, *sources.toTypedArray())
    }

    private fun streamSource(info: StreamInfo, stream: Stream, metadata: MediaMetadata, mediaId: String): MediaSource {
        val item = MediaItem.Builder()
            .setUri(Uri.parse(stream.content))
            .setMediaId(mediaId)
            .setMediaMetadata(metadata)
            .setCustomCacheKey(mediaId + "|" + stream.id)
            .build()
        val itag = stream.itagItem
        val duration = info.duration

        try {
            if (info.streamType == StreamType.POST_LIVE_STREAM && itag != null) {
                val manifest = YoutubePostLiveStreamDvrDashManifestCreator.fromPostLiveStreamDvrStreamingUrl(
                    stream.content, itag, itag.targetDurationSec, duration
                )
                return dashFromString(manifest, stream.content, item)
            }
            when (stream.deliveryMethod) {
                DeliveryMethod.DASH -> if (itag != null) {
                    val manifest = YoutubeOtfDashManifestCreator.fromOtfStreamingUrl(stream.content, itag, duration)
                    return dashFromString(manifest, stream.content, item)
                }
                DeliveryMethod.HLS -> return hlsFactory.createMediaSource(item)
                else -> {
                    val adaptive = (stream is VideoStream && stream.isVideoOnly()) || stream is AudioStream
                    if (adaptive && itag != null) {
                        val manifest = YoutubeProgressiveDashManifestCreator.fromProgressiveStreamingUrl(
                            stream.content, itag, duration
                        )
                        return dashFromString(manifest, stream.content, item)
                    }
                }
            }
        } catch (e: Exception) {
            // fall through to a plain progressive source
        }
        return progressiveFactory.createMediaSource(item)
    }

    private fun dashFromString(manifest: String, url: String, item: MediaItem): MediaSource {
        val parsed = DashManifestParser().parse(
            Uri.parse(url),
            ByteArrayInputStream(manifest.toByteArray(Charsets.UTF_8))
        )
        return dashFactory.createMediaSource(parsed, item)
    }

    private fun subtitleSource(sub: SubtitleOption): MediaSource {
        val config = MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub.url))
            .setMimeType(MimeTypes.TEXT_VTT)
            .setLanguage(sub.language)
            .setLabel(sub.label)
            .setId(sub.id)
            .setSelectionFlags(0)
            .build()
        // A failing caption download must never kill playback
        return SingleSampleMediaSource.Factory(plainDs)
            .setTreatLoadErrorsAsEndOfStream(true)
            .createMediaSource(config, C.TIME_UNSET)
    }

    fun metadata(title: String, artist: String, artwork: String): MediaMetadata =
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setDisplayTitle(title)
            .apply { if (artwork.isNotBlank()) setArtworkUri(Uri.parse(artwork)) }
            .build()
}
