package app.seek.player

import android.content.Context
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.text.TextRenderer
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.core.toVideo
import app.seek.data.Library
import app.seek.data.Settings
import app.seek.extras.Dislikes
import app.seek.extras.SbSegment
import app.seek.extras.SponsorBlock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.stream.StreamInfo

data class NowPlaying(
    val item: VideoItem,
    val info: StreamInfo? = null,
    val loading: Boolean = true,
    val error: String? = null,
    val qualities: List<QualityOption> = emptyList(),
    val quality: QualityOption? = null,
    val audioOnly: Boolean = false,
    val subtitles: List<SubtitleOption> = emptyList(),
    val subtitleId: String? = null,
    val segments: List<SbSegment> = emptyList(),
    val likes: Long = -1,
    val dislikes: Long = -1,
    val related: List<VideoItem> = emptyList(),
    val isLive: Boolean = false,
    val description: String = "",
    val subscriberCount: Long = -1,
    val channelAvatar: String = "",
    val isLocal: Boolean = false
)

/** Renderers with classic WebVTT decoding switched on (captions arrive as raw text/vtt). */
@UnstableApi
private class SeekRenderers(ctx: Context) : DefaultRenderersFactory(ctx) {
    init {
        setEnableDecoderFallback(true)
    }

    override fun buildTextRenderers(
        context: Context,
        output: TextOutput,
        outputLooper: Looper,
        extensionRendererMode: Int,
        out: ArrayList<Renderer>
    ) {
        out.add(TextRenderer(output, outputLooper).apply { experimentalSetLegacyDecodingEnabled(true) })
    }
}

/** Player wrapper that exposes "next" to the notification / lockscreen. */
@UnstableApi
private class SeekSessionPlayer(player: Player) : ForwardingPlayer(player) {
    override fun getAvailableCommands(): Player.Commands =
        super.getAvailableCommands().buildUpon()
            .add(Player.COMMAND_SEEK_TO_NEXT)
            .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
            .build()

    override fun isCommandAvailable(command: Int): Boolean =
        command == Player.COMMAND_SEEK_TO_NEXT || command == Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM ||
            super.isCommandAvailable(command)

    override fun seekToNext() = PlayerController.playNext()
    override fun seekToNextMediaItem() = PlayerController.playNext()
}

/**
 * The one and only player. Lives for the whole process so playback survives
 * screen changes, PiP and the app going to the background.
 */
@UnstableApi
object PlayerController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var initialized = false
    private lateinit var appContext: Context

    lateinit var exo: ExoPlayer
        private set
    lateinit var sessionPlayer: Player
        private set

    private val _now = MutableStateFlow<NowPlaying?>(null)
    val now: StateFlow<NowPlaying?> = _now.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _buffering = MutableStateFlow(false)
    val buffering: StateFlow<Boolean> = _buffering.asStateFlow()

    private val _speed = MutableStateFlow(1f)
    val speed: StateFlow<Float> = _speed.asStateFlow()

    private val _loop = MutableStateFlow(false)
    val loop: StateFlow<Boolean> = _loop.asStateFlow()

    /** Epoch ms when playback stops, or [SLEEP_END_OF_VIDEO], or null. */
    private val _sleepAt = MutableStateFlow<Long?>(null)
    val sleepAt: StateFlow<Long?> = _sleepAt.asStateFlow()
    const val SLEEP_END_OF_VIDEO = -1L

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private var loadJob: Job? = null
    private var tickJob: Job? = null
    private val skipped = mutableSetOf<String>()
    private var retriedFor: String? = null
    private val recent = ArrayDeque<String>()

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        val app = ctx.applicationContext
        appContext = app
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        exo = ExoPlayer.Builder(app, SeekRenderers(app))
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        sessionPlayer = SeekSessionPlayer(exo)
        // "Keep playing during calls": follows the setting live
        val focus = CallFocus(app, exo, attrs)
        scope.launch {
            Settings.state.map { it.keepDuringCalls }.distinctUntilChanged().collect { focus.setEnabled(it) }
        }
        _speed.value = Settings.current.defaultSpeed

        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (!isPlaying) saveProgress()
            }

            override fun onPlaybackStateChanged(state: Int) {
                _buffering.value = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) onEnded()
            }

            override fun onTracksChanged(tracks: Tracks) = applySubtitleSelection()

            override fun onPlayerError(error: PlaybackException) = handleError(error)
        })
    }

    // ------------------------------------------------------------------------------------
    // Loading
    // ------------------------------------------------------------------------------------

    private var queue: List<VideoItem> = emptyList()
    private var queueIndex = -1
    private val _queueState = MutableStateFlow<Pair<Int, Int>?>(null)
    /** (current position, size) when playing through a playlist. */
    val queueState: StateFlow<Pair<Int, Int>?> = _queueState.asStateFlow()

    /** The whole queue and where you are in it (empty when there's no queue). */
    data class Queue(val items: List<VideoItem> = emptyList(), val index: Int = -1, val name: String = "") {
        val upNext: List<VideoItem> get() = if (index in items.indices) items.drop(index + 1) else emptyList()
    }

    private val _queue = MutableStateFlow(Queue())
    val queueFlow: StateFlow<Queue> = _queue.asStateFlow()
    private var queueName = ""

    private fun publishQueue() {
        if (queue.isEmpty() || queueIndex < 0) {
            _queueState.value = null
            _queue.value = Queue()
        } else {
            _queueState.value = queueIndex + 1 to queue.size
            _queue.value = Queue(queue, queueIndex, queueName)
        }
    }

    /** True while the Shorts tab is driving the player: loops, no autoplay, no resume. */
    private var shortsMode = false

    fun play(item: VideoItem, startMs: Long? = null, audioOnly: Boolean? = null) {
        shortsMode = false
        queue = emptyList()
        queueIndex = -1
        queueName = ""
        publishQueue()
        load(item, startMs, audioOnly)
    }

    /** A Short from the Shorts tab: starts at 0, loops, always shows the picture. */
    fun playShort(item: VideoItem) {
        queue = emptyList()
        queueIndex = -1
        queueName = ""
        publishQueue()
        shortsMode = true
        if (_now.value?.item?.url == item.url && _now.value?.error == null) {
            exo.repeatMode = Player.REPEAT_MODE_ONE
            if (!exo.isPlaying) exo.play()
            return
        }
        load(item, 0L, false)
    }

    /** Leaving the Shorts tab stops the Short that was playing (normal videos keep going). */
    fun stopShorts() {
        if (shortsMode) stop()
    }

    /** Plays a list in order (or shuffled); "next" walks the list instead of related videos. */
    fun playQueue(items: List<VideoItem>, index: Int = 0, shuffle: Boolean = false, name: String = "") {
        if (items.isEmpty()) return
        shortsMode = false
        queue = if (shuffle) items.shuffled() else items
        queueIndex = if (shuffle) 0 else index.coerceIn(0, items.size - 1)
        queueName = name
        publishQueue()
        load(queue[queueIndex], null, null)
    }

    // ------------------------------------------------------------------------------------
    // Your queue: Play next / Add to queue, reorder, remove
    // ------------------------------------------------------------------------------------

    /** Starts a queue from what's playing now (if it isn't one already). */
    private fun ensureQueue(): Boolean {
        if (queue.isNotEmpty() && queueIndex >= 0) return true
        val cur = _now.value?.item ?: return false
        if (shortsMode) return false
        queue = listOf(cur)
        queueIndex = 0
        queueName = ""
        return true
    }

    /** Puts [item] right after what's playing. Plays it straight away if nothing is. */
    fun queueNext(item: VideoItem) {
        if (!ensureQueue()) {
            playQueue(listOf(item))
            return
        }
        val rest = queue.filterIndexed { i, v -> i <= queueIndex || v.url != item.url }
        queue = rest.take(queueIndex + 1) + item + rest.drop(queueIndex + 1)
        publishQueue()
    }

    /** Adds [item] to the end of the queue. Plays it straight away if nothing is playing. */
    fun addToQueue(item: VideoItem) {
        if (!ensureQueue()) {
            playQueue(listOf(item))
            return
        }
        if (queue.drop(queueIndex + 1).any { it.url == item.url }) return
        queue = queue + item
        publishQueue()
    }

    fun addAllToQueue(items: List<VideoItem>) {
        if (items.isEmpty()) return
        if (!ensureQueue()) {
            playQueue(items)
            return
        }
        val have = queue.drop(queueIndex + 1).map { it.url }.toHashSet()
        queue = queue + items.filter { have.add(it.url) }
        publishQueue()
    }

    fun removeFromQueue(index: Int) {
        if (index !in queue.indices || index == queueIndex) return
        queue = queue.toMutableList().also { it.removeAt(index) }
        if (index < queueIndex) queueIndex--
        publishQueue()
    }

    /** Drag-to-reorder: moves one item a step at a time (the playing one keeps playing). */
    fun moveInQueue(from: Int, to: Int) {
        if (from !in queue.indices || to !in queue.indices || from == to) return
        val list = queue.toMutableList()
        val v = list.removeAt(from)
        list.add(to, v)
        queueIndex = when (queueIndex) {
            from -> to
            in (minOf(from, to)..maxOf(from, to)) -> if (from < to) queueIndex - 1 else queueIndex + 1
            else -> queueIndex
        }
        queue = list
        publishQueue()
    }

    fun playFromQueue(index: Int) {
        if (index !in queue.indices || index == queueIndex) return
        queueIndex = index
        publishQueue()
        load(queue[queueIndex], null, null)
    }

    /** Clears everything after what's playing. */
    fun clearUpNext() {
        if (queueIndex < 0) return
        queue = queue.take(queueIndex + 1)
        if (queue.size <= 1) {
            queue = emptyList()
            queueIndex = -1
            queueName = ""
        }
        publishQueue()
    }

    // ------------------------------------------------------------------------------------
    // Hold for 2x: a temporary speed that doesn't change your chosen one
    // ------------------------------------------------------------------------------------

    private val _boosted = MutableStateFlow(false)
    val boosted: StateFlow<Boolean> = _boosted.asStateFlow()

    fun startBoost(speed: Float = 2f) {
        if (_boosted.value || !exo.isPlaying) return
        _boosted.value = true
        exo.setPlaybackSpeed(maxOf(speed, _speed.value))
    }

    fun endBoost() {
        if (!_boosted.value) return
        _boosted.value = false
        exo.setPlaybackSpeed(_speed.value)
    }

    private fun load(item: VideoItem, startMs: Long?, audioOnly: Boolean?) {
        if (_now.value?.item?.url == item.url && _now.value?.error == null && _now.value?.loading == false) {
            if (audioOnly != null) setAudioOnly(audioOnly)
            if (!exo.isPlaying) exo.play()
            return
        }
        saveProgress()
        loadJob?.cancel()
        _boosted.value = false
        exo.stop()
        exo.clearMediaItems()
        skipped.clear()
        retriedFor = null
        rememberRecent(item.url)
        _now.value = NowPlaying(item = item, audioOnly = audioOnly ?: Settings.current.audioOnlyDefault)

        loadJob = scope.launch {
            try {
                val info = Yt.stream(item.url)
                val settings = Settings.current
                val full = info.toVideo().let { v ->
                    v.copy(
                        thumbnail = v.thumbnail.ifBlank { item.thumbnail },
                        uploaderAvatar = v.uploaderAvatar.ifBlank { item.uploaderAvatar }
                    )
                }
                val qualities = Sources.qualities(info)
                val subs = Sources.subtitles(info)
                val history = Library.progressFor(item.url)
                val resume = startMs ?: if (settings.resumePlayback && history != null &&
                    history.positionMs > 5_000 &&
                    (history.durationMs <= 0 || history.positionMs < history.durationMs - 15_000)
                ) history.positionMs else 0L

                val description = try {
                    val raw = info.description?.content() ?: ""
                    android.text.Html.fromHtml(raw, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
                } catch (e: Exception) {
                    ""
                }

                _now.value = NowPlaying(
                    item = full,
                    info = info,
                    loading = false,
                    qualities = qualities,
                    quality = Sources.pickQuality(qualities, settings.defaultQuality),
                    audioOnly = _now.value?.audioOnly ?: settings.audioOnlyDefault,
                    subtitles = subs,
                    subtitleId = if (settings.captionsByDefault) pickDefaultSubtitle(subs) else null,
                    likes = info.likeCount,
                    related = Yt.related(info).filterNot { it.url == item.url },
                    isLive = Sources.isLive(info),
                    description = description,
                    subscriberCount = info.uploaderSubscriberCount,
                    channelAvatar = full.uploaderAvatar
                )
                startSource(resume)
                Library.addHistory(full)
                startTicker()

                val id = info.id ?: ""
                if (settings.sponsorBlock && id.isNotBlank()) launch {
                    val segs = SponsorBlock.segments(id)
                    _now.update { if (it != null && it.item.url == item.url) it.copy(segments = segs) else it }
                }
                if (settings.returnDislikes && id.isNotBlank()) launch {
                    val v = Dislikes.votes(id)
                    if (v != null) _now.update {
                        if (it != null && it.item.url == item.url) it.copy(
                            dislikes = v.dislikes,
                            likes = if (it.likes <= 0) v.likes else it.likes
                        ) else it
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _now.update { it?.copy(loading = false, error = Yt.friendlyError(e)) }
            }
        }
    }

    /** Plays a downloaded file straight from storage, fully offline. */
    fun playLocal(item: VideoItem, uri: android.net.Uri, audioOnly: Boolean) {
        saveProgress()
        loadJob?.cancel()
        exo.stop()
        exo.clearMediaItems()
        _now.value = NowPlaying(item = item, loading = false, audioOnly = audioOnly, isLocal = true)
        val media = androidx.media3.common.MediaItem.Builder()
            .setUri(uri)
            .setMediaId("local:" + item.url)
            .setMediaMetadata(Sources.metadata(item.title, item.uploader, item.thumbnail))
            .build()
        val source = androidx.media3.exoplayer.source.ProgressiveMediaSource.Factory(
            androidx.media3.datasource.DefaultDataSource.Factory(appContext)
        ).createMediaSource(media)
        exo.setMediaSource(source)
        exo.setPlaybackSpeed(_speed.value)
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun pickDefaultSubtitle(subs: List<SubtitleOption>): String? {
        if (subs.isEmpty()) return null
        val lang = java.util.Locale.getDefault().language
        return (subs.firstOrNull { !it.auto && it.language.startsWith(lang) }
            ?: subs.firstOrNull { it.language.startsWith(lang) }
            ?: subs.firstOrNull { !it.auto })?.id
    }

    private fun startSource(positionMs: Long) {
        val n = _now.value ?: return
        val info = n.info ?: return
        val source = try {
            Sources.build(
                info = info,
                quality = n.quality,
                audioOnly = n.audioOnly,
                subs = n.subtitles,
                metadata = Sources.metadata(n.item.title, n.item.uploader, n.item.thumbnail)
            )
        } catch (e: Exception) {
            _now.update { it?.copy(error = Yt.friendlyError(e)) }
            return
        }
        exo.setMediaSource(source, positionMs.coerceAtLeast(0))
        exo.repeatMode = if (_loop.value || shortsMode) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        exo.setPlaybackSpeed(_speed.value)
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun rebuild() {
        val pos = exo.currentPosition
        val wasPlaying = exo.playWhenReady
        startSource(pos)
        exo.playWhenReady = wasPlaying
    }

    fun retry() {
        val item = _now.value?.item ?: return
        val pos = exo.currentPosition
        _now.value = null
        load(item, if (pos > 0) pos else null, null)
    }

    fun hasNext(): Boolean =
        (queueIndex >= 0 && queueIndex < queue.size - 1) || _now.value?.related?.isNotEmpty() == true

    // ------------------------------------------------------------------------------------
    // Controls
    // ------------------------------------------------------------------------------------

    fun togglePlay() {
        if (exo.playbackState == Player.STATE_ENDED) {
            exo.seekTo(0)
            exo.play()
        } else if (exo.isPlaying) exo.pause() else {
            if (exo.playbackState == Player.STATE_IDLE) exo.prepare()
            exo.play()
        }
    }

    fun seekBy(ms: Long) {
        val d = exo.duration
        var target = exo.currentPosition + ms
        if (d != C.TIME_UNSET && d > 0) target = target.coerceAtMost(d - 500)
        exo.seekTo(target.coerceAtLeast(0))
    }

    fun seekTo(ms: Long) = exo.seekTo(ms.coerceAtLeast(0))

    fun setQuality(q: QualityOption) {
        _now.update { it?.copy(quality = q, audioOnly = false) }
        rebuild()
    }

    fun setAudioOnly(on: Boolean) {
        if (_now.value?.audioOnly == on) return
        _now.update { it?.copy(audioOnly = on) }
        rebuild()
    }

    fun setSubtitle(id: String?) {
        _now.update { it?.copy(subtitleId = id) }
        applySubtitleSelection()
    }

    fun setSpeed(s: Float) {
        _speed.value = s
        _boosted.value = false
        exo.setPlaybackSpeed(s)
    }

    fun toggleLoop() {
        _loop.value = !_loop.value
        exo.repeatMode = if (_loop.value) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun setSleepTimer(minutes: Int?) {
        _sleepAt.value = when {
            minutes == null -> null
            minutes < 0 -> SLEEP_END_OF_VIDEO
            else -> System.currentTimeMillis() + minutes * 60_000L
        }
        if (minutes != null) _events.tryEmit(if (minutes < 0) "Stopping after this video" else "Sleep timer: $minutes min")
    }

    fun stop() {
        shortsMode = false
        saveProgress()
        loadJob?.cancel()
        tickJob?.cancel()
        exo.stop()
        exo.clearMediaItems()
        _now.value = null
        _sleepAt.value = null
        queue = emptyList()
        queueIndex = -1
        queueName = ""
        publishQueue()
        _boosted.value = false
    }

    fun playNext() {
        if (queueIndex >= 0 && queueIndex < queue.size - 1) {
            queueIndex++
            publishQueue()
            load(queue[queueIndex], null, null)
            return
        }
        val n = _now.value ?: return
        val next = n.related.firstOrNull { it.url !in recent && !it.isLive } ?: n.related.firstOrNull()
        if (next != null) play(next)
    }

    /** Back to the start, or (near the start) the previous video in the queue / your history. */
    fun playPrevious() {
        if (exo.currentPosition > 3_000 || _now.value == null) {
            exo.seekTo(0)
            return
        }
        if (queueIndex > 0) {
            queueIndex--
            publishQueue()
            load(queue[queueIndex], null, null)
            return
        }
        val cur = _now.value?.item?.url
        val prev = Library.value.history.firstOrNull { it.video.url != cur }?.video
        if (prev != null) play(prev) else exo.seekTo(0)
    }

    private fun rememberRecent(url: String) {
        recent.addLast(url)
        while (recent.size > 30) recent.removeFirst()
    }

    // ------------------------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------------------------

    private fun applySubtitleSelection() {
        if (!initialized) return
        val wanted = _now.value?.subtitleId
        val builder = exo.trackSelectionParameters.buildUpon()
        if (wanted == null) {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).clearOverridesOfType(C.TRACK_TYPE_TEXT)
        } else {
            var override: TrackSelectionOverride? = null
            for (group in exo.currentTracks.groups) {
                if (group.type != C.TRACK_TYPE_TEXT) continue
                for (i in 0 until group.length) {
                    val id = group.getTrackFormat(i).id ?: continue
                    if (id == wanted || id.endsWith(":$wanted")) {
                        override = TrackSelectionOverride(group.mediaTrackGroup, i)
                    }
                }
            }
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            if (override != null) builder.setOverrideForType(override)
        }
        val params = builder.build()
        if (params != exo.trackSelectionParameters) exo.trackSelectionParameters = params
    }

    private fun onEnded() {
        saveProgress(finished = true)
        if (_sleepAt.value == SLEEP_END_OF_VIDEO) {
            _sleepAt.value = null
            return
        }
        if (Settings.current.autoplay && !_loop.value && !shortsMode) playNext()
    }

    private fun handleError(error: PlaybackException) {
        val n = _now.value ?: return
        if (n.isLocal) {
            _now.update { it?.copy(error = "Couldn't play this file: " + (error.message ?: error.errorCodeName)) }
            return
        }
        // Stream URLs expire after a few hours, or YouTube rotates them: refetch once and resume
        if (retriedFor != n.item.url) {
            retriedFor = n.item.url
            val pos = exo.currentPosition
            val item = n.item
            scope.launch {
                try {
                    val info = Yt.stream(item.url)
                    val qualities = Sources.qualities(info)
                    _now.update { cur ->
                        if (cur == null) null else {
                            val keep = cur.quality?.let { q -> qualities.firstOrNull { o -> o.label == q.label } }
                            cur.copy(
                                info = info,
                                qualities = qualities,
                                quality = keep ?: Sources.pickQuality(qualities, Settings.current.defaultQuality),
                                subtitles = Sources.subtitles(info)
                            )
                        }
                    }
                    startSource(pos)
                } catch (e: Exception) {
                    _now.update { it?.copy(error = Yt.friendlyError(e)) }
                }
            }
        } else {
            _now.update { it?.copy(error = "Playback error: " + (error.message ?: error.errorCodeName)) }
        }
    }

    private fun startTicker() {
        if (tickJob?.isActive == true) return
        tickJob = scope.launch {
            var lastSave = 0L
            while (isActive) {
                delay(400)
                val n = _now.value ?: continue
                if (!exo.isPlaying) continue
                val pos = exo.currentPosition

                // SponsorBlock auto-skip
                val cats = Settings.current.sponsorCategories
                if (Settings.current.sponsorBlock) {
                    val seg = n.segments.firstOrNull {
                        it.category in cats && pos >= it.startMs && pos < it.endMs - 300 && it.uuid !in skipped
                    }
                    if (seg != null) {
                        skipped += seg.uuid
                        exo.seekTo(seg.endMs)
                        _events.tryEmit("Skipped " + SponsorBlock.label(seg.category).lowercase())
                    }
                }

                // Sleep timer
                val sleep = _sleepAt.value
                if (sleep != null && sleep > 0 && System.currentTimeMillis() >= sleep) {
                    _sleepAt.value = null
                    exo.pause()
                    _events.tryEmit("Sleep timer ended")
                }

                if (System.currentTimeMillis() - lastSave > 5_000) {
                    lastSave = System.currentTimeMillis()
                    saveProgress()
                }
            }
        }
    }

    private fun saveProgress(finished: Boolean = false) {
        if (!initialized) return
        val n = _now.value ?: return
        if (n.info == null || n.isLive) return
        val d = exo.duration
        if (d == C.TIME_UNSET || d <= 0) return
        val pos = if (finished) d else exo.currentPosition
        Library.saveProgress(n.item.url, pos, d)
    }
}
