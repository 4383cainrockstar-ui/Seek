package app.seek.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Comment
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.CircularProgressIndicator
import app.seek.ui.components.EchoLoader
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import app.seek.core.Fmt
import app.seek.core.ListEntry
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.core.videoIdFromUrl
import app.seek.data.Library
import app.seek.player.NowPlaying
import app.seek.player.PlayerController
import app.seek.ui.LocalActions
import app.seek.ui.UiState
import app.seek.ui.components.Avatar
import app.seek.ui.components.EmptyState
import app.seek.ui.components.ErrorBox
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.theme.Cl
import coil.compose.AsyncImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

/**
 * Where Shorts come from: new Shorts from your subscriptions first, then YouTube's
 * own "#shorts" results, loaded endlessly as you swipe.
 */
class ShortsVm : ViewModel() {
    var items by mutableStateOf<List<VideoItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    /** Bumped when the list is replaced, so the pager jumps to [startIndex]. */
    var generation by mutableIntStateOf(0)
        private set
    var startIndex = 0
        private set

    private var started = false
    private var searched = false
    private var next: Page? = null
    private var job: Job? = null

    private fun List<ListEntry>.shortsOnly(): List<VideoItem> =
        filterIsInstance<ListEntry.Video>().map { it.item }
            .filter { !it.isLive && (it.isShort || it.duration in 1..180) }

    /** [seed]: Shorts tapped on a shelf. Null opens the tab normally. */
    fun begin(seed: UiState.ShortsStart?) {
        if (seed != null) {
            job?.cancel()
            items = seed.items.distinctBy { it.url }
            startIndex = seed.index
            generation++
            started = true
            searched = false
            next = null
            loadMore()
            return
        }
        if (started) return
        started = true
        reload()
    }

    fun reload() {
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            error = null
            try {
                val watched = Library.watchedUrls()
                val fromSubs = Library.value.feed.filter { it.isShort && it.url !in watched }.take(30).shuffled()
                val p = Yt.search(QUERY, Yt.FILTER_VIDEOS)
                searched = true
                next = p.next
                val found = p.items.shortsOnly()
                // A couple from your subscriptions, then one from YouTube, and so on
                val mixed = ArrayList<VideoItem>()
                val a = fromSubs.iterator()
                val b = found.iterator()
                while (a.hasNext() || b.hasNext()) {
                    repeat(2) { if (a.hasNext()) mixed += a.next() }
                    if (b.hasNext()) mixed += b.next()
                }
                items = mixed.distinctBy { it.url }
                startIndex = 0
                generation++
                if (items.isEmpty()) error = "Couldn't find any Shorts right now."
            } catch (e: Exception) {
                if (items.isEmpty()) error = Yt.friendlyError(e)
            } finally {
                loading = false
            }
        }
    }

    fun loadMore() {
        if (loading) return
        val page = next
        if (searched && page == null) return
        job = viewModelScope.launch {
            loading = true
            try {
                val p = if (page == null) Yt.search(QUERY, Yt.FILTER_VIDEOS) else Yt.searchMore(QUERY, Yt.FILTER_VIDEOS, page)
                searched = true
                next = p.next
                items = (items + p.items.shortsOnly()).distinctBy { it.url }
            } catch (_: Exception) {
            } finally {
                loading = false
            }
        }
    }

    private companion object {
        const val QUERY = "#shorts"
    }
}

private fun sameVideo(a: String, b: String): Boolean {
    val x = videoIdFromUrl(a)
    return if (x != null) x == videoIdFromUrl(b) else a == b
}

@UnstableApi
@Composable
fun ShortsScreen() {
    val vm: ShortsVm = viewModel()
    val start by UiState.shortsStart.collectAsState()
    LaunchedEffect(start) {
        vm.begin(start)
        if (start != null) UiState.shortsStart.value = null
    }
    // Leaving the tab stops the Short
    DisposableEffect(Unit) { onDispose { PlayerController.stopShorts() } }

    val items = vm.items
    val pager = rememberPagerState(initialPage = vm.startIndex) { items.size }
    val now by PlayerController.now.collectAsState()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    var commentsFor by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(vm.generation) {
        if (items.isNotEmpty()) pager.scrollToPage(vm.startIndex.coerceIn(0, items.size - 1))
    }
    // Play whichever Short has settled on screen; load more before the end
    val settled = items.getOrNull(pager.settledPage)
    LaunchedEffect(settled?.url) {
        settled?.let { PlayerController.playShort(it) }
    }
    LaunchedEffect(pager.settledPage, items.size) {
        if (items.isNotEmpty() && pager.settledPage >= items.size - 4) vm.loadMore()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when {
            items.isEmpty() && vm.loading -> EchoLoader(Modifier.align(Alignment.Center), size = 48.dp)
            items.isEmpty() && vm.error != null -> Box(Modifier.align(Alignment.Center)) {
                ErrorBox(vm.error ?: "", onRetry = { vm.reload() })
            }
            items.isEmpty() -> EmptyState(Icons.Rounded.PlayArrow, "No Shorts yet", "Pull them in by subscribing to a few channels.")
            else -> VerticalPager(
                state = pager,
                beyondViewportPageCount = 1,
                key = { items.getOrNull(it)?.url ?: it },
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val v = items[page]
                val active = page == pager.settledPage
                val n = now?.takeIf { active && sameVideo(it.item.url, v.url) }
                ShortPage(
                    v = v,
                    n = n,
                    active = active,
                    onComments = { commentsFor = v.url },
                    onMore = { menuFor = v }
                )
            }
        }

        // Search, top right, like YouTube's Shorts header
        val actions = LocalActions.current
        Row(
            Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(4.dp)
        ) {
            IconButton(onClick = { actions.search() }) {
                Icon(Icons.Rounded.Search, "Search", tint = Color.White, modifier = Modifier.size(26.dp))
            }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
    commentsFor?.let { url -> CommentsSheet(url, onDismiss = { commentsFor = null }) }
}

@UnstableApi
@Composable
private fun ShortPage(
    v: VideoItem,
    n: NowPlaying?,
    active: Boolean,
    onComments: () -> Unit,
    onMore: () -> Unit
) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val buffering by PlayerController.buffering.collectAsState()
    var flash by remember { mutableIntStateOf(0) }
    val item = n?.item ?: v
    val channelUrl = item.uploaderUrl
    val subscribed = channelUrl.isNotBlank() && lib.subscriptions.any { Library.sameChannel(it.url, channelUrl) }

    Box(Modifier.fillMaxSize()) {
        // Cover until the video shows up
        if (v.thumbnail.isNotBlank()) {
            AsyncImage(v.thumbnail, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        if (active && n != null && !n.loading && n.error == null) ShortSurface(playing)

        // Tap = pause / play, hold = 2x while your finger is down
        val boosted by PlayerController.boosted.collectAsState()
        val haptics = androidx.compose.ui.platform.LocalHapticFeedback.current
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(active) {
                    detectTapGestures(
                        onPress = {
                            tryAwaitRelease()
                            PlayerController.endBoost()
                        },
                        onLongPress = {
                            if (active && PlayerController.exo.isPlaying) {
                                PlayerController.startBoost()
                                haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                            }
                        },
                        onTap = {
                            if (active) {
                                PlayerController.togglePlay()
                                flash++
                            }
                        }
                    )
                }
        )
        if (active && boosted) {
            Text(
                "2x  ▶▶",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 56.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            )
        }

        if (active && (n == null || n.loading || buffering)) {
            EchoLoader(Modifier.align(Alignment.Center), size = 48.dp)
        }
        if (n?.error != null) {
            Text(
                n.error, color = Color.White, fontSize = 14.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(32.dp)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            )
        }
        AnimatedVisibility(
            visible = active && !playing && n != null && !n.loading && !buffering && flash > 0,
            enter = scaleIn() + fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.PlayArrow, "Paused", tint = Color.White, modifier = Modifier.size(48.dp))
            }
        }

        // Shade so the text reads
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(0.6f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.65f)))
        )

        // Right rail
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 8.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val likes = n?.likes ?: -1
            val dislikes = n?.dislikes ?: -1
            RailButton(Icons.Rounded.ThumbUp, if (likes > 0) Fmt.count(likes) else "Like") {}
            RailButton(Icons.Rounded.ThumbDown, if (dislikes > 0) Fmt.count(dislikes) else "Dislike") {}
            RailButton(Icons.AutoMirrored.Rounded.Comment, "Comments", onComments)
            RailButton(Icons.Rounded.Share, "Share") { actions.share(v.url, item.title) }
            RailButton(Icons.Rounded.MoreVert, "") { onMore() }
        }

        // Channel + title
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = 12.dp, end = 76.dp, bottom = 22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier
                        .weight(1f, fill = false)
                        .clickable(enabled = channelUrl.isNotBlank()) { actions.channel(channelUrl) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(n?.channelAvatar?.ifBlank { null } ?: item.uploaderAvatar, 32.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (item.uploader.isBlank()) "" else "@" + item.uploader.replace(" ", ""),
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                if (channelUrl.isNotBlank()) {
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .height(30.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (subscribed) Color.White.copy(alpha = 0.2f) else Color.White)
                            .clickable {
                                Library.toggleSubscription(channelUrl, item.uploader, n?.channelAvatar?.ifBlank { null } ?: item.uploaderAvatar)
                                actions.message(if (subscribed) "Unsubscribed" else "Subscribed to ${item.uploader}")
                            }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (subscribed) "Subscribed" else "Subscribe",
                            color = if (subscribed) Color.White else Color.Black,
                            fontSize = 13.sp, fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(item.title, color = Color.White, fontSize = 14.sp, lineHeight = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }

        if (active) ShortProgress(Modifier.align(Alignment.BottomStart))
    }
}

@UnstableApi
@Composable
private fun ShortSurface(playing: Boolean) {
    AndroidView(
        factory = { context ->
            PlayerView(context).apply {
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                useController = false
                setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                // Transparent until the first frame, so the cover shows instead of black
                setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                player = PlayerController.exo
            }
        },
        update = { view ->
            if (view.player !== PlayerController.exo) view.player = PlayerController.exo
            view.keepScreenOn = playing
        },
        onRelease = { view -> view.player = null },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun RailButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.3f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label.ifBlank { null }, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        if (label.isNotBlank()) {
            Spacer(Modifier.height(3.dp))
            Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** Thin red seek line along the bottom; drag it to scrub. */
@UnstableApi
@Composable
private fun ShortProgress(modifier: Modifier = Modifier) {
    var fraction by remember { mutableFloatStateOf(0f) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            val exo = PlayerController.exo
            duration = exo.duration.coerceAtLeast(0)
            if (!dragging && duration > 0) fraction = (exo.currentPosition.toFloat() / duration).coerceIn(0f, 1f)
            delay(100)
        }
    }
    Box(
        modifier
            .fillMaxWidth()
            .height(18.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        fraction = (o.x / size.width).coerceIn(0f, 1f)
                    },
                    onDragEnd = {
                        if (duration > 0) PlayerController.seekTo((fraction * duration).toLong())
                        dragging = false
                    },
                    onDragCancel = { dragging = false }
                ) { change, _ ->
                    change.consume()
                    fraction = (change.position.x / size.width).coerceIn(0f, 1f)
                }
            },
        contentAlignment = Alignment.BottomStart
    ) {
        Canvas(Modifier.fillMaxWidth().height(if (dragging) 10.dp else 3.dp)) {
            val h = if (dragging) 4.dp.toPx() else 2.dp.toPx()
            val y = size.height - h
            drawRect(Color.White.copy(alpha = 0.3f), Offset(0f, y), Size(size.width, h))
            drawRect(Cl.Red, Offset(0f, y), Size(size.width * fraction, h))
            if (dragging) drawCircle(Cl.Red, 6.dp.toPx(), Offset(size.width * fraction, y + h / 2))
        }
    }
}
