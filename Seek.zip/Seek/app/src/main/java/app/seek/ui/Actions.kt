package app.seek.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavHostController
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.player.PlayerController

object Routes {
    const val HOME = "home"
    const val SHORTS = "shorts"
    const val EXPLORE = "explore"
    const val SUBS = "subs"
    const val SUBS_ALL = "subs_all"
    const val LIBRARY = "library"
    const val SEARCH = "search?q={q}"
    const val PLAYER = "player"
    const val CHANNEL = "channel/{url}"
    const val PLAYLIST = "playlist/{url}"
    const val LOCAL_PLAYLIST = "local/{id}"
    const val HISTORY = "history"
    const val WATCH_LATER = "watch_later"
    const val PLAYLISTS = "playlists"
    const val DOWNLOADS = "downloads"
    const val SETTINGS = "settings"

    val tabs = setOf(HOME, SHORTS, SUBS, LIBRARY)
}

/** Everything a screen can ask the app to do. */
@UnstableApi
class Actions(
    val nav: NavHostController,
    private val ctx: Context,
    private val toast: (String) -> Unit
) {
    fun message(text: String) = toast(text)

    fun video(v: VideoItem) {
        PlayerController.play(v)
        openPlayer()
    }

    fun openPlayer() {
        if (nav.currentDestination?.route != Routes.PLAYER) {
            nav.navigate(Routes.PLAYER) { launchSingleTop = true }
        }
    }

    /** Opens the Shorts tab on [items], starting at [index]. */
    fun shorts(items: List<VideoItem>, index: Int) {
        if (items.isEmpty()) return
        UiState.shortsStart.value = UiState.ShortsStart(items, index.coerceIn(0, items.size - 1))
        tab(Routes.SHORTS)
    }

    fun channel(url: String) {
        if (url.isBlank()) return
        nav.navigate("channel/" + Uri.encode(url))
    }

    fun playlist(url: String) = nav.navigate("playlist/" + Uri.encode(url))

    fun localPlaylist(id: String) = nav.navigate("local/" + Uri.encode(id))

    fun search(q: String = "") = nav.navigate("search?q=" + Uri.encode(q)) { launchSingleTop = true }

    fun open(route: String) = nav.navigate(route) { launchSingleTop = true }

    fun back() {
        if (!nav.popBackStack()) nav.navigate(Routes.HOME)
    }

    fun tab(route: String) {
        nav.navigate(route) {
            popUpTo(Routes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    /** Opens any YouTube link: video, channel or playlist. Returns false if it isn't one. */
    fun link(raw: String): Boolean {
        val url = Yt.extractUrl(raw) ?: raw.trim()
        return when (Yt.linkKind(url)) {
            Yt.LinkKind.VIDEO -> {
                video(VideoItem(url = url, title = "Loading…"))
                true
            }
            Yt.LinkKind.CHANNEL -> {
                channel(url); true
            }
            Yt.LinkKind.PLAYLIST -> {
                playlist(url); true
            }
            Yt.LinkKind.NONE -> {
                toast("That doesn't look like a YouTube link")
                false
            }
        }
    }

    fun share(url: String, title: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, url)
        }
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Opens a link from a description or comment: YouTube links stay in Seek, others go to the browser. */
    fun openLink(raw: String) {
        val url = raw.trim()
        if (Yt.linkKind(url) != Yt.LinkKind.NONE) {
            link(url)
            return
        }
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("No app can open this link")
        }
    }

    fun openUri(uri: Uri, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            toast("No app can open this file")
        }
    }
}

@UnstableApi
val LocalActions = staticCompositionLocalOf<Actions> { error("Actions not provided") }
