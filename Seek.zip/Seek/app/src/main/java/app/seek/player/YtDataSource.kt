package app.seek.player

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import app.seek.core.Net
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import java.io.IOException
import java.io.InputStream

/**
 * HTTP data source tuned for googlevideo.com, ported from NewPipe's approach:
 *  - byte ranges go in a `range=` URL parameter instead of a Range header (avoids throttling)
 *  - a request counter `rn=` is appended
 *  - videoplayback requests are POSTs with the tiny body YouTube's own clients send
 * Everything else (subtitles, other hosts) is a plain GET.
 */
@UnstableApi
class YtDataSource private constructor(
    private val rangeParameter: Boolean,
    private val rnParameter: Boolean
) : BaseDataSource(true) {

    class Factory(
        private val rangeParameter: Boolean,
        private val rnParameter: Boolean
    ) : DataSource.Factory {
        override fun createDataSource(): DataSource = YtDataSource(rangeParameter, rnParameter)
    }

    private var dataSpec: DataSpec? = null
    private var response: Response? = null
    private var stream: InputStream? = null
    private var opened = false
    private var bytesToRead = C.LENGTH_UNSET.toLong()
    private var bytesRead = 0L
    private var requestNumber = 0

    override fun open(dataSpec: DataSpec): Long {
        this.dataSpec = dataSpec
        bytesRead = 0
        bytesToRead = C.LENGTH_UNSET.toLong()
        transferInitializing(dataSpec)

        val position = dataSpec.position
        val length = dataSpec.length
        val uri = dataSpec.uri
        val isPlayback = uri.path?.startsWith("/videoplayback") == true
        var url = uri.toString()
        var usedRangeParam = false

        val builder = Request.Builder()
        for ((k, v) in dataSpec.httpRequestHeaders) builder.header(k, v)

        if (isPlayback && rnParameter && !url.contains("&rn=")) {
            url += "&rn=$requestNumber"
            requestNumber++
        }
        if (isPlayback && rangeParameter) {
            if (position != 0L || length != C.LENGTH_UNSET.toLong()) {
                url += "&range=$position-" + if (length != C.LENGTH_UNSET.toLong()) (position + length - 1).toString() else ""
            }
            usedRangeParam = true
        } else {
            val range = rangeHeader(position, length)
            if (range != null) builder.header("Range", range)
        }

        builder.url(url)
            .header("User-Agent", if (isVisionOs(url)) YoutubeParsingHelper.getVisionOsUserAgent(null) else Net.USER_AGENT)
            .header("Accept-Encoding", "identity")

        if (isWeb(url)) {
            builder.header("Origin", "https://www.youtube.com")
            builder.header("Referer", "https://www.youtube.com/")
            builder.header("Sec-Fetch-Dest", "empty")
            builder.header("Sec-Fetch-Mode", "cors")
            builder.header("Sec-Fetch-Site", "cross-site")
        }

        if (isPlayback) builder.post(POST_BODY.toRequestBody()) else builder.get()

        val resp = try {
            Net.client.newCall(builder.build()).execute()
        } catch (e: IOException) {
            throw HttpDataSource.HttpDataSourceException.createForIOException(
                e, dataSpec, HttpDataSource.HttpDataSourceException.TYPE_OPEN
            )
        }

        if (!resp.isSuccessful) {
            val errorBody = try {
                resp.body?.bytes() ?: ByteArray(0)
            } catch (e: Exception) {
                ByteArray(0)
            }
            val headers = resp.headers.toMultimap()
            val code = resp.code
            val message = resp.message
            resp.close()
            throw HttpDataSource.InvalidResponseCodeException(code, message, null, headers, dataSpec, errorBody)
        }

        response = resp
        val body = resp.body ?: throw IOException("Empty response body")
        val input = body.byteStream()
        stream = input

        // Server ignored our Range header and sent the whole thing: skip manually
        val skip = if (!usedRangeParam && resp.code == 200 && position != 0L) position else 0L

        bytesToRead = if (length != C.LENGTH_UNSET.toLong()) {
            length
        } else {
            val contentLength = body.contentLength()
            if (contentLength != -1L) contentLength - skip else C.LENGTH_UNSET.toLong()
        }

        if (skip > 0) skipFully(input, skip)

        opened = true
        transferStarted(dataSpec)
        return bytesToRead
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        val input = stream ?: return C.RESULT_END_OF_INPUT
        var toRead = length
        if (bytesToRead != C.LENGTH_UNSET.toLong()) {
            val remaining = bytesToRead - bytesRead
            if (remaining <= 0L) return C.RESULT_END_OF_INPUT
            toRead = minOf(length.toLong(), remaining).toInt()
        }
        val n = try {
            input.read(buffer, offset, toRead)
        } catch (e: IOException) {
            val spec = dataSpec ?: throw e
            throw HttpDataSource.HttpDataSourceException.createForIOException(
                e, spec, HttpDataSource.HttpDataSourceException.TYPE_READ
            )
        }
        if (n == -1) return C.RESULT_END_OF_INPUT
        bytesRead += n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? =
        response?.request?.url?.toString()?.let { Uri.parse(it) } ?: dataSpec?.uri

    override fun getResponseHeaders(): Map<String, List<String>> =
        response?.headers?.toMultimap() ?: emptyMap()

    override fun close() {
        try {
            stream?.close()
        } catch (_: Exception) {
        }
        try {
            response?.close()
        } catch (_: Exception) {
        }
        stream = null
        response = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    private fun skipFully(input: InputStream, count: Long) {
        var left = count
        val buf = ByteArray(16 * 1024)
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n == -1) throw IOException("Unexpected end of stream while skipping")
            left -= n
        }
    }

    companion object {
        private val POST_BODY = byteArrayOf(0x78, 0)

        private fun rangeHeader(position: Long, length: Long): String? {
            if (position == 0L && length == C.LENGTH_UNSET.toLong()) return null
            val sb = StringBuilder("bytes=").append(position).append('-')
            if (length != C.LENGTH_UNSET.toLong()) sb.append(position + length - 1)
            return sb.toString()
        }

        private fun isWeb(url: String) = try {
            YoutubeParsingHelper.isWebStreamingUrl(url)
        } catch (e: Exception) {
            false
        }

        private fun isVisionOs(url: String) = try {
            YoutubeParsingHelper.isVisionOsStreamingUrl(url)
        } catch (e: Exception) {
            false
        }
    }
}
