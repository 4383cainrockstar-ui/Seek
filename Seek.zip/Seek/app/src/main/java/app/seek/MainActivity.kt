package app.seek

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.seek.core.Yt
import app.seek.player.PlaybackService
import app.seek.player.PlayerController
import app.seek.ui.SeekRoot
import app.seek.ui.UiState
import app.seek.ui.theme.SeekTheme
import com.google.common.util.concurrent.ListenableFuture

@UnstableApi
class MainActivity : ComponentActivity() {

    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        handleIntent(intent)

        addOnPictureInPictureModeChangedListener { info ->
            UiState.inPip.value = info.isInPictureInPictureMode
        }

        setContent {
            SeekTheme {
                SeekRoot()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        // Binding a controller brings the media session service up, which owns the notification.
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            ACTION_OPEN_PLAYER -> UiState.pending.value = UiState.Pending.OpenPlayer
            ACTION_OPEN_DOWNLOADS -> UiState.pending.value = UiState.Pending.OpenDownloads
            Intent.ACTION_SEND -> Yt.extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let {
                UiState.pending.value = UiState.Pending.Link(it)
            }
            Intent.ACTION_VIEW -> Yt.extractUrl(intent.dataString)?.let {
                UiState.pending.value = UiState.Pending.Link(it)
            }
        }
    }

    private fun canPip(): Boolean {
        val now = PlayerController.now.value ?: return false
        return UiState.onPlayerScreen.value && !now.audioOnly && PlayerController.isPlaying.value &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    }

    fun enterPip() {
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        } catch (_: Exception) {
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (canPip()) enterPip()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_PLAYER = "app.seek.OPEN_PLAYER"
        const val ACTION_OPEN_DOWNLOADS = "app.seek.OPEN_DOWNLOADS"
    }
}
