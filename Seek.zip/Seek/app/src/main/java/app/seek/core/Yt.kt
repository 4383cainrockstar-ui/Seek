package app.seek.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.StreamingService
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.feed.FeedInfo
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.Locale

/** A page of results plus whatever is needed to fetch the next one. */
data class Paged<T>(val items: List<T>, val next: Page?)

data class CommentItem(
    val author: String,
    val avatar: String,
    val text: String,
    val likes: Int,
    val ago: String,
    val pinned: Boolean,
    val hearted: Boolean,
    val replies: Int,
    val id: String = "",
    /** Where this comment's replies are fetched from (null when it has none). */
    val repliesPage: Page? = null,
    val authorUrl: String = "",
    /** Written by the channel that posted the video. */
    val byCreator: Boolean = false,
    val verified: Boolean = false
) {
    val key: String get() = id.ifBlank { author + "|" + text.hashCode() + "|" + ago }
}

/** How comments are ordered. */
enum class CommentSort(val label: String) { TOP("Top"), NEWEST("Newest") }

data class ChannelDetails(
    val info: ChannelInfo,
    val channel: ChannelItem,
    val banner: String,
    val tabs: Map<String, ListLinkHandler>
)

data class Kiosk(val id: String, val label: String)

/** Every YouTube call the app makes goes through here. All functions are main-safe. */
object Yt {
    private val yt: StreamingService get() = ServiceList.YouTube

    val kiosks = listOf(
        Kiosk("trending_music", "Music"),
        Kiosk("trending_gaming", "Gaming"),
        Kiosk("trending_movies_and_shows", "Movies"),
        Kiosk("trending_podcasts_episodes", "Podcasts"),
        Kiosk("live", "Live")
    )

    fun init() {
        val locale = Locale.getDefault()
        val loc = try {
            Localization.fromLocale(locale)
        } catch (e: Exception) {
            Localization.DEFAULT
        }
        val country = locale.country.takeIf { it.length == 2 }?.let { ContentCountry(it) }
            ?: ContentCountry.DEFAULT
        NewPipe.init(SeekDownloader(), loc, country)
    }

    // ---------------- Search ----------------

    const val FILTER_ALL = "all"
    const val FILTER_VIDEOS = "videos"
    const val FILTER_CHANNELS = "channels"
    const val FILTER_PLAYLISTS = "playlists"

    private fun query(q: String, filter: String): SearchQueryHandler =
        yt.searchQHFactory.fromQuery(q, if (filter == FILTER_ALL) emptyList() else listOf(filter), "")

    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        if (q.isBlank()) emptyList() else try {
            yt.suggestionExtractor.suggestionList(q)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun search(q: String, filter: String): Paged<ListEntry> = withContext(Dispatchers.IO) {
        val info = SearchInfo.getInfo(yt, query(q, filter))
        Paged(info.relatedItems.mapNotNull { it.toEntry() }, info.nextPage)
    }

    suspend fun searchMore(q: String, filter: String, page: Page): Paged<ListEntry> =
        withContext(Dispatchers.IO) {
            val p = SearchInfo.getMoreItems(yt, query(q, filter), page)
            Paged(p.items.mapNotNull { it.toEntry() }, p.nextPage)
        }

    // ---------------- Trending ----------------

    private fun kioskUrl(id: String): String =
        yt.kioskList.getListLinkHandlerFactoryByType(id).fromId(id).url

    suspend fun kiosk(id: String): Paged<VideoItem> = withContext(Dispatchers.IO) {
        val info = KioskInfo.getInfo(yt, kioskUrl(id))
        Paged(info.relatedItems.map { it.toVideo() }, info.nextPage)
    }

    suspend fun kioskMore(id: String, page: Page): Paged<VideoItem> = withContext(Dispatchers.IO) {
        val p = KioskInfo.getMoreItems(yt, kioskUrl(id), page)
        Paged(p.items.map { it.toVideo() }, p.nextPage)
    }

    // ---------------- Videos ----------------

    suspend fun stream(url: String): StreamInfo = withContext(Dispatchers.IO) {
        StreamInfo.getInfo(yt, url)
    }

    fun related(info: StreamInfo): List<VideoItem> =
        info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideo() }

    // ---------------- Comments ----------------

    private fun CommentsInfoItem.toComment() = CommentItem(
        author = uploaderName ?: "",
        avatar = uploaderAvatars.bestUrl(88),
        text = try {
            val raw = commentText?.content() ?: ""
            android.text.Html.fromHtml(raw, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
        } catch (e: Exception) {
            ""
        },
        likes = likeCount,
        ago = textualUploadDate ?: "",
        pinned = isPinned,
        hearted = isHeartedByUploader,
        replies = replyCount.coerceAtLeast(if (this.replies != null) 1 else 0),
        id = commentId ?: "",
        repliesPage = this.replies,
        authorUrl = uploaderUrl ?: "",
        byCreator = isChannelOwner,
        verified = isUploaderVerified
    )

    suspend fun comments(url: String): Paged<CommentItem> = withContext(Dispatchers.IO) {
        val info = CommentsInfo.getInfo(yt, url)
        if (info.isCommentsDisabled) Paged(emptyList(), null)
        else Paged(info.relatedItems.map { it.toComment() }, info.nextPage)
    }

    suspend fun commentsMore(url: String, page: Page): Paged<CommentItem> =
        withContext(Dispatchers.IO) {
            val p = CommentsInfo.getMoreItems(yt, url, page)
            Paged(p.items.map { it.toComment() }, p.nextPage)
        }

    /** Comments in the chosen order. "Newest" asks YouTube for its own "Newest first" list. */
    suspend fun comments(url: String, sort: CommentSort): Paged<CommentItem> = when (sort) {
        CommentSort.TOP -> comments(url)
        CommentSort.NEWEST -> withContext(Dispatchers.IO) {
            val token = YtWeb.newestCommentsToken(url) ?: return@withContext comments(url)
            val p = CommentsInfo.getMoreItems(yt, url, Page(url, token))
            Paged(p.items.map { it.toComment() }, p.nextPage)
        }
    }

    /** One page of replies to a comment (the first page is [CommentItem.repliesPage]). */
    suspend fun replies(url: String, page: Page): Paged<CommentItem> = withContext(Dispatchers.IO) {
        val p = CommentsInfo.getMoreItems(yt, url, page)
        Paged(p.items.map { it.toComment() }, p.nextPage)
    }

    // ---------------- Channels ----------------

    suspend fun channel(url: String): ChannelDetails = withContext(Dispatchers.IO) {
        val info = ChannelInfo.getInfo(yt, url)
        val tabs = LinkedHashMap<String, ListLinkHandler>()
        for (t in info.tabs) {
            val name = t.contentFilters.firstOrNull() ?: continue
            tabs[name] = t
        }
        ChannelDetails(
            info = info,
            channel = ChannelItem(
                url = info.url ?: url,
                name = info.name ?: "",
                avatar = info.avatars.bestUrl(240),
                subscribers = info.subscriberCount,
                description = info.description ?: ""
            ),
            banner = info.banners.bestUrl(1080),
            tabs = tabs
        )
    }

    suspend fun tab(handler: ListLinkHandler): Paged<ListEntry> = withContext(Dispatchers.IO) {
        val info = ChannelTabInfo.getInfo(yt, handler)
        Paged(info.relatedItems.mapNotNull { it.toEntry() }, info.nextPage)
    }

    suspend fun tabMore(handler: ListLinkHandler, page: Page): Paged<ListEntry> =
        withContext(Dispatchers.IO) {
            val p: ListExtractor.InfoItemsPage<InfoItem> = ChannelTabInfo.getMoreItems(yt, handler, page)
            Paged(p.items.mapNotNull { it.toEntry() }, p.nextPage)
        }

    /** Latest uploads for a channel. Fast mode uses the RSS feed, full mode the Videos tab. */
    suspend fun latestUploads(channelUrl: String, detailed: Boolean): List<VideoItem> =
        withContext(Dispatchers.IO) {
            if (!detailed) {
                val feed = FeedInfo.getInfo(yt, channelUrl)
                feed.relatedItems.map { it.toVideo() }
            } else {
                val info = ChannelInfo.getInfo(yt, channelUrl)
                val avatar = info.avatars.bestUrl(176)
                val videosTab = info.tabs.firstOrNull { ChannelTabs.VIDEOS in it.contentFilters }
                    ?: return@withContext emptyList()
                val tab = ChannelTabInfo.getInfo(yt, videosTab)
                tab.relatedItems.filterIsInstance<StreamInfoItem>().map {
                    val v = it.toVideo()
                    v.copy(
                        uploader = v.uploader.ifBlank { info.name ?: "" },
                        uploaderUrl = v.uploaderUrl.ifBlank { channelUrl },
                        uploaderAvatar = v.uploaderAvatar.ifBlank { avatar }
                    )
                }
            }
        }

    // ---------------- Playlists ----------------

    suspend fun playlist(url: String): Pair<PlaylistInfo, Paged<VideoItem>> = withContext(Dispatchers.IO) {
        val info = PlaylistInfo.getInfo(yt, url)
        info to Paged(info.relatedItems.map { it.toVideo() }, info.nextPage)
    }

    suspend fun playlistMore(url: String, page: Page): Paged<VideoItem> = withContext(Dispatchers.IO) {
        val p = PlaylistInfo.getMoreItems(yt, url, page)
        Paged(p.items.map { it.toVideo() }, p.nextPage)
    }

    // ---------------- Links ----------------

    enum class LinkKind { VIDEO, CHANNEL, PLAYLIST, NONE }

    fun linkKind(url: String): LinkKind = try {
        when (yt.getLinkTypeByUrl(url)) {
            StreamingService.LinkType.STREAM -> LinkKind.VIDEO
            StreamingService.LinkType.CHANNEL -> LinkKind.CHANNEL
            StreamingService.LinkType.PLAYLIST -> LinkKind.PLAYLIST
            else -> LinkKind.NONE
        }
    } catch (e: Exception) {
        LinkKind.NONE
    }

    /** Pulls the first usable link out of shared text and normalises app-specific schemes. */
    fun extractUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val t = text.trim()
        if (t.startsWith("vnd.youtube:")) {
            val id = t.removePrefix("vnd.youtube:").removePrefix("//").substringBefore('?')
            return "https://www.youtube.com/watch?v=$id"
        }
        val m = Regex("https?://\\S+").find(t) ?: return null
        return m.value.trimEnd('.', ',', ')', ']', '"', '\'')
    }

    fun friendlyError(e: Throwable): String {
        val name = e.javaClass.simpleName
        val msg = e.message ?: ""
        return when {
            name.contains("ReCaptcha") -> "YouTube is rate limiting you. Try again in a bit."
            name.contains("AgeRestricted") -> "This video is age restricted."
            name.contains("Geographic") -> "This video isn't available in your country."
            name.contains("Private") -> "This video is private."
            name.contains("Paid") || name.contains("Members") -> "This video is for paying members only."
            name.contains("ContentNotAvailable") -> "This content isn't available."
            e is java.net.UnknownHostException || e is java.net.SocketTimeoutException ->
                "No connection. Check your internet."
            msg.isNotBlank() -> msg.take(160)
            else -> "Something went wrong ($name)"
        }
    }
}
