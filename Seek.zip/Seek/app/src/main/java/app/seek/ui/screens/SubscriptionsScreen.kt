package app.seek.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Label
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import app.seek.ui.components.EchoPullIndicator
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.seek.core.VideoItem
import app.seek.data.Library
import app.seek.data.Settings
import app.seek.data.Subscription
import app.seek.feed.FeedRepository
import app.seek.ui.LocalActions
import app.seek.ui.Routes
import app.seek.ui.components.Avatar
import app.seek.ui.components.Chip
import app.seek.ui.components.EmptyState
import app.seek.ui.components.Logo
import app.seek.ui.components.PrimaryButton
import app.seek.ui.components.SheetRow
import app.seek.ui.components.ShortTile
import app.seek.ui.components.TonalButton
import app.seek.ui.components.TopBar
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.VideoCard
import app.seek.ui.components.channelKey
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import kotlinx.coroutines.launch

private const val F_ALL = "\u0000all"
private const val F_TODAY = "\u0000today"
private const val F_VIDEOS = "\u0000videos"
private const val F_SHORTS = "\u0000shorts"
private const val F_LIVE = "\u0000live"
private const val F_CONTINUE = "\u0000continue"

// =============================================================================================
// Subscriptions tab: channel row on top, then their latest uploads
// =============================================================================================

@UnstableApi
@Composable
fun SubscriptionsScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val settings by Settings.state.collectAsState()
    val feed by FeedRepository.progress.collectAsState()
    val scope = rememberCoroutineScope()
    val progress = rememberWatchProgress()
    var filter by rememberSaveable { mutableStateOf(F_ALL) }
    var channel by rememberSaveable { mutableStateOf<String?>(null) }
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }

    val subsByKey = remember(lib.subscriptions) { lib.subscriptions.associateBy { channelKey(it.url) } }
    val groups = remember(lib.subscriptions) { lib.subscriptions.map { it.group }.filter { it.isNotBlank() }.distinct().sorted() }
    // Channels with the newest uploads first, like YouTube's avatar row
    val latestByChannel = remember(lib.feed) {
        lib.feed.groupBy { channelKey(it.uploaderUrl) }.mapValues { (_, v) -> v.maxOf { it.uploaded } }
    }
    val row = remember(lib.subscriptions, latestByChannel) {
        lib.subscriptions.sortedByDescending { latestByChannel[channelKey(it.url)] ?: 0L }
    }
    val dayAgo = System.currentTimeMillis() - 24L * 3600 * 1000
    val watched = remember(lib.history) {
        lib.history.filter { it.durationMs > 0 && it.positionMs > it.durationMs * 0.9 }.map { it.video.url }.toSet()
    }

    val list = remember(lib.feed, lib.history, filter, channel, settings, watched) {
        val base = lib.feed.filter { v ->
            (channel == null || channelKey(v.uploaderUrl) == channel) &&
                !(settings.hideWatched && v.url in watched) &&
                !(settings.minDurationMinutes > 0 && !v.isShort && v.duration in 1 until settings.minDurationMinutes * 60L)
        }
        when (filter) {
            F_ALL -> base.filter { !(settings.hideShorts && it.isShort) }
            F_TODAY -> base.filter { it.uploaded >= dayAgo && !(settings.hideShorts && it.isShort) }
            F_VIDEOS -> base.filter { !it.isShort && !it.isLive }
            F_SHORTS -> base.filter { it.isShort }
            F_LIVE -> base.filter { it.isLive }
            F_CONTINUE -> lib.history.filter { it.durationMs > 0 && it.positionMs > 5_000 && it.positionMs < it.durationMs * 0.9 }
                .map { it.video }
                .filter { channel == null || channelKey(it.uploaderUrl) == channel }
            else -> base.filter { subsByKey[channelKey(it.uploaderUrl)]?.group == filter }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(52.dp)
                .padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Logo()
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { scope.launch { FeedRepository.refresh() } }, enabled = !feed.running) {
                Icon(Icons.Rounded.Refresh, "Refresh", tint = if (feed.running) Cl.TextFaint else Cl.Text)
            }
            IconButton(onClick = { actions.search() }) { Icon(Icons.Rounded.Search, "Search", tint = Cl.Text, modifier = Modifier.size(26.dp)) }
        }

        if (lib.subscriptions.isEmpty()) {
            EmptyState(
                Icons.Rounded.Subscriptions,
                "Don't miss new videos",
                "Subscribe to channels and their uploads show up here. Subscriptions live only on this phone.",
                action = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PrimaryButton("Find channels", { actions.search() }, icon = Icons.Rounded.Search)
                        Spacer(Modifier.height(10.dp))
                        TonalButton("Import from YouTube or NewPipe", { actions.open(Routes.SETTINGS) })
                    }
                }
            )
        } else {

        // Avatar row + "All"
        Row(verticalAlignment = Alignment.CenterVertically) {
            LazyRow(
                Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(row, key = { it.url }) { s ->
                    val key = channelKey(s.url)
                    val fresh = (latestByChannel[key] ?: 0L) >= dayAgo
                    ChannelBubble(
                        s,
                        isNew = fresh,
                        dimmed = channel != null && channel != key,
                        onClick = { channel = if (channel == key) null else key }
                    )
                }
            }
            Text(
                "All",
                color = Cl.Blue,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { actions.open(Routes.SUBS_ALL) }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }

        // A channel is picked: its name and a way into the channel
        val picked = channel?.let { k -> subsByKey[k] }
        if (picked != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 14.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(picked.name, color = Cl.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                TextButton(onClick = { actions.channel(picked.url) }) { Text("View channel", color = Cl.Blue, fontWeight = FontWeight.Medium) }
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val fixed = listOf(F_ALL to "All", F_TODAY to "Today", F_VIDEOS to "Videos", F_SHORTS to "Shorts", F_LIVE to "Live", F_CONTINUE to "Continue watching")
            items(fixed) { (k, label) -> Chip(label, filter == k, { filter = k }) }
            items(groups) { g -> Chip(g, filter == g, { filter = g }) }
        }

        if (feed.running && feed.total > 0) {
            LinearProgressIndicator(
                progress = { feed.done.toFloat() / feed.total },
                color = Cl.Red,
                trackColor = Cl.SurfaceHigh,
                modifier = Modifier.fillMaxWidth().height(2.dp)
            )
        } else Spacer(Modifier.height(2.dp))

        val pullState = rememberPullToRefreshState()
        PullToRefreshBox(
            isRefreshing = feed.running,
            onRefresh = { scope.launch { FeedRepository.refresh() } },
            state = pullState,
            modifier = Modifier.fillMaxSize(),
            indicator = { EchoPullIndicator(pullState, feed.running, Modifier.align(Alignment.TopCenter)) }
        ) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (list.isEmpty()) item {
                    EmptyState(
                        Icons.Rounded.Subscriptions,
                        if (lib.feed.isEmpty()) "Pull down to load your feed" else "Nothing here",
                        if (lib.feed.isEmpty()) "Fetching the latest uploads from ${lib.subscriptions.size} channels." else "Try another chip or channel."
                    )
                } else if (filter == F_SHORTS) {
                    // Shorts in a two-wide grid
                    val all = list
                    items(all.chunked(2)) { pair ->
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            pair.forEach { s ->
                                ShortTile(s, onClick = { actions.shorts(all, all.indexOf(s)) }, modifier = Modifier.weight(1f), onMore = { menuFor = s })
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                } else {
                    val shorts = if (filter == F_ALL) list.filter { it.isShort }.take(12) else emptyList()
                    val videos = if (filter == F_ALL) list.filterNot { it.isShort } else list
                    videos.forEachIndexed { i, v ->
                        item(key = "v:" + v.url) {
                            val sub = subsByKey[channelKey(v.uploaderUrl)]
                            VideoCard(
                                video = v,
                                avatar = sub?.avatar?.ifBlank { null } ?: v.uploaderAvatar,
                                progress = progress[v.url] ?: 0f,
                                onClick = { actions.video(v) },
                                onChannel = { actions.channel(v.uploaderUrl) },
                                onMore = { menuFor = v }
                            )
                        }
                        if (i == 1 && shorts.isNotEmpty()) item(key = "shorts-shelf") {
                            ShortsShelf(shorts, onOpen = { idx -> actions.shorts(shorts, idx) }, onMore = { menuFor = it })
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}

@Composable
private fun ChannelBubble(s: Subscription, isNew: Boolean, dimmed: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(68.dp)
            .alpha(if (dimmed) 0.4f else 1f)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Avatar(s.avatar, 54.dp)
        Spacer(Modifier.height(5.dp))
        Text(
            s.name.ifBlank { "Channel" },
            color = Cl.TextDim,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
        Spacer(Modifier.height(3.dp))
        // Blue dot: uploaded in the last day
        Box(
            Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(if (isNew) Cl.Blue else Color.Transparent)
        )
    }
}

// =============================================================================================
// "All subscriptions": filter, groups, unsubscribe
// =============================================================================================

@UnstableApi
@Composable
fun SubscriptionsManageScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var group by rememberSaveable { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<Subscription?>(null) }
    var groupFor by remember { mutableStateOf<Subscription?>(null) }

    val groups = remember(lib.subscriptions) { lib.subscriptions.map { it.group }.filter { it.isNotBlank() }.distinct().sorted() }
    val list = remember(lib.subscriptions, query, group) {
        lib.subscriptions
            .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
            .filter { group.isBlank() || it.group == group }
            .sortedBy { it.name.lowercase() }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("All subscriptions", onBack = { actions.back() })

        TextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search ${lib.subscriptions.size} channels", color = Cl.TextDim) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Cl.TextDim) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Clear", tint = Cl.Text) }
            },
            singleLine = true,
            shape = RoundedCornerShape(50),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Cl.SurfaceHigh,
                unfocusedContainerColor = Cl.SurfaceHigh,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Cl.Text,
                unfocusedTextColor = Cl.Text,
                cursorColor = Cl.Blue
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )

        if (groups.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Chip("All", group.isBlank(), { group = "" }) }
                items(groups) { g -> Chip(g, group == g, { group = g }) }
            }
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.url }) { s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { actions.channel(s.url) }
                        .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(s.avatar, 44.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name.ifBlank { s.url }, color = Cl.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (s.group.isNotBlank()) Text(s.group, color = Cl.TextDim, fontSize = 12.sp)
                    }
                    IconButton(onClick = { menuFor = s }) {
                        Icon(Icons.Rounded.MoreVert, "Options", tint = Cl.Text, modifier = Modifier.size(20.dp))
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    menuFor?.let { s ->
        ModalBottomSheet(
            onDismissRequest = { menuFor = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Cl.Surface
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(s.name, color = Cl.Text, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp))
                HorizontalDivider(color = Cl.Outline)
                SheetRow(Icons.AutoMirrored.Rounded.Label, if (s.group.isBlank()) "Add to a group" else "Change group (${s.group})") {
                    groupFor = s
                    menuFor = null
                }
                SheetRow(Icons.Rounded.PersonRemove, "Unsubscribe") {
                    Library.unsubscribe(s.url)
                    actions.message("Unsubscribed from ${s.name}")
                    menuFor = null
                }
            }
        }
    }

    groupFor?.let { s ->
        GroupDialog(s, groups, onDismiss = { groupFor = null }) { g ->
            Library.setGroup(s.url, g)
            groupFor = null
        }
    }
}

@Composable
private fun GroupDialog(sub: Subscription, groups: List<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var text by remember { mutableStateOf(sub.group) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Cl.Surface,
        shape = RoundedCornerShape(12.dp),
        title = { Text("Group for ${sub.name}", color = Cl.Text, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                Text("Groups become chips on your Subscriptions tab.", color = Cl.TextDim, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                if (groups.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        groups.forEach { g -> Chip(g, text == g, { text = g }) }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text("e.g. Gaming, Tech, Music", color = Cl.TextFaint) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cl.Blue,
                        unfocusedBorderColor = Cl.SurfaceHighest,
                        focusedTextColor = Cl.Text,
                        unfocusedTextColor = Cl.Text,
                        cursorColor = Cl.Blue
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(text.trim()) }) { Text("Save", color = Cl.Blue, fontWeight = FontWeight.Medium) } },
        dismissButton = {
            Row {
                if (sub.group.isNotBlank()) TextButton(onClick = { onPick("") }) { Text("Remove", color = Cl.Text) }
                TextButton(onClick = onDismiss) { Text("Cancel", color = Cl.Text) }
            }
        }
    )
}
