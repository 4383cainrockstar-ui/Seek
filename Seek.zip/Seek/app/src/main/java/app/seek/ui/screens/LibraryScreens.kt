package app.seek.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Subscriptions
import androidx.compose.material.icons.outlined.WatchLater
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.WatchLater
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.seek.core.Fmt
import app.seek.core.Paged
import app.seek.core.VideoItem
import app.seek.core.Yt
import app.seek.data.Library
import app.seek.player.PlayerController
import app.seek.ui.LocalActions
import app.seek.ui.Routes
import app.seek.ui.components.EmptyState
import app.seek.ui.components.EndReached
import app.seek.ui.components.ErrorBox
import app.seek.ui.components.PlaylistThumb
import app.seek.ui.components.PrimaryButton
import app.seek.ui.components.SeekMark
import app.seek.ui.components.ShelfVideoCard
import app.seek.ui.components.TonalButton
import app.seek.ui.components.ViewAllButton
import app.seek.ui.components.Loading
import app.seek.ui.components.Logo
import app.seek.ui.components.PagerVm
import app.seek.ui.components.SectionHeader
import app.seek.ui.components.Thumb
import app.seek.ui.components.TopBar
import app.seek.ui.components.VideoActionsSheet
import app.seek.ui.components.VideoRow
import app.seek.ui.components.rememberWatchProgress
import app.seek.ui.theme.Cl
import coil.compose.AsyncImage
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.playlist.PlaylistInfo

// ---------------------------------------------------------------------------------------------
// "You" tab
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
fun LibraryScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val progress = rememberWatchProgress()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    var creating by remember { mutableStateOf(false) }
    val doneDownloads = lib.downloads.count { it.status == app.seek.data.DownloadRecord.STATUS_DONE }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(52.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { actions.search() }) { Icon(Icons.Rounded.Search, "Search", tint = Cl.Text, modifier = Modifier.size(26.dp)) }
                IconButton(onClick = { actions.open(Routes.SETTINGS) }) { Icon(Icons.Outlined.Settings, "Settings", tint = Cl.Text) }
            }
        }

        // Profile-style header
        item {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Cl.SurfaceHigh),
                    contentAlignment = Alignment.Center
                ) { SeekMark(34.dp) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("You", color = Cl.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "${lib.subscriptions.size} subscriptions · no account",
                        color = Cl.TextDim, fontSize = 13.sp
                    )
                }
            }
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { TonalButton("Import subscriptions", { actions.open(Routes.SETTINGS) }, icon = Icons.Outlined.FileDownload) }
                item { TonalButton("Back up", { actions.open(Routes.SETTINGS) }, icon = Icons.Outlined.CloudUpload) }
                item { TonalButton("All subscriptions", { actions.open(Routes.SUBS_ALL) }, icon = Icons.Outlined.Subscriptions) }
            }
        }

        // History shelf
        item {
            SectionHeader("History") {
                if (lib.history.isNotEmpty()) ViewAllButton({ actions.open(Routes.HISTORY) })
            }
            if (lib.history.isEmpty()) {
                Text(
                    "Videos you watch show up here, with your spot saved.",
                    color = Cl.TextDim, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            } else {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(lib.history.take(20), key = { it.video.url }) { h ->
                        ShelfVideoCard(
                            h.video,
                            onClick = { actions.video(h.video) },
                            progress = progress[h.video.url] ?: 0f,
                            onMore = { menuFor = h.video }
                        )
                    }
                }
            }
        }

        // Playlists shelf: Watch later first, then yours
        item {
            SectionHeader("Playlists") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { creating = true }) { Icon(Icons.Rounded.Add, "New playlist", tint = Cl.Text) }
                    if (lib.playlists.isNotEmpty()) ViewAllButton({ actions.open(Routes.PLAYLISTS) })
                }
            }
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    PlaylistShelfCard(
                        lib.watchLater.firstOrNull()?.thumbnail ?: "",
                        "Watch later",
                        "Private · ${lib.watchLater.size} videos",
                        lib.watchLater.size.toLong()
                    ) { actions.open(Routes.WATCH_LATER) }
                }
                items(lib.playlists, key = { it.id }) { p ->
                    PlaylistShelfCard(
                        p.items.firstOrNull()?.thumbnail ?: "",
                        p.name,
                        "Private · Playlist",
                        p.items.size.toLong()
                    ) { actions.localPlaylist(p.id) }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
        item { Box(Modifier.fillMaxWidth().height(1.dp).background(Cl.Outline)) }
        item { YouLine(Icons.Outlined.Download, "Downloads", "$doneDownloads videos") { actions.open(Routes.DOWNLOADS) } }
        item { YouLine(Icons.Outlined.History, "History", null) { actions.open(Routes.HISTORY) } }
        item { YouLine(Icons.Outlined.WatchLater, "Watch later", "${lib.watchLater.size} videos") { actions.open(Routes.WATCH_LATER) } }
        item { Box(Modifier.fillMaxWidth().height(1.dp).background(Cl.Outline)) }
        item { YouLine(Icons.Outlined.Settings, "Settings", null) { actions.open(Routes.SETTINGS) } }

        item {
            Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(size = 17)
                    Spacer(Modifier.height(4.dp))
                    Text("No ads. No account. No tracking.", color = Cl.TextFaint, fontSize = 12.sp)
                }
            }
        }
    }

    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
    if (creating) {
        NameDialog("New playlist", "", onDismiss = { creating = false }) { name ->
            Library.createPlaylist(name)
            creating = false
        }
    }
}

@Composable
private fun PlaylistShelfCard(thumb: String, title: String, sub: String, count: Long, onClick: () -> Unit) {
    Column(
        Modifier
            .width(160.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        PlaylistThumb(thumb, count)
        Spacer(Modifier.height(8.dp))
        Text(title, color = Cl.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(sub, color = Cl.TextDim, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun YouLine(icon: ImageVector, title: String, sub: String?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Cl.Text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(24.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Cl.Text, fontSize = 16.sp)
            if (sub != null) Text(sub, color = Cl.TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PlaylistLine(thumb: String, title: String, sub: String, count: Long, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        PlaylistThumb(thumb, count, Modifier.width(160.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).padding(top = 8.dp)) {
            Text(title, color = Cl.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(sub, color = Cl.TextDim, fontSize = 12.sp)
        }
    }
}

/** YouTube's playlist header: big cover on a wash of its colors, title, Play all + Shuffle. */
@Composable
private fun PlaylistHeader(thumb: String, title: String, sub: String, onPlay: (() -> Unit)?, onShuffle: (() -> Unit)?) {
    Box(Modifier.fillMaxWidth()) {
        if (thumb.isNotBlank()) {
            AsyncImage(
                thumb, null,
                contentScale = ContentScale.Crop,
                alpha = 0.35f,
                modifier = Modifier
                    .matchParentSize()
                    .blur(40.dp)
            )
        }
        Box(
            Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Cl.Deep)))
        )
        Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
            Thumb(thumb, Modifier.fillMaxWidth(), corner = 12.dp)
            Spacer(Modifier.height(16.dp))
            Text(title, color = Cl.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(sub, color = Cl.TextDim, fontSize = 13.sp)
            }
            if (onPlay != null && onShuffle != null) {
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Play all", onPlay, Modifier.weight(1f), icon = Icons.Rounded.PlayArrow)
                    TonalButton("Shuffle", onShuffle, Modifier.weight(1f), icon = Icons.Rounded.Shuffle)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// History
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
fun HistoryScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }

    Column(Modifier.fillMaxSize()) {
        TopBar("History", onBack = { actions.back() }) {
            if (lib.history.isNotEmpty()) IconButton(onClick = { confirmClear = true }) {
                Icon(Icons.Rounded.DeleteSweep, "Clear", tint = Cl.Text)
            }
        }
        if (lib.history.isEmpty()) {
            EmptyState(Icons.Rounded.History, "No history yet", "Videos you watch show up here, with your spot saved.")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(lib.history, key = { it.video.url }) { h ->
                    val p = if (h.durationMs > 0) (h.positionMs.toFloat() / h.durationMs).coerceIn(0f, 1f) else 0f
                    VideoRow(
                        h.video,
                        onClick = { actions.video(h.video) },
                        progress = p,
                        subtitle = "Watched " + Fmt.ago(h.watchedAt),
                        onMore = { menuFor = h.video }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    menuFor?.let { v ->
        VideoActionsSheet(v, onDismiss = { menuFor = null }, onRemove = { Library.removeHistory(v.url) }, removeLabel = "Remove from history")
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Cl.Surface,
            title = { Text("Clear watch history?", color = Cl.Text) },
            text = { Text("This also forgets where you left off in every video.", color = Cl.TextDim) },
            confirmButton = {
                TextButton(onClick = { Library.clearHistory(); confirmClear = false }) { Text("Clear", color = Cl.Red) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel", color = Cl.TextDim) } }
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Watch later
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
fun WatchLaterScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val progress = rememberWatchProgress()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }

    Column(Modifier.fillMaxSize()) {
        TopBar("", onBack = { actions.back() })
        if (lib.watchLater.isEmpty()) {
            EmptyState(Icons.Rounded.WatchLater, "Nothing saved", "Long-press any video and pick “Save to Watch later”.")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    PlaylistHeader(
                        lib.watchLater.firstOrNull()?.thumbnail ?: "",
                        "Watch later",
                        "Private · ${lib.watchLater.size} videos",
                        onPlay = { PlayerController.playQueue(lib.watchLater, name = "Watch later"); actions.openPlayer() },
                        onShuffle = { PlayerController.playQueue(lib.watchLater, shuffle = true, name = "Watch later"); actions.openPlayer() }
                    )
                }
                itemsIndexed(lib.watchLater, key = { _, v -> v.url }) { i, v ->
                    VideoRow(
                        v,
                        onClick = { PlayerController.playQueue(lib.watchLater, i, name = "Watch later"); actions.openPlayer() },
                        progress = progress[v.url] ?: 0f,
                        onMore = { menuFor = v }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
    menuFor?.let { v ->
        VideoActionsSheet(v, onDismiss = { menuFor = null }, onRemove = { Library.removeWatchLater(v.url) }, removeLabel = "Remove from Watch later")
    }
}

// ---------------------------------------------------------------------------------------------
// Local playlists
// ---------------------------------------------------------------------------------------------

@UnstableApi
@Composable
fun PlaylistsScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Playlists", onBack = { actions.back() }) {
            IconButton(onClick = { creating = true }) { Icon(Icons.Rounded.Add, "New playlist", tint = Cl.Text) }
        }
        if (lib.playlists.isEmpty()) {
            EmptyState(
                Icons.AutoMirrored.Rounded.QueueMusic, "No playlists yet", "Make one here, or save any video to a new playlist.",
                action = { PrimaryButton("New playlist", { creating = true }, icon = Icons.Rounded.Add) }
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    PlaylistLine(lib.watchLater.firstOrNull()?.thumbnail ?: "", "Watch later", "Private", lib.watchLater.size.toLong()) {
                        actions.open(Routes.WATCH_LATER)
                    }
                }
                items(lib.playlists, key = { it.id }) { p ->
                    PlaylistLine(p.items.firstOrNull()?.thumbnail ?: "", p.name, "Private · Playlist", p.items.size.toLong()) { actions.localPlaylist(p.id) }
                }
            }
        }
    }
    if (creating) {
        NameDialog("New playlist", "", onDismiss = { creating = false }) { name ->
            Library.createPlaylist(name)
            creating = false
        }
    }
}

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Cl.Surface,
        title = { Text(title, color = Cl.Text) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cl.Blue,
                    unfocusedBorderColor = Cl.SurfaceHighest,
                    focusedTextColor = Cl.Text,
                    unfocusedTextColor = Cl.Text,
                    cursorColor = Cl.Blue
                ),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text.trim()) }, enabled = text.isNotBlank()) { Text("Save", color = Cl.Blue, fontWeight = FontWeight.Medium) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Cl.TextDim) } }
    )
}

@UnstableApi
@Composable
fun LocalPlaylistScreen(id: String) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val playlist = lib.playlists.firstOrNull { it.id == id }
    val progress = rememberWatchProgress()
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }

    if (playlist == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Playlist", onBack = { actions.back() })
            EmptyState(Icons.AutoMirrored.Rounded.QueueMusic, "Playlist not found", "It may have been deleted.")
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("", onBack = { actions.back() }) {
            IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, "Rename", tint = Cl.Text) }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Delete", tint = Cl.Text) }
        }
        if (playlist.items.isEmpty()) {
            EmptyState(Icons.Rounded.VideoLibrary, "Empty playlist", "Long-press a video anywhere and choose “Add to playlist”.")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    PlaylistHeader(
                        playlist.items.firstOrNull()?.thumbnail ?: "",
                        playlist.name,
                        "Private · ${playlist.items.size} videos",
                        onPlay = { PlayerController.playQueue(playlist.items, name = playlist.name); actions.openPlayer() },
                        onShuffle = { PlayerController.playQueue(playlist.items, shuffle = true, name = playlist.name); actions.openPlayer() }
                    )
                }
                itemsIndexed(playlist.items, key = { _, v -> v.url }) { i, v ->
                    VideoRow(
                        v,
                        onClick = { PlayerController.playQueue(playlist.items, i, name = playlist.name); actions.openPlayer() },
                        progress = progress[v.url] ?: 0f,
                        onMore = { menuFor = v },
                        trailing = {
                            Column {
                                IconButton(onClick = { Library.moveInPlaylist(id, i, i - 1) }, enabled = i > 0, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.KeyboardArrowUp, "Up", tint = if (i > 0) Cl.TextDim else Cl.TextFaint)
                                }
                                IconButton(
                                    onClick = { Library.moveInPlaylist(id, i, i + 1) },
                                    enabled = i < playlist.items.size - 1,
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(Icons.Rounded.KeyboardArrowDown, "Down", tint = if (i < playlist.items.size - 1) Cl.TextDim else Cl.TextFaint)
                                }
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    if (renaming) {
        NameDialog("Rename playlist", playlist.name, onDismiss = { renaming = false }) {
            Library.renamePlaylist(id, it)
            renaming = false
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Cl.Surface,
            title = { Text("Delete “${playlist.name}”?", color = Cl.Text) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    Library.deletePlaylist(id)
                    actions.back()
                }) { Text("Delete", color = Cl.Red) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = Cl.TextDim) } }
        )
    }
    menuFor?.let { v ->
        VideoActionsSheet(v, onDismiss = { menuFor = null }, onRemove = { Library.removeFromPlaylist(id, v.url) }, removeLabel = "Remove from playlist")
    }
}

// ---------------------------------------------------------------------------------------------
// YouTube playlists
// ---------------------------------------------------------------------------------------------

class PlaylistVm(private val url: String) : PagerVm<VideoItem>() {
    var info by mutableStateOf<PlaylistInfo?>(null)
        private set

    override suspend fun first(): Paged<VideoItem> {
        val (i, page) = Yt.playlist(url)
        info = i
        return page
    }

    override suspend fun more(page: Page): Paged<VideoItem> = Yt.playlistMore(url, page)
    override fun keyOf(item: VideoItem): Any = item.url
}

@UnstableApi
@Composable
fun PlaylistScreen(url: String) {
    val actions = LocalActions.current
    val vm: PlaylistVm = viewModel(key = "pl-$url") { PlaylistVm(url) }
    LaunchedEffect(vm) { vm.start() }
    val listState = rememberLazyListState()
    EndReached(listState) { vm.loadMore() }
    val progress = rememberWatchProgress()
    var menuFor by remember { mutableStateOf<VideoItem?>(null) }
    val info = vm.info

    Column(Modifier.fillMaxSize()) {
        TopBar("", onBack = { actions.back() }) {
            IconButton(onClick = { actions.share(url, info?.name ?: "") }) { Icon(Icons.Rounded.Share, "Share", tint = Cl.Text) }
        }
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
            if (info != null) item {
                val by = info.uploaderName ?: ""
                val count = if (info.streamCount >= 0) "${info.streamCount} videos" else ""
                val ready = vm.items.isNotEmpty()
                PlaylistHeader(
                    vm.items.firstOrNull()?.thumbnail ?: "",
                    info.name ?: "Playlist",
                    listOf(by, count).filter { it.isNotBlank() }.joinToString(" · "),
                    onPlay = if (ready) ({ PlayerController.playQueue(vm.items, name = info?.name ?: ""); actions.openPlayer() }) else null,
                    onShuffle = if (ready) ({ PlayerController.playQueue(vm.items, shuffle = true, name = info?.name ?: ""); actions.openPlayer() }) else null
                )
            }
            when {
                vm.loading && vm.items.isEmpty() -> item { Loading() }
                vm.error != null && vm.items.isEmpty() -> item { ErrorBox(vm.error ?: "", onRetry = { vm.reload() }) }
                else -> itemsIndexed(vm.items, key = { _, v -> v.url }) { i, v ->
                    VideoRow(
                        v,
                        onClick = { PlayerController.playQueue(vm.items, i, name = info?.name ?: ""); actions.openPlayer() },
                        progress = progress[v.url] ?: 0f,
                        onMore = { menuFor = v }
                    )
                }
            }
            if (vm.loadingMore) item { Loading() }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
    menuFor?.let { v -> VideoActionsSheet(v, onDismiss = { menuFor = null }) }
}
