# Seek

An ad-free YouTube client for Android that looks and feels like YouTube. No account, no tracking. Everything lives on your phone.

The name is for the red seek bar at the bottom of every video.

Built with Kotlin, Jetpack Compose and Media3, using the same extraction engine as NewPipe. Seek is the new name for Clipse: it installs right over Clipse and keeps your subscriptions, history and playlists.

## New in 2.2

- **New logo, "Echo"**: a play button speeding past two fading copies of itself. New app icon (with a themed version), notification icon and an animated launch screen. The loading spinner is the Echo too, and pull-to-refresh fills it in as you pull
- **Comment replies**: tap "12 replies" to open them right under the comment, "Show more replies" for long threads
- **Sort comments**: Top or Newest
- **Tappable timestamps**: "4:20" in comments and descriptions jumps the video there. Links open (YouTube links stay in Seek), #hashtags search
- **Channel sort**: Latest / Popular / Oldest on Videos, Shorts and Live
- **Search inside a channel**: the search button on a channel now searches just that channel
- **Queue**: "Play next in queue" and "Add to queue" on every video's ⋮ menu. A queue card on the watch page opens the full queue: drag to reorder, remove, clear, jump to any video
- **Hold for 2x**: press and hold the video (or a Short) to play at 2x while your finger is down
- **Scrub previews**: drag the seek bar and see the frame you'd land on, with the chapter name
- **Pinch to zoom**: pinch out to fill the screen (crops the black bars), pinch in for the whole video
- **View angle**: the 3D-cube button on the player (or Settings → View angle) tilts and turns the picture so it looks straight when you're watching from an angle, like lying down. Brightness and volume sliders right there, and **Auto** uses the motion sensor to keep it straight as you shift around
- **Smoother everywhere**: pages slide in, the player rises from the bottom, cards and chips give a little when pressed, loading shows grey placeholders shaped like what's coming, and the keyboard no longer covers lists (the bottom bar steps aside while you type)

## Looks like YouTube

- Keep playing during calls (Settings): video keeps going, turned down, through phone and app calls
- YouTube's dark theme (#0F0F0F), red seek bars, white "Subscribe" pills, rounded-rectangle chips
- Bottom bar: Home · Shorts · (+) · Subscriptions · You. The (+) opens any YouTube link
- Edge-to-edge feed cards with avatar, two-line title and "Channel · views · age", ⋮ menus everywhere
- Mini player above the bottom bar: swipe up to open, swipe down to close, red progress line

## Features

**Home**
- Recommended, without an account: videos related to what you watched last (each video's own "up next"), mixed with new uploads from your subscriptions. Trending fills in when there's no history yet
- Chips: All, Subscriptions, New to you, Recently uploaded, Live, Continue watching, plus the compass that opens Explore
- Shorts shelf between the cards

**Shorts**
- Full-screen vertical swiping, looping, tap to pause, drag the red line to scrub
- Like / dislike counts, comments, share, subscribe from the Short
- New Shorts from your subscriptions first, then endless Shorts from YouTube

**Subscriptions**
- Channel avatar row (blue dot = uploaded today); tap one to see just that channel
- Chips: All, Today, Videos, Shorts, Live, Continue watching, and your own channel groups
- "All" opens the full list: search, groups, unsubscribe
- Background refresh every few hours, new-upload notifications
- Feed filters in Settings: hide Shorts, hide watched, hide videos under X minutes

**Watch page**
- Autoplay switch, captions and settings in the player's top bar; previous / play / next in the middle
- Red seek bar with SponsorBlock segments, time bubble while scrubbing, chapter name next to the time
- Swipe down on the video to minimize; double-tap left/right to skip 10 seconds
- Like | dislike pill (Return YouTube Dislike), Share, Save, Download, Audio only, Loop
- Comments card with the top comment; full comments with replies, Top / Newest and tappable timestamps
- Description panel with stats, chapters, and tappable timestamps, links and hashtags
- Up next as full-size cards
- Quality up to 4K, speed 0.25x–3x, captions, sleep timer, picture-in-picture, background play
- Fullscreen gestures: left side brightness, right side volume, pinch to fill
- Hold the video for 2x, scrub previews on the seek bar, View angle for watching from an angle
- Queue: Play next / Add to queue, drag to reorder

**Explore & search**
- Destination tiles (Music, Gaming, Movies & TV, Podcasts, Live, News, Sports, Learning…) and trending lists
- Search with live suggestions and history, filter by Videos / Channels / Playlists
- YouTube links and shares open straight in Seek

**Channels** – banner, avatar, subscribe, text tabs (Videos, Shorts in a 3-wide grid, Live, Playlists, About), Latest / Popular / Oldest, search inside the channel

**You** – History and Playlists shelves, Watch later, local playlists (reorder, rename, Play all, Shuffle), Downloads, Settings

**Downloads** – MP4 up to 1080p+ (video and audio merged on the phone) or M4A audio, saved to `Downloads/Seek`, playable offline inside Seek

**Data** – import NewPipe `.json` or YouTube Takeout `.csv/.zip`, export NewPipe-compatible subscriptions, full backup/restore (Clipse backups restore too)

## Build it on GitHub (no PC needed)

1. Upload `Seek.zip` to your repo as-is (don't extract it). Your Clipse repo works: the newest zip wins.
2. Put the contents of `build.yml` in `.github/workflows/build.yml` (replace the old one).
3. Commit. The **Actions** tab starts the build (about 6–10 minutes).
4. When it's green, open **Releases → Seek - latest build** and download `Seek.apk`.
   (It's also attached to the workflow run as the `Seek-apk` artifact.)

The APK is signed with the same key Clipse used (`app/seek-release.jks`), so Seek installs right over Clipse without wiping anything.

## Tech

- NewPipe Extractor (pinned to the same commit the NewPipe app ships)
- Media3 ExoPlayer + MediaSession, with NewPipe-style DASH manifests and a custom googlevideo data source
- Jetpack Compose + Material 3
- OkHttp, Coil, kotlinx.serialization, WorkManager
- SponsorBlock API, Return YouTube Dislike API

## Notes

- Seek uses YouTube's public web data the way NewPipe does. It isn't affiliated with YouTube and isn't something Google allows on the Play Store, so it's built for sideloading.
- If YouTube changes something and playback breaks, bump the NewPipe Extractor commit in `app/build.gradle.kts` (and in the workflow's warm-up step) to the one the latest NewPipe release uses.
